(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[3],{"3O+N":function(e,t,a){e.exports=a("h9kl")},BEYS:function(e,t,a){"use strict"
var n=a("sTlx")
var r=a("tpBh")["default"]
var s="1.3.0"
t.VERSION=s
var i=4
t.COMPILER_REVISION=i
var o={1:"<= 1.0.rc.2",2:"== 1.0.0-rc.3",3:"== 1.0.0-rc.4",4:">= 1.0.0"}
t.REVISION_CHANGES=o
var d=n.isArray,_=n.isFunction,c=n.toString,u="[object Object]"
function l(e,t){this.helpers=e||{}
this.partials=t||{}
m(this)}t.HandlebarsEnvironment=l
l.prototype={constructor:l,logger:f,log:h,registerHelper:function(e,t,a){if(c.call(e)===u){if(a||t)throw new r("Arg not supported with multiple helpers")
n.extend(this.helpers,e)}else{a&&(t.not=a)
this.helpers[e]=t}},registerPartial:function(e,t){c.call(e)===u?n.extend(this.partials,e):this.partials[e]=t}}
function m(e){e.registerHelper("helperMissing",(function(e){if(2===arguments.length)return
throw new r("Missing helper: '"+e+"'")}))
e.registerHelper("blockHelperMissing",(function(t,a){var n=a.inverse||function(){},r=a.fn
_(t)&&(t=t.call(this))
return true===t?r(this):false===t||null==t?n(this):d(t)?t.length>0?e.helpers.each(t,a):n(this):r(t)}))
e.registerHelper("each",(function(e,t){var a=t.fn,n=t.inverse
var r,s=0,i=""
_(e)&&(e=e.call(this))
t.data&&(r=p(t.data))
if(e&&"object"===typeof e)if(d(e))for(var o=e.length;s<o;s++){if(r){r.index=s
r.first=0===s
r.last=s===e.length-1}i+=a(e[s],{data:r})}else for(var c in e)if(e.hasOwnProperty(c)){if(r){r.key=c
r.index=s
r.first=0===s}i+=a(e[c],{data:r})
s++}0===s&&(i=n(this))
return i}))
e.registerHelper("if",(function(e,t){_(e)&&(e=e.call(this))
return!t.hash.includeZero&&!e||n.isEmpty(e)?t.inverse(this):t.fn(this)}))
e.registerHelper("unless",(function(t,a){return e.helpers["if"].call(this,t,{fn:a.inverse,inverse:a.fn,hash:a.hash})}))
e.registerHelper("with",(function(e,t){_(e)&&(e=e.call(this))
if(!n.isEmpty(e))return t.fn(e)}))
e.registerHelper("log",(function(t,a){var n=a.data&&null!=a.data.level?parseInt(a.data.level,10):1
e.log(n,t)}))}var f={methodMap:{0:"debug",1:"info",2:"warn",3:"error"},DEBUG:0,INFO:1,WARN:2,ERROR:3,level:3,log:function(e,t){if(f.level<=e){var a=f.methodMap[e]
"undefined"!==typeof console&&console[a]&&console[a].call(console,t)}}}
t.logger=f
function h(e,t){f.log(e,t)}t.log=h
var p=function(e){var t={}
n.extend(t,e)
return t}
t.createFrame=p},DfGn:function(e,t,a){"use strict"
var n=a("2DhO")
var r=a("pQTu")
var s=a("m0r6")
Object(s["a"])(JSON.parse('{"ar":{"enrollmentNames":{"course_designer":"مصمم المساق","observer":"المراقب","student":"الطالب","teacher":"المعلم","teacher_assistant":"مساعد المعلم"}},"cy":{"enrollmentNames":{"course_designer":"Dylunydd Cwrs","observer":"Arsyllwr","student":"Myfyriwr","teacher":"Athro","teacher_assistant":"Cynorthwyydd Dysgu"}},"da":{"enrollmentNames":{"course_designer":"Fagdesigner","observer":"Observatør","student":"Studerende","teacher":"Lærer","teacher_assistant":"Undervisningsassistent"}},"da-x-k12":{"enrollmentNames":{"course_designer":"Fagdesigner","observer":"Observatør","student":"Elev","teacher":"Lærer","teacher_assistant":"Undervisningsassistent"}},"de":{"enrollmentNames":{"course_designer":"Kursdesigner","observer":"Beobachter","student":"Student","teacher":"Dozent","teacher_assistant":"Lehrassistent"}},"el":{"enrollmentNames":{"course_designer":"Σχεδιαστής/ια Μαθήματος","observer":"Παρατηρητής","student":"Μαθητής","teacher":"Δάσκαλος","teacher_assistant":"Βοηθός Διδασκαλίας"}},"en-AU":{"enrollmentNames":{"course_designer":"Course Designer","observer":"Observer","student":"Student","teacher":"Teacher","teacher_assistant":"TA"}},"en-CA":{"enrollmentNames":{"course_designer":"Course Designer","observer":"Observer","student":"Student","teacher":"Teacher","teacher_assistant":"TA"}},"en-GB":{"enrollmentNames":{"course_designer":"Course designer","observer":"Observer","student":"Student","teacher":"Teacher","teacher_assistant":"TA"}},"es":{"enrollmentNames":{"course_designer":"Diseñador del curso","observer":"Observador","student":"Estudiante","teacher":"Profesor","teacher_assistant":"Profesor auxiliar"}},"fa":{"enrollmentNames":{"course_designer":"طراح درس","observer":"بیننده","student":"دانشجو","teacher":"استاد","teacher_assistant":"دستیار آموزشی"}},"fi":{"enrollmentNames":{"course_designer":"Kurssin suunnittelija","observer":"Havainnoija","student":"Opiskelija","teacher":"Opettaja","teacher_assistant":"Apuopettaja"}},"fr":{"enrollmentNames":{"course_designer":"Concepteur de cours","observer":"Observateur","student":"Étudiant","teacher":"Enseignant","teacher_assistant":"AE"}},"fr-CA":{"enrollmentNames":{"course_designer":"Concepteur de cours","observer":"Observateur","student":"Étudiant","teacher":"Enseignant","teacher_assistant":"AE"}},"he":{"enrollmentNames":{"course_designer":"מתכנן / מעצב קורס","observer":"משקיף","student":"תלמיד","teacher":"מורה","teacher_assistant":"עוזר הוראה"}},"ht":{"enrollmentNames":{"course_designer":"Kreyatè Kou","observer":"Obsèvatè","student":"Elèv","teacher":"Pwofesè","teacher_assistant":"AP"}},"hu":{"enrollmentNames":{"course_designer":"Kurzustervező","observer":"Megfigyelő","student":"Hallgató","teacher":"Oktató","teacher_assistant":"Segédoktató"}},"hy":{"enrollmentNames":{"course_designer":"Դասընթացի դիզայներ","observer":"Դիտորդ","student":"Ունկնդիր","teacher":"Դասավանդող","teacher_assistant":"Ասիստենտ"}},"is":{"enrollmentNames":{"course_designer":"Námskeiðshönnuður","observer":"Skoðandi","student":"Nemandi","teacher":"Kennari","teacher_assistant":"Aðstoðarkennari"}},"it":{"enrollmentNames":{"course_designer":"Progettista corso","observer":"Osservatore","student":"Studente","teacher":"Insegnante","teacher_assistant":"Assistente"}},"ja":{"enrollmentNames":{"course_designer":"コース設計者","observer":"オブザーバ","student":"受講生","teacher":"講師","teacher_assistant":"TA"}},"ko":{"enrollmentNames":{"course_designer":"과목 디자이너","observer":"감독자","student":"학생","teacher":"교사","teacher_assistant":"조교"}},"mi":{"enrollmentNames":{"course_designer":"Kaihoahoa akoranga","observer":"kaimātakitaki","student":"Ākonga","teacher":"Kaiako","teacher_assistant":"TA"}},"nb":{"enrollmentNames":{"course_designer":"Designer for emne","observer":"Observatør","student":"Student","teacher":"Lærer","teacher_assistant":"LA"}},"nb-x-k12":{"enrollmentNames":{"course_designer":"Designer for fag","observer":"Observatør","student":"Elev","teacher":"Lærer","teacher_assistant":"LA"}},"nl":{"enrollmentNames":{"course_designer":"Cursusontwerper","observer":"Waarnemer","student":"Cursist","teacher":"Docent","teacher_assistant":"Onderwijsassistent"}},"nn":{"enrollmentNames":{"course_designer":"Emnedesignar","observer":"Observatør","student":"Student","teacher":"Faglærar","teacher_assistant":"Undervisingsassistent"}},"pl":{"enrollmentNames":{"course_designer":"Autor kursu","observer":"Obserwator","student":"Uczestnik","teacher":"Instruktor","teacher_assistant":"Asystent/-ka instruktora"}},"pt":{"enrollmentNames":{"course_designer":"Designer da disciplina","observer":"Observador","student":"Aluno","teacher":"Professor","teacher_assistant":"Assistente"}},"pt-BR":{"enrollmentNames":{"course_designer":"Designer do curso","observer":"Observador","student":"Aluno","teacher":"Professor","teacher_assistant":"Assistente"}},"ru":{"enrollmentNames":{"course_designer":"Дизайнер курса","observer":"Наблюдатель","student":"Студент","teacher":"Учитель","teacher_assistant":"Ассистент"}},"sl":{"enrollmentNames":{"course_designer":"Snovalec predmeta","observer":"Skriti bralec","student":"Študent","teacher":"Izvajalec","teacher_assistant":"Demonstrator"}},"sv":{"enrollmentNames":{"course_designer":"Kursdesigner","observer":"Observatör","student":"Student","teacher":"Lärare","teacher_assistant":"Lärarassistent"}},"sv-x-k12":{"enrollmentNames":{"course_designer":"Kursdesigner","observer":"Observatör","student":"Elev","teacher":"Lärare","teacher_assistant":"Lärarassistent"}},"tr":{"enrollmentNames":{"course_designer":"Ders Tasarımcısı","observer":"Gözlemci","student":"Öğrenci","teacher":"Öğretmen","teacher_assistant":"Asistan Öğretmen"}},"uk":{"enrollmentNames":{"course_designer":"Конструктор курсу","observer":"Спостерігач","student":"Студент","teacher":"Вчитель","teacher_assistant":"TA"}},"zh-Hans":{"enrollmentNames":{"course_designer":"课程设计者","observer":"观察员","student":"学生","teacher":"教师","teacher_assistant":"助教"}},"zh-Hant":{"enrollmentNames":{"course_designer":"課程設計師","observer":"觀察者","student":"學生","teacher":"教師","teacher_assistant":"助教"}}}'))
a("jQeR")
a("0sPK")
var i=r["default"].scoped("enrollmentNames")
const o={get StudentEnrollment(){return i.t("student","Student")},get TeacherEnrollment(){return i.t("teacher","Teacher")},get TaEnrollment(){return i.t("teacher_assistant","TA")},get ObserverEnrollment(){return i.t("observer","Observer")},get DesignerEnrollment(){return i.t("course_designer","Course Designer")}}
function d(e){return o[e]||e}var _=a("3O+N")
var c=a.n(_)
var u=a("ouhR")
var l=a.n(u)
var m=a("GLiE")
var f=a.n(m)
var h=a("5Ky4")
var p=a("u/6C")
var b=a("VTBJ")
const g={year(e,t){const a=e.startYear<e.endYear?1:-1
const n=l()("<select />",t)
e.includeBlank&&n.append("<option />")
let r=e.startYear
while(r*a<=e.endYear*a){r+=a
n.append(l()('<option value="'.concat(r,'">').concat(r,"</option>")))}return n},month(e,t,a){const n=a.month_names
const r=l()("<select />",t)
e.includeBlank&&r.append("<option />")
for(let e=1;e<=12;e++)r.append(l()('<option value="'.concat(e,'">').concat(Object(h["a"])(n[e]),"</option>")))
return r},day(e,t){const a=l()("<select />",t)
e.includeBlank&&a.append("<option />")
for(let e=1;e<=31;e++)a.append(l()('<option value="'.concat(e,'">').concat(e,"</option>")))
return a}}
function v(e,t){let a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:f.a.clone(t)
const n=["type","startYear","endYear","includeBlank","order"]
n.forEach(e=>delete a[e])
null==a.class&&(a.class="")
a.class+=" date-select"
const s=(new Date).getFullYear()
const i={year:1,month:2,day:3}
const o=r["default"].lookup("date")
"birthdate"===t.type&&f.a.defaults(t,{startYear:s-1,endYear:s-125,includeBlank:true})
f.a.defaults(t,{startYear:s-5,endYear:s+5,order:o.order||["year","month","day"]})
const d=l()("<span>")
for(let n=0,r=t.order.length,s=r>=0;s?n<r:n>r;s?n++:n--){const r=t.order[n]
const s=e.replace(/(\]?)$/,"(".concat(i[r],"i)$1"))
const _=g[r](t,Object(b["a"])({name:s},a),o)
d.append(_)
delete a.id}return d}var D=a("sVap")
var k=a("ppAs")
var y=a("0crz")
var x=a("g1Ui")
a("UlQx")
a("JI1W")
a("p6Wi")
Object(s["a"])(JSON.parse('{"ar":{"duration_1_minute_29c7d5ab":"المدة: 1 دقيقة","duration_hours_hours_and_minutes_minutes_d5da8c3":"المدة: %{hours} ساعة و %{minutes} دقيقة","duration_minutes_minutes_d7b9182b":"المدة: %{minutes} دقائق","helpers":{"accessible_date_format":"DD-MM-YYYY hh:mm","accessible_date_only_format":"DD-MM-YYYY","accessible_date_prompt":"تنسيق مثل","accessible_time_only_format":"hh:mm","course":"المساق","local":"محلي"}},"cy":{"duration_1_minute_29c7d5ab":"Hyd: 1 munud","duration_hours_hours_and_minutes_minutes_d5da8c3":"Hyd: %{hours} awr a %{minutes} a munud","duration_minutes_minutes_d7b9182b":"Hyd: %{minutes} munud","helpers":{"accessible_date_format":"BBBB-MM-DD aa:mm","accessible_date_only_format":"BBBB-MM-DD","accessible_date_prompt":"Fformatio’r nodwedd Hoffi","accessible_time_only_format":"aa:mm","course":"Cwrs","local":"Lleol"}},"da":{"duration_1_minute_29c7d5ab":"Varighed: 1 minut","duration_hours_hours_and_minutes_minutes_d5da8c3":"Varighed: %{hours} timer og %{minutes} minutter","duration_minutes_minutes_d7b9182b":"Varighed: %{minutes} minutter","helpers":{"accessible_date_format":"ÅÅÅÅ-MM-DD tt:mm","accessible_date_only_format":"ÅÅÅÅ-MM-DD","accessible_date_prompt":"Formater som","accessible_time_only_format":"tt:mm","course":"Fag","local":"Lokal"}},"da-x-k12":{"duration_1_minute_29c7d5ab":"Varighed: 1 minut","duration_hours_hours_and_minutes_minutes_d5da8c3":"Varighed: %{hours} timer og %{minutes} minutter","duration_minutes_minutes_d7b9182b":"Varighed: %{minutes} minutter","helpers":{"accessible_date_format":"ÅÅÅÅ-MM-DD tt:mm","accessible_date_only_format":"ÅÅÅÅ-MM-DD","accessible_date_prompt":"Formater som","accessible_time_only_format":"tt:mm","course":"Fag","local":"Lokal"}},"de":{"duration_1_minute_29c7d5ab":"Dauer: 1 Minute","duration_hours_hours_and_minutes_minutes_d5da8c3":"Dauer: %{hours} Stunden und %{minutes} Minuten","duration_minutes_minutes_d7b9182b":"Dauer: %{minutes} Minuten","helpers":{"accessible_date_format":"JJJJ-MM-TT hh:mm","accessible_date_only_format":"TT-MM-JJJJ","accessible_date_prompt":"Format wie","accessible_time_only_format":"hh:mm","course":"Kurs","local":"Lokal"}},"el":{"helpers":{"accessible_date_format":"DD-MM-YYYY hh:mm","accessible_date_only_format":"ΕΕΕΕ-ΜΜ-ΗΗ","accessible_date_prompt":"Μορφοποίηση ως","accessible_time_only_format":"ωω:λλ","course":"Μάθημα","local":"Τοπικό"}},"en-AU":{"duration_1_minute_29c7d5ab":"Duration: 1 minute","duration_hours_hours_and_minutes_minutes_d5da8c3":"Duration: %{hours} hours and %{minutes} minutes","duration_minutes_minutes_d7b9182b":"Duration: %{minutes} minutes","helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"Format Like","accessible_time_only_format":"hh:mm","course":"Course","local":"Local"}},"en-CA":{"duration_1_minute_29c7d5ab":"Duration: 1 minute","duration_hours_hours_and_minutes_minutes_d5da8c3":"Duration: %{hours} hours and %{minutes} minutes","duration_minutes_minutes_d7b9182b":"Duration: %{minutes} minutes","helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"Format Like","accessible_time_only_format":"hh:mm","course":"Course","local":"Local"}},"en-GB":{"duration_1_minute_29c7d5ab":"Duration: 1 minute","duration_hours_hours_and_minutes_minutes_d5da8c3":"Duration: %{hours} hours and %{minutes} minutes","duration_minutes_minutes_d7b9182b":"Duration: %{minutes} minutes","helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"Format Like","accessible_time_only_format":"hh:mm","course":"Course","local":"Local"}},"es":{"duration_1_minute_29c7d5ab":"Duración: 1 minuto","duration_hours_hours_and_minutes_minutes_d5da8c3":"Duración: %{hours} horas y %{minutes} minutos","duration_minutes_minutes_d7b9182b":"Duración: %{minutes} minutos","helpers":{"accessible_date_format":"DD-MM-AAAA hh:mm","accessible_date_only_format":"DD-MM-AAAA","accessible_date_prompt":"Formato como","accessible_time_only_format":"hh:mm","course":"Curso","local":"Hora local"}},"fa":{"helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"قالب مانند","accessible_time_only_format":"hh:mm","course":"درس","local":"محلی"}},"fi":{"duration_1_minute_29c7d5ab":"Kesto: 1 minuutti","duration_hours_hours_and_minutes_minutes_d5da8c3":"Kesto: %{hours} tuntia ja %{minutes} minuuttia","duration_minutes_minutes_d7b9182b":"Kesto: %{minutes} minuuttia","helpers":{"accessible_date_format":"VVVV-KKPV hh:mm","accessible_date_only_format":"VVVV-KK-PV","accessible_date_prompt":"Muotoilutapa","accessible_time_only_format":"hh:mm","course":"Kurssi","local":"Paikallinen"}},"fr":{"duration_1_minute_29c7d5ab":"Durée : 1 minute","duration_hours_hours_and_minutes_minutes_d5da8c3":"Durée : %{hours} heures et %{minutes} minutes","duration_minutes_minutes_d7b9182b":"Durée : %{minutes} minutes","helpers":{"accessible_date_format":"AAAA-MM-JJ hh:mm","accessible_date_only_format":"AAAA-MM-JJ","accessible_date_prompt":"Formater comme","accessible_time_only_format":"hh:mm","course":"Cours","local":"Local"}},"fr-CA":{"duration_1_minute_29c7d5ab":"Durée : 1 minute","duration_hours_hours_and_minutes_minutes_d5da8c3":"Durée : %{hours} heures et %{minutes} minutes","duration_minutes_minutes_d7b9182b":"Durée : %{minutes} minutes","helpers":{"accessible_date_format":"AAAA-MM-JJ hh:mm","accessible_date_only_format":"AAAA-MM-JJ","accessible_date_prompt":"Formater comme","accessible_time_only_format":"hh:mm","course":"Cours","local":"Local"}},"he":{"helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"בפורמט כגון","accessible_time_only_format":"hh:mm","course":"קורס","local":"מקומי"}},"ht":{"duration_1_minute_29c7d5ab":"Dire: 1 minit","duration_hours_hours_and_minutes_minutes_d5da8c3":"Dire: %{hours} èdtan e %{minutes} minit","duration_minutes_minutes_d7b9182b":"Dire: %{minutes} minit","helpers":{"accessible_date_format":"JJ-MM-AAAA hh:mm","accessible_date_only_format":"JJ-MM-AAAA","accessible_date_prompt":"Fòma","accessible_time_only_format":"hh:mm","course":"Kou","local":"Lokal"}},"hu":{"duration_1_minute_29c7d5ab":"Időtartam: 1 perc","duration_hours_hours_and_minutes_minutes_d5da8c3":"Időtartam: %{hours}óra és %{minutes}ˇperc","duration_minutes_minutes_d7b9182b":"Időtartam: %{minutes}perc","helpers":{"accessible_date_format":"ÉÉÉÉ-HH-NN óó:pp","accessible_date_only_format":"ÉÉÉÉ-HH-NN","accessible_date_prompt":"Ilyen formátumban","accessible_time_only_format":"óó:pp","course":"Kurzus","local":"Helyi"}},"hy":{"helpers":{"accessible_date_format":"ՏՏՏՏ-ԱԱ-ՕՕ ժժ:րր","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"Ֆորմատի նման","accessible_time_only_format":"hh:mm","course":"Դասընթաց","local":"Տեղական"}},"is":{"duration_1_minute_29c7d5ab":"Tími:1 mínúta","duration_hours_hours_and_minutes_minutes_d5da8c3":"Tími: %{hours}Klukkustundir og %{minutes} mínútur","duration_minutes_minutes_d7b9182b":"Tími: %{minutes}mínútur","helpers":{"accessible_date_format":"ÁÁÁÁ-MM-DD kl:mín","accessible_date_only_format":"ÁÁÁÁ-MM-DD","accessible_date_prompt":"Sníða eins","accessible_time_only_format":"klst:mín","course":"Námskeið","local":"Staðbundið"}},"it":{"duration_1_minute_29c7d5ab":"Durata: 1 minuto","duration_hours_hours_and_minutes_minutes_d5da8c3":"Durata: %{hours} ore e %{minutes} minuti","duration_minutes_minutes_d7b9182b":"Durata: %{minutes} minuti","helpers":{"accessible_date_format":"AAAA-MM-GG hh:mm","accessible_date_only_format":"AAAA-MM-GG","accessible_date_prompt":"Formatta come","accessible_time_only_format":"hh:mm","course":"Corso","local":"Locale"}},"ja":{"duration_1_minute_29c7d5ab":"期間:1 分","duration_hours_hours_and_minutes_minutes_d5da8c3":"期間:%{hours}時間 %{minutes} 分","duration_minutes_minutes_d7b9182b":"期間:%{minutes}分","helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD ","accessible_date_prompt":"フォーマットと同様に","accessible_time_only_format":"hh:mm","course":"コース","local":"ローカル"}},"ko":{"helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"형식","accessible_time_only_format":"hh:mm","course":"과목","local":"로컬"}},"mi":{"duration_1_minute_29c7d5ab":"Te Roanga: 1 meneti","duration_hours_hours_and_minutes_minutes_d5da8c3":"Te Roanga: %{hours} ngā roanga me %{minutes} ngā meneti","duration_minutes_minutes_d7b9182b":"Te Roanga: %{minutes} Ngā meneti","helpers":{"accessible_date_format":"HH YYYY-MM-DD: mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"hōputu rite","accessible_time_only_format":"HH: mm","course":"akoranga","local":"Paetata"}},"nb":{"duration_1_minute_29c7d5ab":"Varighet: 1 minutt","duration_hours_hours_and_minutes_minutes_d5da8c3":"Varighet: %{hours} timer og %{minutes} minutter","duration_minutes_minutes_d7b9182b":"Varighet: %{minutes} minutter","helpers":{"accessible_date_format":"ÅÅÅÅ-MM-DD tt:mm","accessible_date_only_format":"ÅÅÅÅ-MM-DD","accessible_date_prompt":"Formatter som","accessible_time_only_format":"tt:mm","course":"Emne","local":"Lokal"}},"nb-x-k12":{"duration_1_minute_29c7d5ab":"Varighet: 1 minutt","duration_hours_hours_and_minutes_minutes_d5da8c3":"Varighet: %{hours} timer and %{minutes} minutter","duration_minutes_minutes_d7b9182b":"Varighet: %{minutes} minutter","helpers":{"accessible_date_format":"DD-MM-ÅÅÅÅ tt:mm","accessible_date_only_format":"ÅÅÅÅ-MM-DD","accessible_date_prompt":"Formater som","accessible_time_only_format":"tt:mm","course":"Fag","local":"Lokal"}},"nl":{"duration_1_minute_29c7d5ab":"Duur: 1 minuut","duration_hours_hours_and_minutes_minutes_d5da8c3":"Duur: %{hours} uur en %{minutes} minuten","duration_minutes_minutes_d7b9182b":"Duur: %{minutes} minuten","helpers":{"accessible_date_format":"JJJJ-MM-DD uu:mm","accessible_date_only_format":"JJJJ-MM-DD","accessible_date_prompt":"Formaat als","accessible_time_only_format":"JJJJ-MM-DD uu:mm","course":"Cursus","local":"Plaatselijk"}},"nn":{"duration_1_minute_29c7d5ab":"Varigheit: 1 minutt","duration_hours_hours_and_minutes_minutes_d5da8c3":"Varigheit: %{hours} timar og %{minutes} minutt","duration_minutes_minutes_d7b9182b":"Varigheit: %{minutes}minutt","helpers":{"accessible_date_format":"DD-MM-ÅÅÅÅ tt:mm","accessible_date_only_format":"DD-MM-ÅÅÅÅ","accessible_date_prompt":"Format som","accessible_time_only_format":"tt:mm","course":"Emne","local":"Lokal"}},"pl":{"duration_1_minute_29c7d5ab":"Czas trwania: 1 min","duration_hours_hours_and_minutes_minutes_d5da8c3":"Czas trwania: %{hours} godz. i %{minutes} min","duration_minutes_minutes_d7b9182b":"Czas trwania: %{minutes} min","helpers":{"accessible_date_format":"RRRR-MM-DD gg:mm","accessible_date_only_format":"RRRR-MM-DD","accessible_date_prompt":"Rodzaj formatu","accessible_time_only_format":"gg:mm","course":"Kurs","local":"Lokalne"}},"pt":{"duration_1_minute_29c7d5ab":"Duração: 1 minuto","duration_hours_hours_and_minutes_minutes_d5da8c3":"Duração: %{hours} horas e %{minutes} minutos","duration_minutes_minutes_d7b9182b":"Duração: %{minutes} minutos","helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"AAAA-MM-DD","accessible_date_prompt":"Gostar do Formato","accessible_time_only_format":"hh:mm","course":"Disciplina","local":"Local"}},"pt-BR":{"duration_1_minute_29c7d5ab":"Duração: 1 minuto","duration_hours_hours_and_minutes_minutes_d5da8c3":"Duração: %{hours} horas e %{minutes} minutos","duration_minutes_minutes_d7b9182b":"Duração: %{minutes} minutos","helpers":{"accessible_date_format":"DD-MM-AAAA hh:mm","accessible_date_only_format":"DD-MM-AAAA","accessible_date_prompt":"Formatar como","accessible_time_only_format":"hh:mm","course":"Curso","local":"Local"}},"ru":{"duration_1_minute_29c7d5ab":"Длительность: 1 минута","duration_hours_hours_and_minutes_minutes_d5da8c3":"Длительность: %{hours} часов и %{minutes} минут","duration_minutes_minutes_d7b9182b":"Длительность: %{minutes} минут","helpers":{"accessible_date_format":"ГГГГ-ММ-ДД чч:мм","accessible_date_only_format":"ГГГГ-ММ-ДД","accessible_date_prompt":"Формат подобно","accessible_time_only_format":"чч:мм","course":"Курс","local":"Местный"}},"sl":{"duration_1_minute_29c7d5ab":"Trajanje: 1 minuta","duration_hours_hours_and_minutes_minutes_d5da8c3":"Trajanje: %{hours} ur in %{minutes} minut","duration_minutes_minutes_d7b9182b":"Trajanje: %{minutes} minut","helpers":{"accessible_date_format":"LLLL-MM-DD uu:mm","accessible_date_only_format":"LLLL-MM-DD","accessible_date_prompt":"Oblikuj všeček","accessible_time_only_format":"uu:mm","course":"Predmet","local":"Lokalno"}},"sv":{"duration_1_minute_29c7d5ab":"Varaktighet: 1 minut","duration_hours_hours_and_minutes_minutes_d5da8c3":"Varaktighet: %{hours} timmar och %{minutes} minuter","duration_minutes_minutes_d7b9182b":"Varaktighet: %{minutes} minuter","helpers":{"accessible_date_format":"ÅÅÅÅ-MM-DD hh:mm","accessible_date_only_format":"ÅÅÅÅ-MM-DD","accessible_date_prompt":"Formatera Gilla","accessible_time_only_format":"hh:mm","course":"Kurs","local":"Lokal"}},"sv-x-k12":{"duration_1_minute_29c7d5ab":"Varaktighet: 1 minut","duration_hours_hours_and_minutes_minutes_d5da8c3":"Varaktighet: %{hours} timmar och %{minutes} minuter","duration_minutes_minutes_d7b9182b":"Varaktighet: %{minutes} minuter","helpers":{"accessible_date_format":"ÅÅÅÅ-MM-DD hh:mm","accessible_date_only_format":"ÅÅÅÅ-MM-DD","accessible_date_prompt":"Formatera Gilla","accessible_time_only_format":"hh:mm","course":"Kurs","local":"Lokal"}},"tr":{"duration_1_minute_29c7d5ab":"Süre: 1 dakika","duration_hours_hours_and_minutes_minutes_d5da8c3":"Süre: %{hours} saat %{minutes} dakika","duration_minutes_minutes_d7b9182b":"Süre: %{minutes} dakika","helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"Gibi Format","accessible_time_only_format":"ss:dd","course":"Ders","local":"Yerel"}},"uk":{"helpers":{"accessible_date_format":"РРРР-ММ-ДД гг:хв","accessible_date_only_format":"РРРР-ММ-ДД","accessible_date_prompt":"Форматувати як","accessible_time_only_format":"гг:хв","course":"Курс","local":"локально"}},"zh-Hans":{"duration_1_minute_29c7d5ab":"持续时间：1 分钟","duration_hours_hours_and_minutes_minutes_d5da8c3":"持续时间：%{hours}小时 %{minutes} 分钟","duration_minutes_minutes_d7b9182b":"持续时间：%{minutes}分钟","helpers":{"accessible_date_format":"YYYY-MM-DD hh:mm","accessible_date_only_format":"YYYY-MM-DD","accessible_date_prompt":"格式像","accessible_time_only_format":"hh:mm","course":"课程","local":"当地时间"}},"zh-Hant":{"duration_1_minute_29c7d5ab":"持續時間：1 分鐘","duration_hours_hours_and_minutes_minutes_d5da8c3":"持續時間：%{hours}小時和 %{minutes} 分鐘","duration_minutes_minutes_d7b9182b":"持續時間：%{minutes}分鐘","helpers":{"accessible_date_format":"年年年年-月月-日日 時時:分分","accessible_date_only_format":"年年年年-月月-日日","accessible_date_prompt":"格式示例：","accessible_time_only_format":"時時:分分","course":"課程","local":"本地"}}}'))
var w=r["default"].scoped("handlebars_helpers")
var M,A,S,T,Y=[].slice,F={}.hasOwnProperty,N=[].indexOf||function(e){for(var t=0,a=this.length;t<a;t++)if(t in this&&this[t]===e)return t
return-1}
M=c.a["default"]
T={t:function(){var e,t,a,n,s,i,o,d,_,c
e=2<=arguments.length?Y.call(arguments,0,t=arguments.length-1):(t=0,[]),i=arguments[t++]
c={}
i=null!=(o=null!=i?i.hash:void 0)?o:{}
for(n in i){_=i[n]
if(!n.match(/^w\d+$/))continue
c[new Array(parseInt(n.replace("w",""))+2).join("*")]=_
delete i[n]}c["*"]&&(i.wrapper=c)
if(!("undefined"===typeof this||this instanceof Window)){d=this
for(a=0,s=d.length;a<s;a++){n=d[a]
i[n]=this[n]}}return new M.SafeString(Object(h["a"])(r["default"].t.apply(r["default"],Y.call(e).concat([i]))))},__i18nliner_escape:function(e){return Object(h["a"])(e)},__i18nliner_safe:function(e){return new h["a"].SafeString(e)},__i18nliner_concat:function(){var e,t
e=2<=arguments.length?Y.call(arguments,0,t=arguments.length-1):(t=0,[]),arguments[t++]
return e.join("")},hiddenIf:function(e){if(e)return" display:none; "},hiddenUnless:function(e){if(!e)return" display:none; "},hiddenIfExists:function(e){if(null!=e)return" display:none; "},hiddenUnlessExists:function(e){if(null==e)return" display:none; "},ifExists:function(e,t){return null!=e?t.fn(this):t.inverse(this)},semanticDateRange:function(){return new M.SafeString(p["a"].apply(null,arguments))},contextSensitiveDatetimeTitle:function(e,t){var a,n,r,s,i,o
r=t.hash.justText
s=l.a.datetimeString(e)
o=s
if(ENV&&ENV.CONTEXT_TIMEZONE&&ENV.TIMEZONE!==ENV.CONTEXT_TIMEZONE){i=w.t("#helpers.local","Local")
n=w.t("#helpers.course","Course")
a=l.a.datetimeString(e,{timezone:ENV.CONTEXT_TIMEZONE})
s!==a&&(o=Object(h["a"])(i)+": "+Object(h["a"])(s)+"<br>"+Object(h["a"])(n)+": "+Object(h["a"])(a))}return r?new M.SafeString(o):new M.SafeString('data-tooltip data-html-tooltip-title="'+Object(h["a"])(o)+'"')},friendlyDatetime:function(e,t){var a,r,s,i,o
i=t.hash,s=i.pubdate,a=i.contextSensitive
if(null==e)return
f.a.isDate(e)||(e=n["a"].parse(e))
r=l.a.fudgeDateForProfileTimezone(n["a"].parse(e))
o=""
o=a&&ENV&&ENV.CONTEXT_TIMEZONE?M.helpers.contextSensitiveDatetimeTitle(e,{hash:{justText:true}}):l.a.datetimeString(e)
return new M.SafeString("<time data-tooltip data-html-tooltip-title='"+Object(h["a"])(o)+"' datetime='"+e.toISOString()+"' "+l.a.raw(s?"pubdate":void 0)+">\n  <span aria-hidden='true'>"+l.a.friendlyDatetime(r)+"</span>\n  <span class='screenreader-only'>"+o+"</span>\n</time>")},fudge:function(e){return l.a.fudgeDateForProfileTimezone(e)},unfudge:function(e){return l.a.unfudgeDateForProfileTimezone(e)},formattedDate:function(e,t,a){var r
r=a.hash.pubdate
if(null==e)return
f.a.isDate(e)||(e=n["a"].parse(e))
return new M.SafeString("<time data-tooltip title='"+l.a.datetimeString(e)+"' datetime='"+e.toISOString()+"' "+l.a.raw(r?"pubdate":void 0)+">"+Object(h["a"])(e.toString(t))+"</time>")},datetimeFormatted:function(e){return l.a.datetimeString(e)},dateString:function(e){if(!e)return""
return r["default"].l("date.formats.medium",e)},minutesToHM:function(e){var t,a,n
t=Math.floor(e/60)
n=e%60
a=n<10?"0"+n:n
return t+":"+a},durationToString:function(e){var t,a
t=Math.floor(e/60)
a=e%60
return t>0?w.t("Duration: %{hours} hours and %{minutes} minutes",{hours:t,minutes:a}):a>1?w.t("Duration: %{minutes} minutes",{minutes:a}):w.t("Duration: 1 minute")},addIcon:function(e){return new M.SafeString("<i role='presentation' class='icon-"+Object(h["a"])(e)+"'></i>")},dateToString:function(e,t){null==e&&(e="")
return e.toString(t)},tDateToString:function(e,t){var a
null==e&&(e="")
if(!e)return""
f.a.isDate(e)||(e=n["a"].parse(e))
a=l.a.fudgeDateForProfileTimezone(n["a"].parse(e))
return r["default"].l("date.formats."+t,a)},tTimeToString:function(e,t){var a
null==e&&(e="")
if(!e)return""
f.a.isDate(e)||(e=n["a"].parse(e))
a=l.a.fudgeDateForProfileTimezone(n["a"].parse(e))
return r["default"].l("time.formats."+t,a)},tTimeHours:function(e){null==e&&(e="")
return 0===e.getMinutes()&&0===e.getSeconds()?r["default"].l("time.formats.tiny_on_the_hour",e):r["default"].l("time.formats.tiny",e)},tEventToString:function(e,t,a){null==e&&(e="")
null==t&&(t="short")
null==a&&(a="tiny")
return r["default"].t("time.event",{defaultValue:"%{date} at %{time}",date:r["default"].l("date.formats."+t,e),time:r["default"].l("time.formats."+a,e)})},strftime:function(e,t){null==e&&(e="")
return r["default"].strftime(e,t)},accessibleDateFormat:function(e){null==e&&(e="datetime")
return"date"===e?w.t("#helpers.accessible_date_only_format","YYYY-MM-DD"):"time"===e?w.t("#helpers.accessible_time_only_format","hh:mm"):w.t("#helpers.accessible_date_format","YYYY-MM-DD hh:mm")},datepickerScreenreaderPrompt:function(e){var t
null==e&&(e="datetime")
t=w.t("#helpers.accessible_date_prompt","Format Like")
e=M.helpers.accessibleDateFormat(e)
return t+" "+e},mimeClass:D["a"],convertApiUserContent:function(e,t){var a,n
n=t.hash
a=k["a"].convert(e,n)
n&&n.forEditing||(a=new M.SafeString(a))
return a},newlinesToBreak:function(e){e||(e="")
return new M.SafeString(Object(h["a"])(e).replace(/\n/g,"<br />"))},not:function(e){return!e},ifEqual:function(){var e,t,a,n,r,s,i,o
i=arguments[0],t=3<=arguments.length?Y.call(arguments,1,a=arguments.length-1):(a=1,[]),o=arguments[a++],A=o.fn,n=o.inverse
for(r=0,s=t.length;r<s;r++){e=t[r]
if(e!==i)return n(this)
i=e}return A(this)},ifAll:function(){var e,t,a,n,r,s,i
t=2<=arguments.length?Y.call(arguments,0,a=arguments.length-1):(a=0,[]),i=arguments[a++],A=i.fn,n=i.inverse
for(r=0,s=t.length;r<s;r++){e=t[r]
if(!e)return n(this)}return A(this)},ifAny:function(){var e,t,a,n,r,s,i
t=2<=arguments.length?Y.call(arguments,0,a=arguments.length-1):(a=0,[]),i=arguments[a++],A=i.fn,n=i.inverse
for(r=0,s=t.length;r<s;r++){e=t[r]
if(e)return A(this)}return n(this)},ifNull:function(){var e,t,a,n,r
t=2<=arguments.length?Y.call(arguments,0,a=arguments.length-1):(a=0,[]),r=arguments[a++],A=r.fn,n=r.inverse
e=t[0]
if(null!=e)return n(this)
return A(this)},eachWithIndex:function(e,t){var a,n,r,s,i
A=t.fn
r=t.inverse
i=parseInt(t.hash.startingValue||0,10)
s=""
if(e&&e.length>0)for(n in e){if(!F.call(e,n))continue
a=e[n]
a._index=parseInt(n,10)+i
s+=A(a)}else s=r(this)
return s},eachProp:function(e,t){var a
return function(){var n
n=[]
for(a in e)n.push(t.fn({property:a,value:e[a]}))
return n}().join("")},ifSettingIs:function(){var e,t,a,n,r
a=arguments[0],r=arguments[1],t=arguments[2],A=t.fn,e=t.inverse
n=ENV.SETTINGS
if(n[a]===r)return A(this)
return e(this)},toSentence:function(e,t){var a
a=f.a.map(e,(function(e){return t.fn(e)}))
return l.a.toSentence(a)},dateSelect:function(e,t){return new M.SafeString(v(e,t.hash).html())},checkbox:function(e,t){var a,n,r,s,i,o,d,_,c,u,m,p,b,g
r=t.hash
p=e.split(/\./)
m=p.join("_")
if(r.prefix){p.unshift(r.prefix)
delete r.prefix}n=p[0]+f.a.chain(p).rest().map((function(e){return"["+e+"]"})).value().join("")
o=f.a.extend({type:"checkbox",value:1,id:m,name:n},r)
if(null==o.checked){g=f.a.reduce(p,(function(e,t){if(null!=e)return e[t]}),this)
g&&(o.checked=true)}u=["checked","disabled"]
for(i=0,_=u.length;i<_;i++){c=u[i]
o[c]?o[c]=c:delete o[c]}o.uniqid&&o.id&&(o.id+="-"+M.helpers.uniqid.call(this))
delete o.uniqid
a=function(){var e
e=[]
for(d in o){b=o[d]
null!=b&&e.push(Object(h["a"])(d)+'="'+Object(h["a"])(b)+'"')}return e}()
s=o.disabled?"disabled":""
return new M.SafeString('<input name="'+Object(h["a"])(o.name)+'" type="hidden" value="0" '+s+">\n<input "+l.a.raw(a.join(" "))+" />")},toPercentage:function(e){return parseInt(100*e)+"%"},toPrecision:function(e,t){return e?parseFloat(e).toPrecision(t):""},checkedIf:function(e,t,a){return 3===arguments.length?e===t?"checked":"":e?"checked":""},selectedIf:function(e,t,a){return 3===arguments.length?e===t?"selected":"":e?"selected":""},disabledIf:function(e,t){return e?"disabled":""},readonlyIf:function(e,t){return e?"readonly":""},checkedUnless:function(e){return e?"":"checked"},join:function(e,t,a){null==t&&(t=",")
if(!e)return""
return e.join(t)},ifIncludes:function(e,t,a){if(!e)return false
return N.call(e,t)>=0?a.fn(this):a.inverse(this)},disabledIfIncludes:function(e,t){if(!e)return""
return N.call(e,t)>=0?"disabled":""},truncate_left:function(e,t){return M.Utils.escapeExpression(y["a"].truncateText(e.split("").reverse().join(""),{max:t}).split("").reverse().join(""))},truncate:function(e,t){return M.Utils.escapeExpression(y["a"].truncateText(e,{max:t}))},escape_html:function(e){return Object(h["a"])(e)},enrollmentName:d,list:function(e,t){var a,n,r,s,i,o,d
f.a.defaults(t.hash,{separator:", ",propName:null,limit:null,end:"..."})
s=t.hash,r=s.propName,n=s.limit,a=s.end,o=s.separator
i=f.a.map(e,(function(e){return r?e[r]:e}))
n&&(i=i.slice(0,n))
d=i.join(o)
return n&&e.length>n?""+d+a:d},titleize:function(e){var t,a
if(!e)return""
a=e.split(/[ _]+/)
t=f()(a).map((function(e){return e[0].toUpperCase()+e.slice(1)}))
return t.join(" ")},uniqid:function(e){var t
arguments.length<=1&&(e=this||window)
if(!e._uniqid_){t="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
e._uniqid_=function(){var e,a
a=[]
for(e=1;e<=8;e++)a.push(t.charAt(Math.floor(Math.random()*t.length)))
return a}().join("")}return e._uniqid_},view:function(e){var t,a,n
a=function(e){return(window.requestAnimationFrame||setTimeout)(e,0)}
t="placeholder-"+l.a.guid++
n=function(){var r
r=l()("#"+t)
return r.length?r.replaceWith(e.$el):a(n)}
e.render()
a(n)
return new M.SafeString('<span id="'+t+'">pk</span>')},or:function(){var e,t,a,n,r
t=2<=arguments.length?Y.call(arguments,0,a=arguments.length-1):(a=0,[]),arguments[a++]
for(n=0,r=t.length;n<r;n++){e=t[n]
if(e)return e}},addMasteryIcon:function(e,t){var a
null==t&&(t={})
a={exceeds:"check-plus",mastery:"check",near:"plus"}[e]||"x"
return new M.SafeString("<i aria-hidden='true' class='icon-"+Object(h["a"])(a)+"'></i>")},ifGreaterThan:function(e,t,a){return e>t?a.fn(this):a.inverse(this)},n:function(e,t){var a,n,s,i
s=t.hash,n=s.precision,a=s.percentage,i=s.strip_insignificant_zeros
return r["default"].n(e,{precision:n,percentage:a,strip_insignificant_zeros:i})},nf:function(e,t){var a
a=t.hash.format
return x["a"][a](e)},lookup:function(e,t){return e&&e[t]}}
for(S in T){A=T[S]
M.registerHelper(S,A)}t["a"]=M},g1Ui:function(e,t,a){"use strict"
var n=a("pQTu")
const r={_format(e,t){if("number"!==typeof e||isNaN(e))return e
return n["default"].n(e,t)},outcomeScore:e=>r._format(e,{precision:2,strip_insignificant_zeros:true})}
t["a"]=r},h9kl:function(e,t,a){"use strict"
var n=a("BEYS")
var r=a("scbj")["default"]
var s=a("tpBh")["default"]
var i=a("sTlx")
var o=a("vRmd")
var d=function(){var e=new n.HandlebarsEnvironment
i.extend(e,n)
e.SafeString=r
e.Exception=s
e.Utils=i
e.VM=o
e.template=function(t){return o.template(t,e)}
return e}
var _=d()
_.create=d
t["default"]=_},sTlx:function(e,t,a){"use strict"
var n=a("scbj")["default"]
var r={"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#x27;","`":"&#x60;"}
var s=/[&<>"'`]/g
var i=/[&<>"'`]/
function o(e){return r[e]||"&amp;"}function d(e,t){for(var a in t)Object.prototype.hasOwnProperty.call(t,a)&&(e[a]=t[a])}t.extend=d
var _=Object.prototype.toString
t.toString=_
var c=function(e){return"function"===typeof e}
c(/x/)&&(c=function(e){return"function"===typeof e&&"[object Function]"===_.call(e)})
t.isFunction=c
var u=Array.isArray||function(e){return!(!e||"object"!==typeof e)&&"[object Array]"===_.call(e)}
t.isArray=u
function l(e){if(e instanceof n)return e.toString()
if(!e&&0!==e)return""
e=""+e
if(!i.test(e))return e
return e.replace(s,o)}t.escapeExpression=l
function m(e){return!e&&0!==e||!(!u(e)||0!==e.length)}t.isEmpty=m},sVap:function(e,t,a){"use strict"
var n=a("pQTu")
var r=a("m0r6")
Object(r["a"])(JSON.parse('{"ar":{"archive_3f794d7e":"أرشيف","audio_dd489fcc":"صوت","flash_6afbf65a":"Flash","image_8ad06":"الصورة","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"نص عادي","presentation_2d9387ca":"عرض تقديمي","source_code_2395ca74":"رمز المصدر","spreadsheet_6d622119":"جدول بيانات","text_document_eacbcdb7":"مستند نصي","unknown_47a3b725":"غير معروف","video_b9f27375":"فيديو","web_page_146f9102":"صفحة الويب"},"cy":{"archive_3f794d7e":"Archifo","audio_dd489fcc":"Sain","flash_6afbf65a":"Flash","image_8ad06":"Delwedd","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Testun plaen","presentation_2d9387ca":"Cyflwyniad","source_code_2395ca74":"Cod ffynhonnell","spreadsheet_6d622119":"Taenlen","text_document_eacbcdb7":"Dogfen Testun","unknown_47a3b725":"Dieithr","video_b9f27375":"Fideo","web_page_146f9102":"Tudalen we"},"da":{"archive_3f794d7e":"Arkiv","audio_dd489fcc":"Lyd","flash_6afbf65a":"Flash","image_8ad06":"Billede","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Almindelig tekst","presentation_2d9387ca":"Præsentation","source_code_2395ca74":"Kildekode","spreadsheet_6d622119":"Regneark","text_document_eacbcdb7":"Tekstdokument","unknown_47a3b725":"Ukendt","video_b9f27375":"Video","web_page_146f9102":"Webside"},"da-x-k12":{"archive_3f794d7e":"Arkiv","audio_dd489fcc":"Lyd","flash_6afbf65a":"Flash","image_8ad06":"Billede","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Almindelig tekst","presentation_2d9387ca":"Præsentation","source_code_2395ca74":"Kildekode","spreadsheet_6d622119":"Regneark","text_document_eacbcdb7":"Tekstdokument","unknown_47a3b725":"Ukendt","video_b9f27375":"Video","web_page_146f9102":"Webside"},"de":{"archive_3f794d7e":"Archivieren","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Bild","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Nur-Text","presentation_2d9387ca":"Präsentation","source_code_2395ca74":"Quellcode","spreadsheet_6d622119":"Tabellenblatt","text_document_eacbcdb7":"Textdokument","unknown_47a3b725":"Unbekannt","video_b9f27375":"Video","web_page_146f9102":"Webseite"},"el":{"archive_3f794d7e":"Αρχείο","audio_dd489fcc":"Αρχείο ήχου","flash_6afbf65a":"Flash","image_8ad06":"Εικόνα","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Απλό κείμενο","presentation_2d9387ca":"Παρουσίαση","source_code_2395ca74":"Πηγαίος κώδικας","spreadsheet_6d622119":"Λογιστικό φύλλο","text_document_eacbcdb7":"Έγγραφο κειμένου","unknown_47a3b725":"Άγνωστο","video_b9f27375":"Αρχείο Βίντεο","web_page_146f9102":"Ιστοσελίδα"},"en-AU":{"archive_3f794d7e":"Archive","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Image","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Plain text","presentation_2d9387ca":"Presentation","source_code_2395ca74":"Source code","spreadsheet_6d622119":"Spreadsheet","text_document_eacbcdb7":"Text document","unknown_47a3b725":"Unknown","video_b9f27375":"Video","web_page_146f9102":"Web page"},"en-CA":{"archive_3f794d7e":"Archive","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Image","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Plain text","presentation_2d9387ca":"Presentation","source_code_2395ca74":"Source code","spreadsheet_6d622119":"Spreadsheet","text_document_eacbcdb7":"Text document","unknown_47a3b725":"Unknown","video_b9f27375":"Video","web_page_146f9102":"Web page"},"en-GB":{"archive_3f794d7e":"Archive","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Image","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Plain text","presentation_2d9387ca":"Presentation","source_code_2395ca74":"Source code","spreadsheet_6d622119":"Spreadsheet","text_document_eacbcdb7":"Text document","unknown_47a3b725":"Unknown","video_b9f27375":"Video","web_page_146f9102":"Web page"},"es":{"archive_3f794d7e":"Archivar","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Imagen","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Texto sin formato","presentation_2d9387ca":"Presentación","source_code_2395ca74":"Código fuente","spreadsheet_6d622119":"Hoja de cálculo","text_document_eacbcdb7":"Documento de texto","unknown_47a3b725":"Desconocido","video_b9f27375":"Video","web_page_146f9102":"Página web"},"fa":{"archive_3f794d7e":"بایگانی","audio_dd489fcc":"صدا","flash_6afbf65a":"فلش","image_8ad06":"تصویر","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"متن ساده","presentation_2d9387ca":"ارائه","source_code_2395ca74":"رمز منبع","spreadsheet_6d622119":"صفحه گسترده","text_document_eacbcdb7":"سند متنی","unknown_47a3b725":"ناشناس","video_b9f27375":"تصویر","web_page_146f9102":"صفحه وب"},"fi":{"archive_3f794d7e":"Arkisto","audio_dd489fcc":"Ääni","flash_6afbf65a":"Flash","image_8ad06":"Kuva","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Pelkkä teksti","presentation_2d9387ca":"Esitys","source_code_2395ca74":"Lähteen koodi","spreadsheet_6d622119":"Työkirja","text_document_eacbcdb7":"Tekstiasiakirja","unknown_47a3b725":"Tuntematon","video_b9f27375":"Video","web_page_146f9102":"Verkkosivusto"},"fr":{"archive_3f794d7e":"Archiver","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Image","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Texte brut","presentation_2d9387ca":"Présentation","source_code_2395ca74":"Code source","spreadsheet_6d622119":"Feuille","text_document_eacbcdb7":"Document de texte","unknown_47a3b725":"Inconnu","video_b9f27375":"Vidéo","web_page_146f9102":"Page Web"},"fr-CA":{"archive_3f794d7e":"Archiver","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Image","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Texte brut","presentation_2d9387ca":"Présentation","source_code_2395ca74":"Code source","spreadsheet_6d622119":"Feuille","text_document_eacbcdb7":"Document de texte","unknown_47a3b725":"Inconnu","video_b9f27375":"Vidéo","web_page_146f9102":"Page Web"},"he":{"archive_3f794d7e":"העברה לארכיון","audio_dd489fcc":"שמע","flash_6afbf65a":"פלאש","image_8ad06":"תמונה","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"כיתוב פשוט","presentation_2d9387ca":"מצגת","source_code_2395ca74":"קוד מקור","spreadsheet_6d622119":"גיליון חישובים","text_document_eacbcdb7":"מסמך מלל","unknown_47a3b725":"לא מוכר","video_b9f27375":"וידאו","web_page_146f9102":"דף אינטרנט"},"ht":{"archive_3f794d7e":"Achiv","audio_dd489fcc":"Son","flash_6afbf65a":"Flash","image_8ad06":"Imaj","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Tèks brit","presentation_2d9387ca":"Prezantasyon","source_code_2395ca74":"Kòd sous","spreadsheet_6d622119":"Fèy Kalkil","text_document_eacbcdb7":"Dokiman Tèks","unknown_47a3b725":"Enkoni","video_b9f27375":"Videyo","web_page_146f9102":"Paj web"},"hu":{"archive_3f794d7e":"Archívum","audio_dd489fcc":"Hang","flash_6afbf65a":"Flash","image_8ad06":"Kép","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Egyszerű szöveg","presentation_2d9387ca":"Prezentáció","source_code_2395ca74":"Forráskód","spreadsheet_6d622119":"Táblázat","text_document_eacbcdb7":"Szöveges dokumentum","unknown_47a3b725":"Ismeretlen","video_b9f27375":"Videó","web_page_146f9102":"Weboldal "},"hy":{"archive_3f794d7e":"Արխիվ","audio_dd489fcc":"Աուդիո","flash_6afbf65a":"Flash","image_8ad06":"Պատկեր","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Սովորական տեքստ","presentation_2d9387ca":"Պրեզենտացիա","source_code_2395ca74":"Աղբյուրի կոդ","spreadsheet_6d622119":"Էլեկտրոնային աղյուսակ","text_document_eacbcdb7":"Տեքստային փաստաթուղթ","unknown_47a3b725":"Անհայտ է","video_b9f27375":"Վիդեո","web_page_146f9102":"Վեբ-էջ"},"is":{"archive_3f794d7e":"Safn","audio_dd489fcc":"Hljóð","flash_6afbf65a":"Flash","image_8ad06":"Mynd","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Einfaldur texti","presentation_2d9387ca":"Kynning","source_code_2395ca74":"Frumkóði","spreadsheet_6d622119":"Töflureiknir","text_document_eacbcdb7":"Textaskjal","unknown_47a3b725":"Óþekkt","video_b9f27375":"Myndband","web_page_146f9102":"Vefsíða"},"it":{"archive_3f794d7e":"Archivia","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Immagine","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Testo normale","presentation_2d9387ca":"Presentazione","source_code_2395ca74":"Codice sorgente","spreadsheet_6d622119":"Foglio di calcolo","text_document_eacbcdb7":"Documento di testo","unknown_47a3b725":"Sconosciuto","video_b9f27375":"Video","web_page_146f9102":"Pagina web"},"ja":{"archive_3f794d7e":"アーカイブ","audio_dd489fcc":"オーディオ","flash_6afbf65a":"Flash","image_8ad06":"画像","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"プレーン テキスト","presentation_2d9387ca":"プレゼンテーション","source_code_2395ca74":"ソース コード","spreadsheet_6d622119":"スプレッドシート","text_document_eacbcdb7":"テキスト文書","unknown_47a3b725":"不明","video_b9f27375":"ビデオ","web_page_146f9102":"Web ページ"},"ko":{"archive_3f794d7e":"저장소","image_8ad06":"이미지","unknown_47a3b725":"알 수 없음"},"mi":{"archive_3f794d7e":"Pūranga","audio_dd489fcc":"Ōrorongo","flash_6afbf65a":"Flash","image_8ad06":"Āhua","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"kuputuhi tōkau","presentation_2d9387ca":"Whakāturanga","source_code_2395ca74":"waehere pūtake","spreadsheet_6d622119":"Ripanga","text_document_eacbcdb7":"tuhinga Kupu","unknown_47a3b725":"Kaore e mōhiotia","video_b9f27375":"Ataata","web_page_146f9102":"whārangi Tukutuku"},"nb":{"archive_3f794d7e":"Arkiv","audio_dd489fcc":"Lyd","flash_6afbf65a":"Blitz","image_8ad06":"Bilde","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Enkel tekst","presentation_2d9387ca":"Presentasjon","source_code_2395ca74":"kilde kode","spreadsheet_6d622119":"Regneark","text_document_eacbcdb7":"Tekst dokument","unknown_47a3b725":"Ukjent","video_b9f27375":"Video","web_page_146f9102":"Nettside"},"nb-x-k12":{"archive_3f794d7e":"Arkiv","audio_dd489fcc":"Lyd","flash_6afbf65a":"Blitz","image_8ad06":"Bilde","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Enkel tekst","presentation_2d9387ca":"Presentasjon","source_code_2395ca74":"kilde kode","spreadsheet_6d622119":"Regneark","text_document_eacbcdb7":"Tekst dokument","unknown_47a3b725":"Ukjent","video_b9f27375":"Video","web_page_146f9102":"Nettside"},"nl":{"archive_3f794d7e":"Archiveren","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash ","image_8ad06":"Afbeelding","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Tekst zonder opmaak","presentation_2d9387ca":"Presentatie","source_code_2395ca74":"Broncode","spreadsheet_6d622119":"Werkblad","text_document_eacbcdb7":"Tekstdocument","unknown_47a3b725":"Onbekend","video_b9f27375":"Video ","web_page_146f9102":"webpagina"},"nn":{"archive_3f794d7e":"Arkiv","audio_dd489fcc":"Lyd","flash_6afbf65a":"Flash","image_8ad06":"Bilde","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Rein tekst","presentation_2d9387ca":"Presentasjon","source_code_2395ca74":"Kjeldekode","spreadsheet_6d622119":"Rekneark","text_document_eacbcdb7":"Tekstdokument","unknown_47a3b725":"Ukjent","video_b9f27375":"Video","web_page_146f9102":"Nettside"},"pl":{"archive_3f794d7e":"Archiwum","audio_dd489fcc":"Audio","flash_6afbf65a":"Flash","image_8ad06":"Obraz","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Zwykły tekst","presentation_2d9387ca":"Prezentacja","source_code_2395ca74":"Kod źródłowy","spreadsheet_6d622119":"Arkusz kalkulacyjny","text_document_eacbcdb7":"Dokument tekstowy","unknown_47a3b725":"Nieznany","video_b9f27375":"Wideo","web_page_146f9102":"Strona sieci Web"},"pt":{"archive_3f794d7e":"Arquivar","audio_dd489fcc":"Áudio","flash_6afbf65a":"Flash","image_8ad06":"Imagem","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Texto simples","presentation_2d9387ca":"Apresentação","source_code_2395ca74":"Código-fonte","spreadsheet_6d622119":"Folha de cálculo","text_document_eacbcdb7":"Documento de texto","unknown_47a3b725":"Desconhecido","video_b9f27375":"Vídeo","web_page_146f9102":"Página Web"},"pt-BR":{"archive_3f794d7e":"Arquivar","audio_dd489fcc":"Áudio","flash_6afbf65a":"Flash","image_8ad06":"Imagem","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Texto simples","presentation_2d9387ca":"Apresentação","source_code_2395ca74":"Código-fonte","spreadsheet_6d622119":"Planilha","text_document_eacbcdb7":"Documento de texto","unknown_47a3b725":"Desconhecido","video_b9f27375":"Vídeo","web_page_146f9102":"Página Web"},"ru":{"archive_3f794d7e":"Архив","audio_dd489fcc":"Аудио","flash_6afbf65a":"Flash","image_8ad06":"Изображение","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Обычный текст","presentation_2d9387ca":"Презентация","source_code_2395ca74":"Код источника","spreadsheet_6d622119":"Динамическая таблица","text_document_eacbcdb7":"Текстовый документ","unknown_47a3b725":"Неизвестно","video_b9f27375":"Видео","web_page_146f9102":"Веб-страница"},"sl":{"archive_3f794d7e":"Arhiviraj","audio_dd489fcc":"Zvok","flash_6afbf65a":"Flash","image_8ad06":"Slika","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Navadno besedilo","presentation_2d9387ca":"Predstavitev","source_code_2395ca74":"Izvorna koda","spreadsheet_6d622119":"Preglednica","text_document_eacbcdb7":"Besedilni dokument","unknown_47a3b725":"Neznano","video_b9f27375":"Videoposnetek","web_page_146f9102":"Spletna stran"},"sv":{"archive_3f794d7e":"Arkivera","audio_dd489fcc":"Ljud","flash_6afbf65a":"Flash","image_8ad06":"Bild","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Oformaterad text","presentation_2d9387ca":"Presentation","source_code_2395ca74":"Källkod","spreadsheet_6d622119":"Kalkylblad","text_document_eacbcdb7":"Textdokument","unknown_47a3b725":"Okänd","video_b9f27375":"Video","web_page_146f9102":"Webbsida"},"sv-x-k12":{"archive_3f794d7e":"Arkivera","audio_dd489fcc":"Ljud","flash_6afbf65a":"Flash","image_8ad06":"Bild","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Oformaterad text","presentation_2d9387ca":"Presentation","source_code_2395ca74":"Källkod","spreadsheet_6d622119":"Kalkylblad","text_document_eacbcdb7":"Textdokument","unknown_47a3b725":"Okänd","video_b9f27375":"Video","web_page_146f9102":"Webbsida"},"tr":{"archive_3f794d7e":"Arşiv","audio_dd489fcc":"Ses","flash_6afbf65a":"Flash","image_8ad06":"Resim","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"Düz metin","presentation_2d9387ca":"Sunum","source_code_2395ca74":"Kaynak kodu","spreadsheet_6d622119":"Elektronik Tablo","text_document_eacbcdb7":"Metin belgesi","unknown_47a3b725":"Bilinmiyor","video_b9f27375":"Video","web_page_146f9102":"Web sayfası"},"uk":{"archive_3f794d7e":"Архів","audio_dd489fcc":"Звук","flash_6afbf65a":"Флеш","image_8ad06":"Зображення","pdf_d8236d9a":"Формат PDF","plain_text_e3ab33aa":"Простий текст","presentation_2d9387ca":"Презентація","source_code_2395ca74":"Вихідний код","spreadsheet_6d622119":"Електронна таблиця","text_document_eacbcdb7":"Текстовий документ","unknown_47a3b725":"Невідомий","video_b9f27375":"Відео","web_page_146f9102":"Веб-сторінка"},"zh-Hans":{"archive_3f794d7e":"存档","audio_dd489fcc":"音频","flash_6afbf65a":"Flash","image_8ad06":"图像","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"纯文本","presentation_2d9387ca":"展示","source_code_2395ca74":"源代码","spreadsheet_6d622119":"电子表格","text_document_eacbcdb7":"文本文档","unknown_47a3b725":"未知","video_b9f27375":"视频","web_page_146f9102":"网页"},"zh-Hant":{"archive_3f794d7e":"存檔","audio_dd489fcc":"音頻","flash_6afbf65a":"Flash","image_8ad06":"影像","pdf_d8236d9a":"PDF","plain_text_e3ab33aa":"純文字","presentation_2d9387ca":"簡報","source_code_2395ca74":"源代碼","spreadsheet_6d622119":"电子表格","text_document_eacbcdb7":"文本文件","unknown_47a3b725":"未知","video_b9f27375":"視訊","web_page_146f9102":"網頁"}}'))
a("jQeR")
a("0sPK")
var s=n["default"].scoped("mimeClass")
a.d(t,"a",(function(){return o}))
const i={audio:{get displayName(){return s.t("Audio")},mimeTypes:["audio/x-mpegurl","audio/x-pn-realaudio","audio/x-aiff","audio/3gpp","audio/mid","audio/x-wav","audio/basic","audio/mpeg"]},code:{get displayName(){return s.t("Source code")},mimeTypes:["text/xml","text/css","text/x-yaml","application/xml","application/javascript","text/x-csharp"]},doc:{get displayName(){return s.t("Text document")},mimeTypes:["application/x-docx","text/rtf","application/msword","application/rtf","application/vnd.oasis.opendocument.text","application/vnd.openxmlformats-officedocument.wordprocessingml.document"]},flash:{get displayName(){return s.t("Flash")},mimeTypes:["application/x-shockwave-flash"]},html:{get displayName(){return s.t("Web page")},mimeTypes:["text/html","application/xhtml+xml"]},image:{get displayName(){return s.t("Image")},mimeTypes:["image/png","image/x-psd","image/gif","image/pjpeg","image/jpeg"]},ppt:{get displayName(){return s.t("Presentation")},mimeTypes:["application/vnd.openxmlformats-officedocument.presentationml.presentation","application/vnd.ms-powerpoint"]},pdf:{get displayName(){return s.t("PDF")},mimeTypes:["application/pdf"]},text:{get displayName(){return s.t("Plain text")},mimeTypes:["text","text/plain"]},video:{get displayName(){return s.t("Video")},mimeTypes:["video/mp4","video/x-ms-asf","video/x-msvideo","video/x-sgi-movie","video/mpeg","video/quicktime","video/x-la-asf","video/3gpp"]},xls:{get displayName(){return s.t("Spreadsheet")},mimeTypes:["application/vnd.oasis.opendocument.spreadsheet","text/csv","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-excel"]},zip:{get displayName(){return s.t("Archive")},mimeTypes:["application/x-rar-compressed","application/x-zip-compressed","application/zip","application/x-zip","application/x-rar"]}}
function o(e){return o.mimeClasses[e]||"file"}o.displayName=function(e){const t=i[o(e)]
return t&&t.displayName||s.t("Unknown")}
o.mimeClasses={}
for(const e in i){const t=i[e]
t.mimeTypes.forEach(t=>o.mimeClasses[t]=e)}},scbj:function(e,t,a){"use strict"
function n(e){this.string=e}n.prototype.toString=function(){return""+this.string}
t["default"]=n},tpBh:function(e,t,a){"use strict"
var n=["description","fileName","lineNumber","message","name","number","stack"]
function r(e,t){var a
if(t&&t.firstLine){a=t.firstLine
e+=" - "+a+":"+t.firstColumn}var r=Error.prototype.constructor.call(this,e)
for(var s=0;s<n.length;s++)this[n[s]]=r[n[s]]
if(a){this.lineNumber=a
this.column=t.firstColumn}}r.prototype=new Error
t["default"]=r},"u/6C":function(e,t,a){"use strict"
var n=a("pQTu")
var r=a("m0r6")
Object(r["a"])(JSON.parse('{"ar":{"dates":{"no_date":"بلا تاريخ"}},"cy":{"dates":{"no_date":"Dim Dyddiad"}},"da":{"dates":{"no_date":"Ingen dato"}},"da-x-k12":{"dates":{"no_date":"Ingen dato"}},"de":{"dates":{"no_date":"Kein Datum"}},"el":{"dates":{"no_date":"Δεν υπάρχει Ημερομηνία"}},"en-AU":{"dates":{"no_date":"No Date"}},"en-CA":{"dates":{"no_date":"No Date"}},"en-GB":{"dates":{"no_date":"No date"}},"es":{"dates":{"no_date":"Sin fecha"}},"fa":{"dates":{"no_date":"تاریخ موجود نیست"}},"fi":{"dates":{"no_date":"Ei päivämäärää"}},"fr":{"dates":{"no_date":"Aucune date"}},"fr-CA":{"dates":{"no_date":"Aucune date"}},"he":{"dates":{"no_date":"אין תאריך"}},"ht":{"dates":{"no_date":"San Dat"}},"hu":{"dates":{"no_date":"Nincs dátum"}},"hy":{"dates":{"no_date":"Տվյալներ չկան"}},"is":{"dates":{"no_date":"Engin dagsetning"}},"it":{"dates":{"no_date":"Nessuna data"}},"ja":{"dates":{"no_date":"日付なし"}},"ko":{"dates":{"no_date":"날짜 없음"}},"mi":{"dates":{"no_date":"Kāore he rā"}},"nb":{"dates":{"no_date":"Ingen dato"}},"nb-x-k12":{"dates":{"no_date":"Ingen dato"}},"nl":{"dates":{"no_date":"Geen datum"}},"nn":{"dates":{"no_date":"Ingen dato"}},"pl":{"dates":{"no_date":"Brak daty"}},"pt":{"dates":{"no_date":"Sem data"}},"pt-BR":{"dates":{"no_date":"Sem Data"}},"ru":{"dates":{"no_date":"Отсутствует дата"}},"sl":{"dates":{"no_date":"Brez datuma"}},"sv":{"dates":{"no_date":"Inget datum"}},"sv-x-k12":{"dates":{"no_date":"Inget datum"}},"tr":{"dates":{"no_date":"Tarih Yok"}},"uk":{"dates":{"no_date":"Дата відсутня"}},"zh-Hans":{"dates":{"no_date":"无日期"}},"zh-Hant":{"dates":{"no_date":"無日期"}}}'))
a("jQeR")
a("0sPK")
var s=n["default"].scoped("dates")
var i=a("ouhR")
var o=a.n(i)
var d=a("2DhO")
var _=a("5Ky4")
a("UlQx")
a.d(t,"a",(function(){return c}))
function c(e,t){if(!e)return'<span class="date-range date-range-no-date">\n  '.concat(Object(_["a"])(s.t("no_date","No Date")),"\n</span>")
const a=d["a"].parse(e)
const n=d["a"].parse(t)
return+a!==+n?o.a.sameDate(a,n)?'<span class="date-range">\n  <time datetime=\''.concat(a.toISOString(),"'>\n    ").concat(o.a.dateString(a),", ").concat(o.a.timeString(a),"\n  </time> -\n  <time datetime='").concat(n.toISOString(),"'>\n    ").concat(o.a.timeString(n),"\n  </time>\n</span>"):'<span class="date-range">\n  <time datetime=\''.concat(a.toISOString(),"'>\n    ").concat(o.a.datetimeString(a),"\n  </time> -\n  <time datetime='").concat(n.toISOString(),"'>\n    ").concat(o.a.datetimeString(n),"\n  </time>\n</span>"):'<span class="date-range">\n  <time datetime=\''.concat(a.toISOString(),"'>\n    ").concat(o.a.datetimeString(a),"\n  </time>\n</span>")}},vRmd:function(e,t,a){"use strict"
var n=a("sTlx")
var r=a("tpBh")["default"]
var s=a("BEYS").COMPILER_REVISION
var i=a("BEYS").REVISION_CHANGES
function o(e){var t=e&&e[0]||1,a=s
if(t!==a){if(t<a){var n=i[a],o=i[t]
throw new r("Template was precompiled with an older version of Handlebars than the current runtime. Please update your precompiler to a newer version ("+n+") or downgrade your runtime to an older version ("+o+").")}throw new r("Template was precompiled with a newer version of Handlebars than the current runtime. Please update your runtime to a newer version ("+e[1]+").")}}t.checkRevision=o
function d(e,t){if(!t)throw new r("No environment passed to template")
var a=function(e,a,n,s,i,o){var d=t.VM.invokePartial.apply(this,arguments)
if(null!=d)return d
if(t.compile){var _={helpers:s,partials:i,data:o}
i[a]=t.compile(e,{data:void 0!==o},t)
return i[a](n,_)}throw new r("The partial "+a+" could not be compiled when running in runtime-only mode")}
var s={escapeExpression:n.escapeExpression,invokePartial:a,programs:[],program:function(e,t,a){var n=this.programs[e]
a?n=c(e,t,a):n||(n=this.programs[e]=c(e,t))
return n},merge:function(e,t){var a=e||t
if(e&&t&&e!==t){a={}
n.extend(a,t)
n.extend(a,e)}return a},programWithDepth:t.VM.programWithDepth,noop:t.VM.noop,compilerInfo:null}
return function(a,n){n=n||{}
var r,i,o=n.partial?n:t
if(!n.partial){r=n.helpers
i=n.partials}var d=e.call(s,o,a,r,i,n.data)
n.partial||t.VM.checkRevision(s.compilerInfo)
return d}}t.template=d
function _(e,t,a){var n=Array.prototype.slice.call(arguments,3)
var r=function(e,r){r=r||{}
return t.apply(this,[e,r.data||a].concat(n))}
r.program=e
r.depth=n.length
return r}t.programWithDepth=_
function c(e,t,a){var n=function(e,n){n=n||{}
return t(e,n.data||a)}
n.program=e
n.depth=0
return n}t.program=c
function u(e,t,a,n,s,i){var o={partial:true,helpers:n,partials:s,data:i}
if(void 0===e)throw new r("The partial "+t+" could not be found")
if(e instanceof Function)return e(a,o)}t.invokePartial=u
function l(){return""}t.noop=l}}])

//# sourceMappingURL=3-c-4807ad1f8d.js.map