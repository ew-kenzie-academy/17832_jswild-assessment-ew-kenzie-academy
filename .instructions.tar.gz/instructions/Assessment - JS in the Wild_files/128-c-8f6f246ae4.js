(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[128],{"1I77":function(e,t,n){"use strict"
n.d(t,"a",(function(){return o}))
var r=n("i/8D")
function o(){return!!r["a"]&&"objectFit"in document.documentElement.style!==false}},"2LKJ":function(e,t,n){e.exports=v
v.Minimatch=g
var r={sep:"/"}
try{r=n("33yf")}catch(e){}var o=v.GLOBSTAR=g.GLOBSTAR={}
var i=n("TuBq")
var a={"!":{open:"(?:(?!(?:",close:"))[^/]*?)"},"?":{open:"(?:",close:")?"},"+":{open:"(?:",close:")+"},"*":{open:"(?:",close:")*"},"@":{open:"(?:",close:")"}}
var c="[^/]"
var s=c+"*?"
var l="(?:(?!(?:\\/|^)(?:\\.{1,2})($|\\/)).)*?"
var u="(?:(?!(?:\\/|^)\\.).)*?"
var d=p("().*{}+?[]^$\\!")
function p(e){return e.split("").reduce((function(e,t){e[t]=true
return e}),{})}var h=/\/+/
v.filter=f
function f(e,t){t=t||{}
return function(n,r,o){return v(n,e,t)}}function b(e,t){e=e||{}
t=t||{}
var n={}
Object.keys(t).forEach((function(e){n[e]=t[e]}))
Object.keys(e).forEach((function(t){n[t]=e[t]}))
return n}v.defaults=function(e){if(!e||!Object.keys(e).length)return v
var t=v
var n=function(n,r,o){return t.minimatch(n,r,b(e,o))}
n.Minimatch=function(n,r){return new t.Minimatch(n,b(e,r))}
return n}
g.defaults=function(e){if(!e||!Object.keys(e).length)return g
return v.defaults(e).Minimatch}
function v(e,t,n){if("string"!==typeof t)throw new TypeError("glob pattern string required")
n||(n={})
if(!n.nocomment&&"#"===t.charAt(0))return false
if(""===t.trim())return""===e
return new g(t,n).match(e)}function g(e,t){if(!(this instanceof g))return new g(e,t)
if("string"!==typeof e)throw new TypeError("glob pattern string required")
t||(t={})
e=e.trim()
"/"!==r.sep&&(e=e.split(r.sep).join("/"))
this.options=t
this.set=[]
this.pattern=e
this.regexp=null
this.negate=false
this.comment=false
this.empty=false
this.make()}g.prototype.debug=function(){}
g.prototype.make=y
function y(){if(this._made)return
var e=this.pattern
var t=this.options
if(!t.nocomment&&"#"===e.charAt(0)){this.comment=true
return}if(!e){this.empty=true
return}this.parseNegate()
var n=this.globSet=this.braceExpand()
t.debug&&(this.debug=console.error)
this.debug(this.pattern,n)
n=this.globParts=n.map((function(e){return e.split(h)}))
this.debug(this.pattern,n)
n=n.map((function(e,t,n){return e.map(this.parse,this)}),this)
this.debug(this.pattern,n)
n=n.filter((function(e){return-1===e.indexOf(false)}))
this.debug(this.pattern,n)
this.set=n}g.prototype.parseNegate=m
function m(){var e=this.pattern
var t=false
var n=this.options
var r=0
if(n.nonegate)return
for(var o=0,i=e.length;o<i&&"!"===e.charAt(o);o++){t=!t
r++}r&&(this.pattern=e.substr(r))
this.negate=t}v.braceExpand=function(e,t){return j(e,t)}
g.prototype.braceExpand=j
function j(e,t){t||(t=this instanceof g?this.options:{})
e="undefined"===typeof e?this.pattern:e
if("undefined"===typeof e)throw new TypeError("undefined pattern")
if(t.nobrace||!e.match(/\{.*\}/))return[e]
return i(e)}g.prototype.parse=U
var _={}
function U(e,t){if(e.length>65536)throw new TypeError("pattern is too long")
var n=this.options
if(!n.noglobstar&&"**"===e)return o
if(""===e)return""
var r=""
var i=!!n.nocase
var l=false
var u=[]
var p=[]
var h
var f=false
var b=-1
var v=-1
var g="."===e.charAt(0)?"":n.dot?"(?!(?:^|\\/)\\.{1,2}(?:$|\\/))":"(?!\\.)"
var y=this
function m(){if(h){switch(h){case"*":r+=s
i=true
break
case"?":r+=c
i=true
break
default:r+="\\"+h}y.debug("clearStateChar %j %j",h,r)
h=false}}for(var j,U=0,k=e.length;U<k&&(j=e.charAt(U));U++){this.debug("%s\t%s %s %j",e,U,r,j)
if(l&&d[j]){r+="\\"+j
l=false
continue}switch(j){case"/":return false
case"\\":m()
l=true
continue
case"?":case"*":case"+":case"@":case"!":this.debug("%s\t%s %s %j <-- stateChar",e,U,r,j)
if(f){this.debug("  in class")
"!"===j&&U===v+1&&(j="^")
r+=j
continue}y.debug("call clearStateChar %j",h)
m()
h=j
n.noext&&m()
continue
case"(":if(f){r+="("
continue}if(!h){r+="\\("
continue}u.push({type:h,start:U-1,reStart:r.length,open:a[h].open,close:a[h].close})
r+="!"===h?"(?:(?!(?:":"(?:"
this.debug("plType %j %j",h,r)
h=false
continue
case")":if(f||!u.length){r+="\\)"
continue}m()
i=true
var B=u.pop()
r+=B.close
"!"===B.type&&p.push(B)
B.reEnd=r.length
continue
case"|":if(f||!u.length||l){r+="\\|"
l=false
continue}m()
r+="|"
continue
case"[":m()
if(f){r+="\\"+j
continue}f=true
v=U
b=r.length
r+=j
continue
case"]":if(U===v+1||!f){r+="\\"+j
l=false
continue}if(f){var O=e.substring(v+1,U)
try{RegExp("["+O+"]")}catch(e){var x=this.parse(O,_)
r=r.substr(0,b)+"\\["+x[0]+"\\]"
i=i||x[1]
f=false
continue}}i=true
f=false
r+=j
continue
default:m()
l?l=false:!d[j]||"^"===j&&f||(r+="\\")
r+=j}}if(f){O=e.substr(v+1)
x=this.parse(O,_)
r=r.substr(0,b)+"\\["+x[0]
i=i||x[1]}for(B=u.pop();B;B=u.pop()){var C=r.slice(B.reStart+B.open.length)
this.debug("setting tail",r,B)
C=C.replace(/((?:\\{2}){0,64})(\\?)\|/g,(function(e,t,n){n||(n="\\")
return t+t+n+"|"}))
this.debug("tail=%j\n   %s",C,C,B,r)
var G="*"===B.type?s:"?"===B.type?c:"\\"+B.type
i=true
r=r.slice(0,B.reStart)+G+"\\("+C}m()
l&&(r+="\\\\")
var I=false
switch(r.charAt(0)){case".":case"[":case"(":I=true}for(var S=p.length-1;S>-1;S--){var L=p[S]
var F=r.slice(0,L.reStart)
var E=r.slice(L.reStart,L.reEnd-8)
var T=r.slice(L.reEnd-8,L.reEnd)
var R=r.slice(L.reEnd)
T+=R
var A=F.split("(").length-1
var z=R
for(U=0;U<A;U++)z=z.replace(/\)[+*?]?/,"")
R=z
var M=""
""===R&&t!==_&&(M="$")
var N=F+E+R+M+T
r=N}""!==r&&i&&(r="(?=.)"+r)
I&&(r=g+r)
if(t===_)return[r,i]
if(!i)return w(e)
var D=n.nocase?"i":""
try{var W=new RegExp("^"+r+"$",D)}catch(e){return new RegExp("$.")}W._glob=e
W._src=r
return W}v.makeRe=function(e,t){return new g(e,t||{}).makeRe()}
g.prototype.makeRe=k
function k(){if(this.regexp||false===this.regexp)return this.regexp
var e=this.set
if(!e.length){this.regexp=false
return this.regexp}var t=this.options
var n=t.noglobstar?s:t.dot?l:u
var r=t.nocase?"i":""
var i=e.map((function(e){return e.map((function(e){return e===o?n:"string"===typeof e?O(e):e._src})).join("\\/")})).join("|")
i="^(?:"+i+")$"
this.negate&&(i="^(?!"+i+").*$")
try{this.regexp=new RegExp(i,r)}catch(e){this.regexp=false}return this.regexp}v.match=function(e,t,n){n=n||{}
var r=new g(t,n)
e=e.filter((function(e){return r.match(e)}))
r.options.nonull&&!e.length&&e.push(t)
return e}
g.prototype.match=B
function B(e,t){this.debug("match",e,this.pattern)
if(this.comment)return false
if(this.empty)return""===e
if("/"===e&&t)return true
var n=this.options
"/"!==r.sep&&(e=e.split(r.sep).join("/"))
e=e.split(h)
this.debug(this.pattern,"split",e)
var o=this.set
this.debug(this.pattern,"set",o)
var i
var a
for(a=e.length-1;a>=0;a--){i=e[a]
if(i)break}for(a=0;a<o.length;a++){var c=o[a]
var s=e
n.matchBase&&1===c.length&&(s=[i])
var l=this.matchOne(s,c,t)
if(l){if(n.flipNegate)return true
return!this.negate}}if(n.flipNegate)return false
return this.negate}g.prototype.matchOne=function(e,t,n){var r=this.options
this.debug("matchOne",{this:this,file:e,pattern:t})
this.debug("matchOne",e.length,t.length)
for(var i=0,a=0,c=e.length,s=t.length;i<c&&a<s;i++,a++){this.debug("matchOne loop")
var l=t[a]
var u=e[i]
this.debug(t,l,u)
if(false===l)return false
if(l===o){this.debug("GLOBSTAR",[t,l,u])
var d=i
var p=a+1
if(p===s){this.debug("** at the end")
for(;i<c;i++)if("."===e[i]||".."===e[i]||!r.dot&&"."===e[i].charAt(0))return false
return true}while(d<c){var h=e[d]
this.debug("\nglobstar while",e,d,t,p,h)
if(this.matchOne(e.slice(d),t.slice(p),n)){this.debug("globstar found match!",d,c,h)
return true}if("."===h||".."===h||!r.dot&&"."===h.charAt(0)){this.debug("dot detected!",e,d,t,p)
break}this.debug("globstar swallow a segment, and continue")
d++}if(n){this.debug("\n>>> no match, partial?",e,d,t,p)
if(d===c)return true}return false}var f
if("string"===typeof l){f=r.nocase?u.toLowerCase()===l.toLowerCase():u===l
this.debug("string match",l,u,f)}else{f=u.match(l)
this.debug("pattern match",l,u,f)}if(!f)return false}if(i===c&&a===s)return true
if(i===c)return n
if(a===s){var b=i===c-1&&""===e[i]
return b}throw new Error("wtf?")}
function w(e){return e.replace(/\\(.)/g,"$1")}function O(e){return e.replace(/[-[\]{}()*+?.,\\^$|#\s]/g,"\\$&")}},"33yf":function(e,t,n){(function(e){function n(e,t){var n=0
for(var r=e.length-1;r>=0;r--){var o=e[r]
if("."===o)e.splice(r,1)
else if(".."===o){e.splice(r,1)
n++}else if(n){e.splice(r,1)
n--}}if(t)for(;n--;n)e.unshift("..")
return e}t.resolve=function(){var t="",r=false
for(var i=arguments.length-1;i>=-1&&!r;i--){var a=i>=0?arguments[i]:e.cwd()
if("string"!==typeof a)throw new TypeError("Arguments to path.resolve must be strings")
if(!a)continue
t=a+"/"+t
r="/"===a.charAt(0)}t=n(o(t.split("/"),(function(e){return!!e})),!r).join("/")
return(r?"/":"")+t||"."}
t.normalize=function(e){var r=t.isAbsolute(e),a="/"===i(e,-1)
e=n(o(e.split("/"),(function(e){return!!e})),!r).join("/")
e||r||(e=".")
e&&a&&(e+="/")
return(r?"/":"")+e}
t.isAbsolute=function(e){return"/"===e.charAt(0)}
t.join=function(){var e=Array.prototype.slice.call(arguments,0)
return t.normalize(o(e,(function(e,t){if("string"!==typeof e)throw new TypeError("Arguments to path.join must be strings")
return e})).join("/"))}
t.relative=function(e,n){e=t.resolve(e).substr(1)
n=t.resolve(n).substr(1)
function r(e){var t=0
for(;t<e.length;t++)if(""!==e[t])break
var n=e.length-1
for(;n>=0;n--)if(""!==e[n])break
if(t>n)return[]
return e.slice(t,n-t+1)}var o=r(e.split("/"))
var i=r(n.split("/"))
var a=Math.min(o.length,i.length)
var c=a
for(var s=0;s<a;s++)if(o[s]!==i[s]){c=s
break}var l=[]
for(s=c;s<o.length;s++)l.push("..")
l=l.concat(i.slice(c))
return l.join("/")}
t.sep="/"
t.delimiter=":"
t.dirname=function(e){"string"!==typeof e&&(e+="")
if(0===e.length)return"."
var t=e.charCodeAt(0)
var n=47===t
var r=-1
var o=true
for(var i=e.length-1;i>=1;--i){t=e.charCodeAt(i)
if(47===t){if(!o){r=i
break}}else o=false}if(-1===r)return n?"/":"."
if(n&&1===r)return"/"
return e.slice(0,r)}
function r(e){"string"!==typeof e&&(e+="")
var t=0
var n=-1
var r=true
var o
for(o=e.length-1;o>=0;--o)if(47===e.charCodeAt(o)){if(!r){t=o+1
break}}else if(-1===n){r=false
n=o+1}if(-1===n)return""
return e.slice(t,n)}t.basename=function(e,t){var n=r(e)
t&&n.substr(-1*t.length)===t&&(n=n.substr(0,n.length-t.length))
return n}
t.extname=function(e){"string"!==typeof e&&(e+="")
var t=-1
var n=0
var r=-1
var o=true
var i=0
for(var a=e.length-1;a>=0;--a){var c=e.charCodeAt(a)
if(47===c){if(!o){n=a+1
break}continue}if(-1===r){o=false
r=a+1}46===c?-1===t?t=a:1!==i&&(i=1):-1!==t&&(i=-1)}if(-1===t||-1===r||0===i||1===i&&t===r-1&&t===n+1)return""
return e.slice(t,r)}
function o(e,t){if(e.filter)return e.filter(t)
var n=[]
for(var r=0;r<e.length;r++)t(e[r],r,e)&&n.push(e[r])
return n}var i="b"==="ab".substr(-1)?function(e,t,n){return e.substr(t,n)}:function(e,t,n){t<0&&(t=e.length+t)
return e.substr(t,n)}}).call(this,n("8oxB"))},"5JRF":function(e,t,n){"use strict"
var r=n("rePB")
var o=n("1OyB")
var i=n("vuIU")
var a=n("md7G")
var c=n("foSv")
var s=n("Ji7U")
var l=n("q1tI")
var u=n.n(l)
var d=n("17x9")
var p=n.n(d)
var h=n("TSYQ")
var f=n.n(h)
var b=n("J2CL")
var v=n("nAyT")
var g=n("KgFQ")
var y=n("jtGx")
var m=n("VTBJ")
function j(e){var t=e.typography,n=e.colors,r=e.spacing
return Object(m["a"])({},t,{primaryInverseColor:n.textLightest,primaryColor:n.textDarkest,secondaryColor:n.textDark,secondaryInverseColor:n.textLight,warningColor:n.textWarning,brandColor:n.textBrand,errorColor:n.textDanger,successColor:n.textSuccess,alertColor:n.textAlert,paragraphMargin:"".concat(r.medium," 0")})}j.canvas=function(e){return{primaryColor:e["ic-brand-font-color-dark"],brandColor:e["ic-brand-primary"]}}
n.d(t,"a",(function(){return x}))
var _,U,k,B,w
var O={componentId:"cjUyb",template:function(e){return"\n\n.cjUyb_bGBk{font-family:".concat(e.fontFamily||"inherit","}\n\n.cjUyb_bGBk sub,.cjUyb_bGBk sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}\n\n.cjUyb_bGBk sup{top:-0.4em}\n\n.cjUyb_bGBk sub{bottom:-0.4em}\n\n.cjUyb_bGBk code,.cjUyb_bGBk pre{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;empty-cells:show;float:none;font-family:serif;font-family:").concat(e.fontFamilyMonospace||"inherit",";font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n.cjUyb_bGBk em,.cjUyb_bGBk i{font-style:italic}\n\n.cjUyb_bGBk b,.cjUyb_bGBk strong{font-weight:").concat(e.fontWeightBold||"inherit","}\n\n.cjUyb_bGBk p{display:block;margin:").concat(e.paragraphMargin||"inherit",";padding:0}\n\ninput.cjUyb_bGBk[type]{-moz-appearance:none;-webkit-appearance:none;appearance:none;background:none;border:none;border-radius:0;box-shadow:none;box-sizing:border-box;color:inherit;display:block;height:auto;line-height:inherit;margin:0;outline:0;padding:0;text-align:start;width:100%}\n\n[dir=ltr] input.cjUyb_bGBk[type]{text-align:left}\n\n[dir=rtl] input.cjUyb_bGBk[type]{text-align:right}\n\n.cjUyb_bGBk:focus,input.cjUyb_bGBk[type]:focus{outline:none}\n\n.cjUyb_bGBk.cjUyb_qFsi,input.cjUyb_bGBk[type].cjUyb_qFsi{color:").concat(e.primaryColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bLsb,input.cjUyb_bGBk[type].cjUyb_bLsb{color:").concat(e.secondaryColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ezBQ,input.cjUyb_bGBk[type].cjUyb_ezBQ{color:").concat(e.primaryInverseColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dlnd,input.cjUyb_bGBk[type].cjUyb_dlnd{color:").concat(e.secondaryInverseColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_cJLh,input.cjUyb_bGBk[type].cjUyb_cJLh{color:").concat(e.successColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fpfC,input.cjUyb_bGBk[type].cjUyb_fpfC{color:").concat(e.brandColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eHcp,input.cjUyb_bGBk[type].cjUyb_eHcp{color:").concat(e.warningColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dwua,input.cjUyb_bGBk[type].cjUyb_dwua{color:").concat(e.errorColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eZgl,input.cjUyb_bGBk[type].cjUyb_eZgl{color:").concat(e.alertColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fbNi,input.cjUyb_bGBk[type].cjUyb_fbNi{-ms-hyphens:auto;-webkit-hyphens:auto;hyphens:auto;overflow-wrap:break-word;word-break:break-word}\n\n.cjUyb_bGBk.cjUyb_drST,input.cjUyb_bGBk[type].cjUyb_drST{font-weight:").concat(e.fontWeightNormal||"inherit","}\n\n.cjUyb_bGBk.cjUyb_pEgL,input.cjUyb_bGBk[type].cjUyb_pEgL{font-weight:").concat(e.fontWeightLight||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bdMA,input.cjUyb_bGBk[type].cjUyb_bdMA{font-weight:").concat(e.fontWeightBold||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ijuF,input.cjUyb_bGBk[type].cjUyb_ijuF{font-style:normal}\n\n.cjUyb_bGBk.cjUyb_fetN,input.cjUyb_bGBk[type].cjUyb_fetN{font-style:italic}\n\n.cjUyb_bGBk.cjUyb_dfBC,input.cjUyb_bGBk[type].cjUyb_dfBC{font-size:").concat(e.fontSizeXSmall||"inherit","}\n\n.cjUyb_bGBk.cjUyb_doqw,input.cjUyb_bGBk[type].cjUyb_doqw{font-size:").concat(e.fontSizeSmall||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ycrn,input.cjUyb_bGBk[type].cjUyb_ycrn{font-size:").concat(e.fontSizeMedium||"inherit","}\n\n.cjUyb_bGBk.cjUyb_cMDj,input.cjUyb_bGBk[type].cjUyb_cMDj{font-size:").concat(e.fontSizeLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eoMd,input.cjUyb_bGBk[type].cjUyb_eoMd{font-size:").concat(e.fontSizeXLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fdca,input.cjUyb_bGBk[type].cjUyb_fdca{font-size:").concat(e.fontSizeXXLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fEWX,input.cjUyb_bGBk[type].cjUyb_fEWX{line-height:").concat(e.lineHeight||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fNIu,input.cjUyb_bGBk[type].cjUyb_fNIu{line-height:").concat(e.lineHeightFit||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dfDs,input.cjUyb_bGBk[type].cjUyb_dfDs{line-height:").concat(e.lineHeightCondensed||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bDjL,input.cjUyb_bGBk[type].cjUyb_bDjL{line-height:").concat(e.lineHeightDouble||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eQnG,input.cjUyb_bGBk[type].cjUyb_eQnG{letter-spacing:").concat(e.letterSpacingNormal||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bbUA,input.cjUyb_bGBk[type].cjUyb_bbUA{letter-spacing:").concat(e.letterSpacingCondensed||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bRWU,input.cjUyb_bGBk[type].cjUyb_bRWU{letter-spacing:").concat(e.letterSpacingExpanded||"inherit","}\n\n.cjUyb_bGBk.cjUyb_wZsr,input.cjUyb_bGBk[type].cjUyb_wZsr{text-transform:none}\n\n.cjUyb_bGBk.cjUyb_fCZK,input.cjUyb_bGBk[type].cjUyb_fCZK{text-transform:capitalize}\n\n.cjUyb_bGBk.cjUyb_dsRi,input.cjUyb_bGBk[type].cjUyb_dsRi{text-transform:uppercase}\n\n.cjUyb_bGBk.cjUyb_bLtD,input.cjUyb_bGBk[type].cjUyb_bLtD{text-transform:lowercase}")},root:"cjUyb_bGBk","color-primary":"cjUyb_qFsi","color-secondary":"cjUyb_bLsb","color-primary-inverse":"cjUyb_ezBQ","color-secondary-inverse":"cjUyb_dlnd","color-success":"cjUyb_cJLh","color-brand":"cjUyb_fpfC","color-warning":"cjUyb_eHcp","color-error":"cjUyb_dwua","color-alert":"cjUyb_eZgl","wrap-break-word":"cjUyb_fbNi","weight-normal":"cjUyb_drST","weight-light":"cjUyb_pEgL","weight-bold":"cjUyb_bdMA","style-normal":"cjUyb_ijuF","style-italic":"cjUyb_fetN","x-small":"cjUyb_dfBC",small:"cjUyb_doqw",medium:"cjUyb_ycrn",large:"cjUyb_cMDj","x-large":"cjUyb_eoMd","xx-large":"cjUyb_fdca","lineHeight-default":"cjUyb_fEWX","lineHeight-fit":"cjUyb_fNIu","lineHeight-condensed":"cjUyb_dfDs","lineHeight-double":"cjUyb_bDjL","letterSpacing-normal":"cjUyb_eQnG","letterSpacing-condensed":"cjUyb_bbUA","letterSpacing-expanded":"cjUyb_bRWU","transform-none":"cjUyb_wZsr","transform-capitalize":"cjUyb_fCZK","transform-uppercase":"cjUyb_dsRi","transform-lowercase":"cjUyb_bLtD"}
var x=(_=Object(v["a"])("7.0.0",null,"Use Text from ui-text instead."),U=Object(b["themeable"])(j,O),_(k=U(k=(w=B=function(e){Object(s["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(a["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){var e
var n=this.props,o=n.wrap,i=n.weight,a=n.fontStyle,c=n.size,s=n.lineHeight,l=n.letterSpacing,d=n.transform,p=n.color,h=n.children
var b=Object(g["a"])(t,this.props)
return u.a.createElement(b,Object.assign({},Object(y["a"])(this.props,t.propTypes),{className:f()((e={},Object(r["a"])(e,O.root,true),Object(r["a"])(e,O[c],c),Object(r["a"])(e,O["wrap-".concat(o)],o),Object(r["a"])(e,O["weight-".concat(i)],i),Object(r["a"])(e,O["style-".concat(a)],a),Object(r["a"])(e,O["transform-".concat(d)],d),Object(r["a"])(e,O["lineHeight-".concat(s)],s),Object(r["a"])(e,O["letterSpacing-".concat(l)],l),Object(r["a"])(e,O["color-".concat(p)],p),e)),ref:this.props.elementRef}),h)}}])
t.displayName="Text"
return t}(l["Component"]),B.propTypes={as:p.a.elementType,wrap:p.a.oneOf(["normal","break-word"]),weight:p.a.oneOf(["normal","light","bold"]),fontStyle:p.a.oneOf(["italic","normal"]),size:p.a.oneOf(["x-small","small","medium","large","x-large","xx-large"]),lineHeight:p.a.oneOf(["default","fit","condensed","double"]),letterSpacing:p.a.oneOf(["normal","condensed","expanded"]),transform:p.a.oneOf(["none","capitalize","uppercase","lowercase"]),color:p.a.oneOf(["primary","secondary","primary-inverse","secondary-inverse","success","error","alert","warning","brand"]),children:p.a.node,elementRef:p.a.func},B.defaultProps={as:"span",wrap:"normal",size:"medium",letterSpacing:"normal",children:null,elementRef:void 0,color:void 0,transform:void 0,lineHeight:void 0,fontStyle:void 0,weight:void 0},w))||k)||k)},"7Lu0":function(e,t,n){"use strict"
n.d(t,"a",(function(){return h}))
var r=n("VTBJ")
var o=n("1OyB")
var i=n("vuIU")
var a=n("md7G")
var c=n("foSv")
var s=n("Ji7U")
var l=n("q1tI")
var u=n.n(l)
var d=n("hPGw")
var p=u.a.createElement("path",{d:"M572.501 747l-254.933 815.893-101.867-31.786 278.507-890.774h1105.813v-320H783.808L612.181 107H.021v1546.667c0 88.213 71.787 160 160 160h1388.054c75.946 0 141.973-54.08 156.906-128.64L1892.608 747H572.501z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var h=function(e){Object(s["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(a["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){return u.a.createElement(d["a"],Object.assign({},this.props,{name:"IconOpenFolder",viewBox:"0 0 1920 1920",bidirectional:true}),p)}}])
t.displayName="IconOpenFolderSolid"
return t}(l["Component"])
h.glyphName="open-folder"
h.variant="Solid"
h.propTypes=Object(r["a"])({},d["a"].propTypes)},HVsT:function(e,t,n){"use strict"
n.d(t,"a",(function(){return h}))
var r=n("VTBJ")
var o=n("1OyB")
var i=n("vuIU")
var a=n("md7G")
var c=n("foSv")
var s=n("Ji7U")
var l=n("q1tI")
var u=n.n(l)
var d=n("hPGw")
var p=u.a.createElement("path",{d:"M213.333 960c0-167.36 56-321.707 149.44-446.4L1406.4 1557.227c-124.693 93.44-279.04 149.44-446.4 149.44-411.627 0-746.667-335.04-746.667-746.667m1493.334 0c0 167.36-56 321.707-149.44 446.4L513.6 362.773c124.693-93.44 279.04-149.44 446.4-149.44 411.627 0 746.667 335.04 746.667 746.667M960 0C429.76 0 0 429.76 0 960s429.76 960 960 960 960-429.76 960-960S1490.24 0 960 0",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var h=function(e){Object(s["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(a["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){return u.a.createElement(d["a"],Object.assign({},this.props,{name:"IconNo",viewBox:"0 0 1920 1920"}),p)}}])
t.displayName="IconNoSolid"
return t}(l["Component"])
h.glyphName="no"
h.variant="Solid"
h.propTypes=Object(r["a"])({},d["a"].propTypes)},IqBw:function(e,t,n){"use strict"
n.d(t,"a",(function(){return h}))
var r=n("VTBJ")
var o=n("1OyB")
var i=n("vuIU")
var a=n("md7G")
var c=n("foSv")
var s=n("Ji7U")
var l=n("q1tI")
var u=n.n(l)
var d=n("hPGw")
var p=u.a.createElement("path",{d:"M1493.602 1468.294H225.837C523.211 387.9 755.305 1443.9 983.898 1115.918c284.612-408.283 590.57-405.685 710.174 352.376h-200.47zm-816-1129.412c124.8 0 225.882 101.196 225.882 225.883 0 124.687-101.082 225.882-225.882 225.882-124.687 0-225.882-101.195-225.882-225.882 0-124.687 101.195-225.883 225.882-225.883zM-.045 1807.118h1920V113h-1920v1694.118z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var h=function(e){Object(s["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(a["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){return u.a.createElement(d["a"],Object.assign({},this.props,{name:"IconImage",viewBox:"0 0 1920 1920"}),p)}}])
t.displayName="IconImageSolid"
return t}(l["Component"])
h.glyphName="image"
h.variant="Solid"
h.propTypes=Object(r["a"])({},d["a"].propTypes)},J3yE:function(e,t,n){"use strict"
n.d(t,"a",(function(){return h}))
var r=n("VTBJ")
var o=n("1OyB")
var i=n("vuIU")
var a=n("md7G")
var c=n("foSv")
var s=n("Ji7U")
var l=n("q1tI")
var u=n.n(l)
var d=n("hPGw")
var p=u.a.createElement("path",{d:"M1072.156 537.778c59.802-.707 116.561 14.29 157.774 56.99 36.644 37.974 50.015 91.327 43.72 142.908-9.128 74.877-30.737 144.983-56.093 215.657-27.129 75.623-54.66 151.09-82.332 226.512-44.263 120.685-88.874 241.237-132.65 362.1-10.877 30.018-18.635 62.072-21.732 93.784-3.376 34.532 21.462 51.526 52.648 36.203 24.977-12.278 49.288-28.992 68.845-48.768 31.952-32.31 63.766-64.776 94.805-97.98 15.515-16.605 30.86-33.397 45.912-50.438 11.993-13.583 24.318-34.02 40.779-42.28 31.17-15.642 55.226 22.846 49.582 49.794-6.008 28.736-27.377 53.54-45.014 75.973-54.87 69.795-115.044 137.088-183.308 193.977-67.103 55.77-141.607 103.216-223.428 133.98-26.65 10.016-53.957 18.253-81.713 24.563-53.585 12.192-112.798 11.283-167.56 3.333-40.151-5.828-76.246-31.44-93.264-68.707-29.544-64.698-8.98-144.595 6.295-210.45 20.37-87.77 51.85-170.961 83.13-255.163 33.253-89.517 67.435-178.676 101.726-267.797 31.294-81.296 62.72-162.537 93.69-243.95 8.718-22.923 21.183-45.255 24.845-68.963 6.109-39.537-22.406-74.738-61.985-51.947-92.46 53.244-153.538 141.534-224.52 218.4-16.089 17.43-35.243 39.04-62.907 19.07-29.521-21.308-20.765-48.637-3.987-71.785 93.18-128.58 205.056-248.86 350.86-316.783 60.932-28.386 146.113-57.285 225.882-58.233zM1440 205.244c-.008 169.189-182.758 284.908-335.53 212.455-78.956-37.446-117.358-126.202-98.219-227.002 26.494-139.598 183.78-227.203 315.717-175.87 76.703 29.846 118.04 96.533 118.032 190.417z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var h=function(e){Object(s["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(a["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){return u.a.createElement(d["a"],Object.assign({},this.props,{name:"IconInfoBorderless",viewBox:"0 0 1920 1920"}),p)}}])
t.displayName="IconInfoBorderlessSolid"
return t}(l["Component"])
h.glyphName="info-borderless"
h.variant="Solid"
h.propTypes=Object(r["a"])({},d["a"].propTypes)},"L+/K":function(e,t,n){"use strict"
var r=n("1OyB")
var o=n("vuIU")
var i=n("md7G")
var a=n("foSv")
var c=n("Ji7U")
n("DEX3")
var s=n("q1tI")
var l=n.n(s)
var u=n("i8i4")
var d=n.n(u)
var p=n("17x9")
var h=n.n(p)
var f=n("TSYQ")
var b=n.n(f)
var v=n("3zPy")
var g=n.n(v)
var y=n("nAyT")
var m=n("E+IV")
var j=n("Mmr1")
var _=n("n12J")
var U=n("6SzX")
var k=n("HVsT")
var B=n("J3yE")
var w=n("97gy")
var O=n("znKQ")
var x=n("XQb/")
var C=n("J2CL")
var G=n("BTe1")
function I(e){var t=e.colors,n=e.borders,r=e.spacing,o=e.typography,i=e.shadows
return{background:t.backgroundLightest,color:t.textDarkest,marginTop:r.small,borderRadius:n.radiusMedium,borderWidth:n.widthMedium,borderStyle:n.style,contentPadding:"".concat(r.small," ").concat(r.medium),contentFontSize:o.fontSizeMedium,contentFontFamily:o.fontFamily,contentFontWeight:o.fontWeightNormal,contentLineHeight:o.lineHeightCondensed,closeButtonMarginTop:r.xSmall,closeButtonMarginRight:r.xxSmall,iconColor:t.textLightest,successBorderColor:t.borderSuccess,successIconBackground:t.backgroundSuccess,infoBorderColor:t.borderInfo,infoIconBackground:t.backgroundInfo,warningBorderColor:t.borderWarning,warningIconBackground:t.backgroundWarning,dangerBorderColor:t.borderDanger,dangerIconBackground:t.backgroundDanger,boxShadow:i.depth2}}I.canvas=function(e){return{color:e["ic-brand-font-color-dark"]}}
n.d(t,"a",(function(){return A}))
var S,L,F,E,T
var R={componentId:"cvphu",template:function(e){return"\n\n.cvphu_bgqc{background:".concat(e.background||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";border-style:").concat(e.borderStyle||"inherit",";border-width:").concat(e.borderWidth||"inherit",";box-shadow:").concat(e.boxShadow||"inherit",";color:").concat(e.color||"inherit",";display:flex;min-width:12rem}\n\n.cvphu_bgqc,.cvphu_caGd{box-sizing:border-box}\n\n.cvphu_caGd{flex:1;font-family:").concat(e.contentFontFamily||"inherit",";font-size:").concat(e.contentFontSize||"inherit",";font-weight:").concat(e.contentFontWeight||"inherit",";line-height:").concat(e.contentLineHeight||"inherit",";min-width:0.0625rem;padding:").concat(e.contentPadding||"inherit","}\n\n.cvphu_dnnz{align-items:center;border-right:").concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit",";color:").concat(e.iconColor||"inherit",";flex:0 0 2.5rem;font-size:1.125rem;justify-content:center}\n\n.cvphu_fsGh,.cvphu_dnnz{box-sizing:border-box;display:flex}\n\n.cvphu_fsGh{align-items:flex-start;margin-right:").concat(e.closeButtonMarginRight||"inherit",";margin-top:").concat(e.closeButtonMarginTop||"inherit",";order:1}\n\n.cvphu_cOXX{border-color:").concat(e.successBorderColor||"inherit","}\n\n.cvphu_cOXX .cvphu_dnnz{background-color:").concat(e.successIconBackground||"inherit",";border-right-color:").concat(e.successIconBackground||"inherit","}\n\n.cvphu_pypk{border-color:").concat(e.infoBorderColor||"inherit","}\n\n.cvphu_pypk .cvphu_dnnz{background:").concat(e.infoIconBackground||"inherit",";border-right-color:").concat(e.infoIconBackground||"inherit","}\n\n.cvphu_ddvR{border-color:").concat(e.dangerBorderColor||"inherit","}\n\n.cvphu_ddvR .cvphu_dnnz{background:").concat(e.dangerIconBackground||"inherit",";border-right-color:").concat(e.dangerIconBackground||"inherit","}\n\n.cvphu_eRqw{border-color:").concat(e.warningBorderColor||"inherit","}\n\n.cvphu_eRqw .cvphu_dnnz{background:").concat(e.warningIconBackground||"inherit",";border-right-color:").concat(e.warningIconBackground||"inherit","}")},alert:"cvphu_bgqc",content:"cvphu_caGd",icon:"cvphu_dnnz",closeButton:"cvphu_fsGh",success:"cvphu_cOXX",info:"cvphu_pypk",error:"cvphu_ddvR",warning:"cvphu_eRqw"}
var A=(S=Object(y["a"])("7.0.0",{closeButtonLabel:"renderCloseButtonLabel"}),L=Object(C["themeable"])(I,R),S(F=L(F=(T=E=function(e){Object(c["a"])(t,e)
function t(e){var n
Object(r["a"])(this,t)
n=Object(i["a"])(this,Object(a["a"])(t).call(this,e))
n._timeouts=[]
n.handleTimeout=function(){n.props.timeout>0&&n._timeouts.push(setTimeout((function(){n.close()}),n.props.timeout))}
n.onExitTransition=function(){n.props.onDismiss&&n.props.onDismiss()}
n.close=function(){n.clearTimeouts()
n.removeScreenreaderAlert()
n.setState({open:false},(function(){n.props.onDismiss&&"none"===n.props.transition&&n.props.onDismiss()}))}
n.handleKeyUp=function(e){(n.props.renderCloseButtonLabel||n.props.closeButtonLabel)&&e.keyCode===g.a.codes.esc&&n.close()}
n.state={open:true}
return n}Object(o["a"])(t,[{key:"variantUI",value:function(){return{error:{Icon:k["a"],classNames:b()(R.alert,R.error)},info:{Icon:B["a"],classNames:b()(R.alert,R.info)},success:{Icon:w["a"],classNames:b()(R.alert,R.success)},warning:{Icon:O["a"],classNames:b()(R.alert,R.warning)}}[this.props.variant]}},{key:"clearTimeouts",value:function(){this._timeouts.forEach((function(e){return clearTimeout(e)}))
this._timeouts=[]}},{key:"isDOMNode",value:function(e){return e&&"object"===typeof e&&1===e.nodeType}},{key:"getLiveRegion",value:function(){var e=null
"function"===typeof this.props.liveRegion&&(e=this.props.liveRegion())
return this.isDOMNode(e)?e:null}},{key:"initLiveRegion",value:function(e){e.getAttribute("role")
if(e){e.setAttribute("aria-live",this.props.liveRegionPoliteness)
e.setAttribute("aria-relevant","additions text")
e.setAttribute("aria-atomic",this.props.isLiveRegionAtomic)}}},{key:"createScreenreaderContentNode",value:function(){return l.a.createElement(U["a"],null,this.props.children)}},{key:"createScreenreaderAlert",value:function(){var e=this.getLiveRegion()
if(e){this.srid=Object(G["a"])("Alert")
var t=document.createElement("div")
t.setAttribute("id",this.srid)
var n=this.createScreenreaderContentNode()
d.a.render(n,t)
e.appendChild(t)}}},{key:"updateScreenreaderAlert",value:function(){var e=this
if(this.getLiveRegion()){var t=document.getElementById(this.srid)
t&&d.a.render(null,t,(function(){var n=e.createScreenreaderContentNode()
d.a.render(n,t)}))}}},{key:"removeScreenreaderAlert",value:function(){var e=this.getLiveRegion()
if(e){var t=document.getElementById(this.srid)
if(t){e.removeAttribute("aria-live")
e.removeAttribute("aria-relevant")
e.removeAttribute("aria-atomic")
d.a.unmountComponentAtNode(t)
t.parentNode.removeChild(t)
this.initLiveRegion(e)}}}},{key:"componentDidMount",value:function(){var e=this.getLiveRegion()
e&&this.initLiveRegion(e)
this.handleTimeout()
this.createScreenreaderAlert()}},{key:"componentDidUpdate",value:function(e){false===!!this.props.open&&!!this.props.open!==!!e.open?this.close():this.props.children!==e.children&&this.updateScreenreaderAlert()}},{key:"componentWillUnmount",value:function(){this.removeScreenreaderAlert()
this.clearTimeouts()}},{key:"renderIcon",value:function(){var e=this.variantUI(),t=e.Icon
return l.a.createElement("div",{className:R.icon},l.a.createElement(t,{className:R.alertIcon}))}},{key:"renderCloseButton",value:function(){var e=this.props.renderCloseButtonLabel&&Object(m["a"])(this.props.renderCloseButtonLabel)||this.props.closeButtonLabel
return e?l.a.createElement("div",{className:R.closeButton,key:"closeButton"},l.a.createElement(j["a"],{onClick:this.close,size:"small",screenReaderLabel:e})):null}},{key:"renderAlert",value:function(){var e=this.variantUI(),t=e.classNames
return l.a.createElement(_["a"],{as:"div",margin:this.props.margin,className:t,onKeyUp:this.handleKeyUp},this.renderIcon(),l.a.createElement("div",{className:R.content},this.props.children),this.renderCloseButton())}},{key:"render",value:function(){if(this.props.screenReaderOnly){this.getLiveRegion()
return null}if("none"===this.props.transition)return this.state.open?this.renderAlert():null
return l.a.createElement(x["a"],{type:this.props.transition,transitionOnMount:true,in:this.state.open,unmountOnExit:true,onExited:this.onExitTransition},this.renderAlert())}}])
t.displayName="Alert"
return t}(s["Component"]),E.propTypes={children:h.a.node,variant:h.a.oneOf(["info","success","warning","error"]),margin:C["ThemeablePropTypes"].spacing,liveRegion:h.a.func,liveRegionPoliteness:h.a.oneOf(["polite","assertive"]),isLiveRegionAtomic:h.a.bool,screenReaderOnly:h.a.bool,timeout:h.a.number,renderCloseButtonLabel:h.a.oneOfType([h.a.func,h.a.node]),closeButtonLabel:h.a.string,onDismiss:h.a.func,transition:h.a.oneOf(["none","fade"]),open:h.a.bool},E.defaultProps={variant:"info",margin:"x-small 0",timeout:0,transition:"fade",open:true,screenReaderOnly:false,liveRegionPoliteness:"assertive",isLiveRegionAtomic:false,onDismiss:void 0,liveRegion:void 0,renderCloseButtonLabel:void 0,closeButtonLabel:void 0,children:null},T))||F)||F)},"Op/J":function(e,t,n){"use strict"
var r=n("An8g")
var o=n("VTBJ")
var i=n("M1Vv")
var a=n("q1tI")
var c=n.n(a)
var s=n("LvDl")
var l=n.n(s)
var u=n("ouhR")
var d=n.n(u)
var p=n("x1Tw")
var h=n("2LKJ")
var f=n.n(h)
var b=n("TU4e")
var v=n("VTJ5")
var g=n("5JRF")
var y=n("Xx/m")
var m=n("ysUD")
var j=n("WfMV")
var _=n("Cf7h")
var U=n("VDZY")
var k=n("7Lu0")
var B=n("XHgw")
var w=n("IqBw")
n("17x9")
const O={Accept:"application/json+canvas-string-ids"}
function x(e,t){return p["default"].get("/api/v1/".concat(e,"/").concat(t,"/folders/root"),O)}function C(e){const t=new FormData
Object.keys(e).forEach(n=>t.append(n,e[n]))
return t}function G(e,t,n,r){const i=C(Object(o["a"])({},t.upload_params,{file:e}))
const a=Object(o["a"])({"Content-Type":"multipart/form-data"},O)
p["default"].post(t.upload_url,i,a).then(e=>n(e.data)).catch(e=>r(e))}function I(e,t,n,r){p["default"].post("/api/v1/folders/".concat(t,"/files"),{name:e.name,size:e.size,parent_folder_id:t,on_duplicate:"rename"},O).then(t=>G(e,t.data,n,r)).catch(e=>r(e))}var S=n("XGn+")
var L=n("dqQ7")
var F=n("yE80")
class E extends c.a.Component{constructor(e){var t
super(e)
t=this
this.populateCollectionsList=function(e){let n=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}
const r=l.a.cloneDeep(t.state.collections)
e.forEach(e=>{const o=t.formatFolderInfo(e,n)
r[o.id]=o
const i=e.parent_folder_id||0
const a=r[i].collections
if(!a.includes(o.id)){a.push(o.id)
r[i].collections=t.orderedIdsFromList(r,a)}})
t.setState({collections:r})
e.forEach(e=>{t.state.openFolders.includes(e.parent_folder_id)&&t.getFolderData(e.id)})}
this.populateItemsList=e=>{const t=l.a.cloneDeep(this.state.items)
const n=l.a.cloneDeep(this.state.collections)
e.forEach(e=>{if(this.contentTypeIsAllowed(e["content-type"])){const r=this.formatFileInfo(e)
t[r.id]=r
const o=e.folder_id
const i=n[o].items
if(!i.includes(r.id)){i.push(r.id)
n[o].items=this.orderedIdsFromList(t,i)}}})
this.setState({items:t,collections:n})}
this.onFolderToggle=e=>this.onFolderClick(e.id,e)
this.onFolderClick=(e,t)=>{const n=this.state.collections[e]
let r=[]
const o=this.state.openFolders
if(!n.locked&&o.includes(e))r=r.concat(o.filter(t=>t!==e))
else if(!n.locked){r=r.concat(o)
r.push(e)
n.collections.forEach(e=>this.getFolderData(e))}return this.setState({openFolders:r,uploadFolder:e})}
this.onFileClick=e=>{const t=this.findFolderForFile(e)
this.setState({uploadFolder:t&&t.id})
this.props.selectFile(this.state.items[e.id])}
this.onInputChange=e=>{e&&this.submitFile(e[0])}
this.submitFile=e=>{this.setState({uploading:true})
I(e,this.state.uploadFolder,this.onUploadSucceed,this.onUploadFail)}
this.onUploadSucceed=e=>{this.populateItemsList([e])
this.clearUploadInfo()
const t=this.state.collections[e.folder_id]
this.setSuccessMessage(i["a"].t("Success: File uploaded"))
0===d()("button:contains('".concat(e.display_name,"')")).length&&d()("button:contains('".concat(t&&t.name,"')")).click()
const n=d()("button:contains('".concat(e.display_name,"')"))
d()(".file-browser__tree").scrollTo(n)
n.click()}
this.onUploadFail=()=>{this.clearUploadInfo()
this.setFailureMessage(i["a"].t("File upload failed"))}
this.setSuccessMessage=e=>{Object(L["c"])(e)()}
this.setFailureMessage=e=>{Object(L["b"])(e)()}
this.selectLocalFile=()=>{this.uploadInput.click()}
this.state={collections:{0:{collections:[]}},items:{},openFolders:[],uploadFolder:null,uploading:false,loadingCount:0}}componentDidMount(){this.getRootFolders()}getContextName(e){return"courses"===e?i["a"].t("Course files"):i["a"].t("Group files")}getContextInfo(e){const t=Object(_["a"])(e)
if(t&&t[0]&&t[1]){const e=this.getContextName(t[0])
return{name:e,type:t[0],id:t[1]}}}getRootFolders(){this.props.useContextAssets&&this.getContextFolders()
this.getUserFolders()}getUserFolders(){this.getRootFolderData("users","self",{name:i["a"].t("My files")})}getContextFolders(){if(!ENV.context_asset_string)return
const e=this.getContextInfo(ENV.context_asset_string)
e&&e.type&&e.id&&this.getRootFolderData(e.type,e.id,{name:e.name})}increaseLoadingCount(){let e=this.state.loadingCount
e+=1
this.setState({loadingCount:e})}decreaseLoadingCount(){let e=this.state.loadingCount
e-=1
this.setState({loadingCount:e})}getRootFolderData(e,t){let n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}
this.increaseLoadingCount()
x(e,t).then(e=>this.populateRootFolder(e.data,n)).catch(e=>{this.decreaseLoadingCount()
e.response&&401!==e.response.status&&this.setFailureMessage(i["a"].t("Something went wrong"))})}populateRootFolder(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}
this.decreaseLoadingCount()
this.populateCollectionsList([e],t)
this.getFolderData(e.id)}getFolderData(e){const t=this.state.collections
if(!t[e].locked){this.getPaginatedData(this.folderFileApiUrl(e,"folders"),this.populateCollectionsList)
this.getPaginatedData(this.folderFileApiUrl(e),this.populateItemsList)}}getPaginatedData(e,t){p["default"].get(e).then(e=>{t(e.data)
const n=Object(S["a"])(e.headers.link).next
n&&this.getPaginatedData(n,t)})}folderFileApiUrl(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"files"
return"/api/v1/folders/".concat(e,"/").concat(t)}contentTypeIsAllowed(e){for(const t of this.props.contentTypes)if(f()(e,t))return true
return false}formatFolderInfo(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}
const n=e.locked_for_user?i["a"].t("Locked"):null
const r=Object(o["a"])({api:e,id:e.id,collections:[],items:[],name:e.name,context:"/".concat(e.context_type.toLowerCase(),"s/").concat(e.context_id),canUpload:e.can_upload,locked:e.locked_for_user,descriptor:n},t)
const a=this.state.collections[e.id]
Object.assign(r,a&&{collections:a.collections,items:a.items})
return r}formatFileInfo(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}
const n=this.state.collections
const r=n[e.folder_id].context
const i=Object(o["a"])({api:e,id:e.id,name:e.display_name,thumbnail:e.thumbnail_url,src:"".concat(r,"/files/").concat(e.id,"/preview").concat(r.includes("user")?"?verifier=".concat(e.uuid):""),alt:e.display_name},t)
return i}orderedIdsFromList(e,t){try{const n=t.sort((t,n)=>F["a"].strings(e[t].name,e[n].name))
return n}catch(e){console.error(e)
return t}}findFolderForFile(e){const t=this.state.collections
const n=Object.keys(t).find(n=>{const r=t[n].items
if(r&&r.includes(e.id))return n})
return t[n]}clearUploadInfo(){this.setState({uploading:false})
this.uploadInput.value=""}renderUploadDialog(){if(!this.props.allowUpload)return null
const e=this.state.collections[this.state.uploadFolder]
const t=!e||e.locked||!e.canUpload
const n=t?Object(r["a"])(j["a"],{},void 0,i["a"].t("Upload not available for this folder")):""
const o=this.props.contentTypes.join(",")
return Object(r["a"])("div",{className:"image-upload__form"},void 0,c.a.createElement("input",{onChange:e=>this.onInputChange(e.target.files),ref:e=>{this.uploadInput=e},type:"file",accept:o,className:"hidden"}),Object(r["a"])(y["a"],{id:"image-upload__upload",onClick:this.selectLocalFile,disabled:t,variant:"ghost",icon:U["a"]},void 0,i["a"].t("Upload File")," ",n))}renderMask(){return this.state.uploading?Object(r["a"])(m["a"],{},void 0,Object(r["a"])(v["a"],{className:"file-browser__uploading",renderTitle:i["a"].t("File uploading")})):null}renderLoading(){return this.state.loadingCount>0?Object(r["a"])(v["a"],{className:"file-browser__loading",renderTitle:i["a"].t("Loading folders"),size:"small"}):null}render(){const e=Object(r["a"])("div",{className:"file-browser__container"},void 0,Object(r["a"])(g["a"],{},void 0,i["a"].t("Available folders")),Object(r["a"])("div",{className:"file-browser__tree"},void 0,Object(r["a"])(b["a"],{collections:this.state.collections,items:this.state.items,size:"medium",onCollectionToggle:this.onFolderToggle,onCollectionClick:this.onFolderClick,onItemClick:this.onFileClick,treeLabel:i["a"].t("Folder tree"),rootId:0,showRootCollection:false,defaultExpanded:this.state.openFolders,collectionIconExpanded:k["a"],collectionIcon:B["a"],itemIcon:w["a"],selectionType:"single"}),this.renderMask(),this.renderLoading()),this.renderUploadDialog())
return e}}E.defaultProps={allowUpload:true,contentTypes:["*/*"],useContextAssets:true}
t["a"]=E},TuBq:function(e,t,n){var r=n("icBU")
var o=n("kbA8")
e.exports=f
var i="\0SLASH"+Math.random()+"\0"
var a="\0OPEN"+Math.random()+"\0"
var c="\0CLOSE"+Math.random()+"\0"
var s="\0COMMA"+Math.random()+"\0"
var l="\0PERIOD"+Math.random()+"\0"
function u(e){return parseInt(e,10)==e?parseInt(e,10):e.charCodeAt(0)}function d(e){return e.split("\\\\").join(i).split("\\{").join(a).split("\\}").join(c).split("\\,").join(s).split("\\.").join(l)}function p(e){return e.split(i).join("\\").split(a).join("{").split(c).join("}").split(s).join(",").split(l).join(".")}function h(e){if(!e)return[""]
var t=[]
var n=o("{","}",e)
if(!n)return e.split(",")
var r=n.pre
var i=n.body
var a=n.post
var c=r.split(",")
c[c.length-1]+="{"+i+"}"
var s=h(a)
if(a.length){c[c.length-1]+=s.shift()
c.push.apply(c,s)}t.push.apply(t,c)
return t}function f(e){if(!e)return[]
"{}"===e.substr(0,2)&&(e="\\{\\}"+e.substr(2))
return m(d(e),true).map(p)}function b(e){return"{"+e+"}"}function v(e){return/^-?0\d/.test(e)}function g(e,t){return e<=t}function y(e,t){return e>=t}function m(e,t){var n=[]
var i=o("{","}",e)
if(!i||/\$$/.test(i.pre))return[e]
var a=/^-?\d+\.\.-?\d+(?:\.\.-?\d+)?$/.test(i.body)
var s=/^[a-zA-Z]\.\.[a-zA-Z](?:\.\.-?\d+)?$/.test(i.body)
var l=a||s
var d=i.body.indexOf(",")>=0
if(!l&&!d){if(i.post.match(/,.*\}/)){e=i.pre+"{"+i.body+c+i.post
return m(e)}return[e]}var p
if(l)p=i.body.split(/\.\./)
else{p=h(i.body)
if(1===p.length){p=m(p[0],false).map(b)
if(1===p.length){var f=i.post.length?m(i.post,false):[""]
return f.map((function(e){return i.pre+p[0]+e}))}}}var j=i.pre
f=i.post.length?m(i.post,false):[""]
var _
if(l){var U=u(p[0])
var k=u(p[1])
var B=Math.max(p[0].length,p[1].length)
var w=3==p.length?Math.abs(u(p[2])):1
var O=g
var x=k<U
if(x){w*=-1
O=y}var C=p.some(v)
_=[]
for(var G=U;O(G,k);G+=w){var I
if(s){I=String.fromCharCode(G)
"\\"===I&&(I="")}else{I=String(G)
if(C){var S=B-I.length
if(S>0){var L=new Array(S+1).join("0")
I=G<0?"-"+L+I.slice(1):L+I}}}_.push(I)}}else _=r(p,(function(e){return m(e,false)}))
for(var F=0;F<_.length;F++)for(var E=0;E<f.length;E++){var T=j+_[F]+f[E];(!t||l||T)&&n.push(T)}return n}},VDZY:function(e,t,n){"use strict"
n.d(t,"a",(function(){return h}))
var r=n("VTBJ")
var o=n("1OyB")
var i=n("vuIU")
var a=n("md7G")
var c=n("foSv")
var s=n("Ji7U")
var l=n("q1tI")
var u=n.n(l)
var d=n("hPGw")
var p=u.a.createElement("path",{d:"M1467.552 1700.252l297.428-297.428 155.362 155.362L1558.527 1920H368.814L7 1558.186l155.361-155.362 297.429 297.428h1007.762zM965.902 0l517.175 517.176-155.361 155.361-251.941-251.94v1002.708H856.028V420.597l-251.941 251.94-155.362-155.361L965.901 0z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var h=function(e){Object(s["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(a["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){return u.a.createElement(d["a"],Object.assign({},this.props,{name:"IconUpload",viewBox:"0 0 1920 1920"}),p)}}])
t.displayName="IconUploadSolid"
return t}(l["Component"])
h.glyphName="upload"
h.variant="Solid"
h.propTypes=Object(r["a"])({},d["a"].propTypes)},"XGn+":function(e,t,n){"use strict"
t["a"]=function(e){if(!e)return[]
const t={}
e.split(",").map(e=>e.split("; ")).forEach(e=>{const n=e[0].substring(1,e[0].length-1)
let r=e[1].split("=")
r=r[1]
r=r.substring(1,r.length-1)
t[r]=n})
return t}},cClk:function(e,t,n){"use strict"
n.d(t,"a",(function(){return r}))
function r(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"onChange"
var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"defaultValue"
return function(r,o,i){var a=e.apply(null,arguments)
if(a)return a
if(r[o]&&"function"!==typeof r[t])return new Error(["You provided a '".concat(o,"' prop without an '").concat(t,"' handler on '").concat(i,"'. This will render a controlled component. If the component should be uncontrolled and manage its own state, use '").concat(n,"'. Otherwise, set '").concat(t,"'.")].join(""))}}},eAd9:function(e,t,n){(function(t){var n=false
var r
var o
function i(){if("undefined"!==typeof r)return r
var e=document.documentElement
var t=document.createElement("div")
t.setAttribute("style","width:99px;height:99px;position:absolute;top:-9999px;overflow:scroll;")
e.appendChild(t)
r=t.offsetWidth-t.clientWidth
e.removeChild(t)
return r}function a(){return document.documentElement.scrollHeight>window.innerHeight}function c(e){if("undefined"===typeof document||n)return
var t=document.documentElement
o=window.pageYOffset
a()?t.style.width="calc(100% - "+i()+"px)":t.style.width="100%"
t.style.position="fixed"
t.style.top=-o+"px"
t.style.overflow="hidden"
n=true}function s(){if("undefined"===typeof document||!n)return
var e=document.documentElement
e.style.width=""
e.style.position=""
e.style.top=""
e.style.overflow=""
window.scroll(0,o)
n=false}function l(){if(n){s()
return}c()}var u={on:c,off:s,toggle:l}
"undefined"!==typeof e.exports?e.exports=u:t.noScroll=u})(this)},icBU:function(e,t){e.exports=function(e,t){var r=[]
for(var o=0;o<e.length;o++){var i=t(e[o],o)
n(i)?r.push.apply(r,i):r.push(i)}return r}
var n=Array.isArray||function(e){return"[object Array]"===Object.prototype.toString.call(e)}},kbA8:function(e,t,n){"use strict"
e.exports=r
function r(e,t,n){e instanceof RegExp&&(e=o(e,n))
t instanceof RegExp&&(t=o(t,n))
var r=i(e,t,n)
return r&&{start:r[0],end:r[1],pre:n.slice(0,r[0]),body:n.slice(r[0]+e.length,r[1]),post:n.slice(r[1]+t.length)}}function o(e,t){var n=t.match(e)
return n?n[0]:null}r.range=i
function i(e,t,n){var r,o,i,a,c
var s=n.indexOf(e)
var l=n.indexOf(t,s+1)
var u=s
if(s>=0&&l>0){r=[]
i=n.length
while(u>=0&&!c){if(u==s){r.push(u)
s=n.indexOf(e,u+1)}else if(1==r.length)c=[r.pop(),l]
else{o=r.pop()
if(o<i){i=o
a=l}l=n.indexOf(t,u+1)}u=s<l&&s>=0?s:l}r.length&&(c=[i,a])}return c}},ysUD:function(e,t,n){"use strict"
var r=n("VTBJ")
var o=n("rePB")
var i=n("1OyB")
var a=n("vuIU")
var c=n("md7G")
var s=n("foSv")
var l=n("Ji7U")
var u=n("q1tI")
var d=n.n(u)
var p=n("17x9")
var h=n.n(p)
var f=n("TSYQ")
var b=n.n(f)
var v=n("eAd9")
var g=n.n(v)
var y=n("J2CL")
var m=n("sQ3t")
var j=n("jtGx")
function _(e){var t=e.colors,n=e.borders,r=e.stacking
return{zIndex:r.topmost,background:"rgba(255, 255, 255, 0.75)",borderColor:"transparent",focusBorderColor:t.borderBrand,borderRadius:n.radiusMedium,borderWidth:n.widthSmall}}_.canvas=function(e){return{focusBorderColor:e["ic-brand-primary"]}}
n.d(t,"a",(function(){return x}))
var U,k,B,w
var O={componentId:"fvvQs",template:function(e){return"\n\n.fvvQs_bGBk{background:".concat(e.background||"inherit",";border:").concat(e.borderWidth||"inherit"," solid ").concat(e.borderColor||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";bottom:0;box-sizing:border-box;display:flex;justify-content:center;left:0;outline:none;overflow:auto;position:absolute;right:0;top:0;z-index:").concat(e.zIndex||"inherit","}\n\n.fvvQs_bGBk:focus{border-color:").concat(e.focusBorderColor||"inherit","}\n\n.fvvQs_cMOR{position:fixed}\n\n.fvvQs_dacV{align-items:flex-start}\n\n.fvvQs_cwzs{align-items:center}\n\n.fvvQs_cGWj{align-items:flex-end}\n\n.fvvQs_eFiI{align-items:stretch}")},root:"fvvQs_bGBk",fullscreen:"fvvQs_cMOR",top:"fvvQs_dacV",center:"fvvQs_cwzs",bottom:"fvvQs_cGWj",stretch:"fvvQs_eFiI"}
var x=(U=Object(y["themeable"])(_,O),U(k=(w=B=function(e){Object(l["a"])(t,e)
function t(){var e
var n
Object(i["a"])(this,t)
for(var r=arguments.length,o=new Array(r),a=0;a<r;a++)o[a]=arguments[a]
n=Object(c["a"])(this,(e=Object(s["a"])(t)).call.apply(e,[this].concat(o)))
n.handleElementRef=function(e){n.props.elementRef(e)}
n.contentRef=function(e){n._content=e}
return n}Object(a["a"])(t,[{key:"componentDidMount",value:function(){this.props.fullscreen&&g.a.on()}},{key:"componentWillUnmount",value:function(){this.props.fullscreen&&g.a.off()}},{key:"render",value:function(){var e
var n=Object(m["a"])(this.props.children,{ref:this.contentRef})
var i=b()((e={},Object(o["a"])(e,O.root,true),Object(o["a"])(e,O[this.props.placement],true),Object(o["a"])(e,O.fullscreen,this.props.fullscreen),e))
var a=Object(r["a"])({},Object(j["a"])(this.props,t.propTypes),{className:i,ref:this.handleElementRef})
if("function"===typeof this.props.onClick){a.onClick=this.props.onClick
a.tabIndex=-1}return d.a.createElement("span",a,n)}}])
t.displayName="Mask"
return t}(u["Component"]),B.propTypes={onDismiss:h.a.func,placement:h.a.oneOf(["top","center","bottom","stretch"]),fullscreen:h.a.bool,children:h.a.node,onClick:h.a.func,elementRef:h.a.func},B.defaultProps={placement:"center",fullscreen:false,onDismiss:void 0,children:null,onClick:void 0,elementRef:function(e){}},w))||k)},znKQ:function(e,t,n){"use strict"
n.d(t,"a",(function(){return h}))
var r=n("VTBJ")
var o=n("1OyB")
var i=n("vuIU")
var a=n("md7G")
var c=n("foSv")
var s=n("Ji7U")
var l=n("q1tI")
var u=n.n(l)
var d=n("hPGw")
var p=u.a.createElement("g",{fillRule:"evenodd",stroke:"none",strokeWidth:"1"},u.a.createElement("path",{d:"M994.578 1436.356c-133.365 0-241.822 108.457-241.822 241.822S861.213 1920 994.578 1920s241.822-108.457 241.822-241.822-108.457-241.822-241.822-241.822zM1165.063 1315.444L1310.156 0H679l145.093 1315.444z"}))
var h=function(e){Object(s["a"])(t,e)
function t(){Object(o["a"])(this,t)
return Object(a["a"])(this,Object(c["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){return u.a.createElement(d["a"],Object.assign({},this.props,{name:"IconWarningBorderless",viewBox:"0 0 1920 1920"}),p)}}])
t.displayName="IconWarningBorderlessSolid"
return t}(l["Component"])
h.glyphName="warning-borderless"
h.variant="Solid"
h.propTypes=Object(r["a"])({},d["a"].propTypes)}}])

//# sourceMappingURL=128-c-8f6f246ae4.js.map