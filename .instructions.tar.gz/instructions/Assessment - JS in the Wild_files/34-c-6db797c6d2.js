(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[34],{"CO+y":function(e,n,r){"use strict"
r.d(n,"a",(function(){return p}))
var t=r("Ff2n")
var a=r("1OyB")
var o=r("vuIU")
var i=r("md7G")
var c=r("foSv")
var s=r("Ji7U")
var d=r("q1tI")
var _=r.n(d)
var l=r("17x9")
var g=r.n(l)
var u=r("KgFQ")
var b=r("jtGx")
var p=function(e){Object(s["a"])(n,e)
function n(){Object(a["a"])(this,n)
return Object(i["a"])(this,Object(c["a"])(n).apply(this,arguments))}Object(o["a"])(n,[{key:"render",value:function(){var e=this.props,r=e.children,a=Object(t["a"])(e,["children"])
var o=Object(u["a"])(n,this.props)
return _.a.createElement(o,Object.assign({},Object(b["b"])(a),{"aria-hidden":"true"}),r)}}])
n.displayName="PresentationContent"
return n}(d["Component"])
p.propTypes={as:g.a.elementType,children:g.a.node}
p.defaultProps={as:"span",children:null}},EUQ6:function(e,n,r){"use strict"
r.d(n,"a",(function(){return o}))
var t=r("17x9")
const a=Object(t["shape"])({id:t["string"].isRequired,display_name:t["string"].isRequired,avatar_image_url:t["string"]})
n["b"]=a
Object(t["shape"])({id:t["string"].isRequired,name:t["string"].isRequired,avatar_url:t["string"],email:t["string"]})
const o=Object(t["shape"])({id:t["string"].isRequired,name:t["string"].isRequired,avatar_image_url:t["string"],html_url:t["string"].isRequired})},ZbPE:function(e,n,r){"use strict"
var t=r("rePB")
var a=r("1OyB")
var o=r("vuIU")
var i=r("md7G")
var c=r("foSv")
var s=r("Ji7U")
var d=r("q1tI")
var _=r.n(d)
var l=r("17x9")
var g=r.n(l)
var u=r("TSYQ")
var b=r.n(u)
var p=r("J2CL")
var m=r("KgFQ")
var k=r("jtGx")
var h=r("nAyT")
var f=r("VTBJ")
function R(e){var n=e.typography,r=e.colors,t=e.spacing
return Object(f["a"])({},n,{primaryInverseColor:r.textLightest,primaryColor:r.textDarkest,secondaryColor:r.textDark,secondaryInverseColor:r.textLight,warningColor:r.textWarning,brandColor:r.textBrand,errorColor:r.textDanger,dangerColor:r.textDanger,successColor:r.textSuccess,alertColor:r.textAlert,paragraphMargin:"".concat(t.medium," 0")})}R.canvas=function(e){return{primaryColor:e["ic-brand-font-color-dark"],brandColor:e["ic-brand-primary"]}}
r.d(n,"a",(function(){return j}))
var v,y,w,B
var G={componentId:"enRcg",template:function(e){return"\n\n.enRcg_bGBk{font-family:".concat(e.fontFamily||"inherit","}\n\n.enRcg_bGBk sub,.enRcg_bGBk sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}\n\n.enRcg_bGBk sup{top:-0.4em}\n\n.enRcg_bGBk sub{bottom:-0.4em}\n\n.enRcg_bGBk code,.enRcg_bGBk pre{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;empty-cells:show;float:none;font-family:serif;font-family:").concat(e.fontFamilyMonospace||"inherit",";font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n.enRcg_bGBk em,.enRcg_bGBk i{font-style:italic}\n\n.enRcg_bGBk b,.enRcg_bGBk strong{font-weight:").concat(e.fontWeightBold||"inherit","}\n\n.enRcg_bGBk p{display:block;margin:").concat(e.paragraphMargin||"inherit",";padding:0}\n\ninput.enRcg_bGBk[type]{-moz-appearance:none;-webkit-appearance:none;appearance:none;background:none;border:none;border-radius:0;box-shadow:none;box-sizing:border-box;color:inherit;display:block;height:auto;line-height:inherit;margin:0;outline:0;padding:0;text-align:start;width:100%}\n\n[dir=ltr] input.enRcg_bGBk[type]{text-align:left}\n\n[dir=rtl] input.enRcg_bGBk[type]{text-align:right}\n\n.enRcg_bGBk:focus,input.enRcg_bGBk[type]:focus{outline:none}\n\n.enRcg_bGBk.enRcg_qFsi,input.enRcg_bGBk[type].enRcg_qFsi{color:").concat(e.primaryColor||"inherit","}\n\n.enRcg_bGBk.enRcg_bLsb,input.enRcg_bGBk[type].enRcg_bLsb{color:").concat(e.secondaryColor||"inherit","}\n\n.enRcg_bGBk.enRcg_ezBQ,input.enRcg_bGBk[type].enRcg_ezBQ{color:").concat(e.primaryInverseColor||"inherit","}\n\n.enRcg_bGBk.enRcg_dlnd,input.enRcg_bGBk[type].enRcg_dlnd{color:").concat(e.secondaryInverseColor||"inherit","}\n\n.enRcg_bGBk.enRcg_cJLh,input.enRcg_bGBk[type].enRcg_cJLh{color:").concat(e.successColor||"inherit","}\n\n.enRcg_bGBk.enRcg_fpfC,input.enRcg_bGBk[type].enRcg_fpfC{color:").concat(e.brandColor||"inherit","}\n\n.enRcg_bGBk.enRcg_eHcp,input.enRcg_bGBk[type].enRcg_eHcp{color:").concat(e.warningColor||"inherit","}\n\n.enRcg_bGBk.enRcg_dwua,input.enRcg_bGBk[type].enRcg_dwua{color:").concat(e.errorColor||"inherit","}\n\n.enRcg_bGBk.enRcg_NQMb,input.enRcg_bGBk[type].enRcg_NQMb{color:").concat(e.dangerColor||"inherit","}\n\n.enRcg_bGBk.enRcg_eZgl,input.enRcg_bGBk[type].enRcg_eZgl{color:").concat(e.alertColor||"inherit","}\n\n.enRcg_bGBk.enRcg_fbNi,input.enRcg_bGBk[type].enRcg_fbNi{-ms-hyphens:auto;-webkit-hyphens:auto;hyphens:auto;overflow-wrap:break-word;word-break:break-word}\n\n.enRcg_bGBk.enRcg_drST,input.enRcg_bGBk[type].enRcg_drST{font-weight:").concat(e.fontWeightNormal||"inherit","}\n\n.enRcg_bGBk.enRcg_pEgL,input.enRcg_bGBk[type].enRcg_pEgL{font-weight:").concat(e.fontWeightLight||"inherit","}\n\n.enRcg_bGBk.enRcg_bdMA,input.enRcg_bGBk[type].enRcg_bdMA{font-weight:").concat(e.fontWeightBold||"inherit","}\n\n.enRcg_bGBk.enRcg_ijuF,input.enRcg_bGBk[type].enRcg_ijuF{font-style:normal}\n\n.enRcg_bGBk.enRcg_fetN,input.enRcg_bGBk[type].enRcg_fetN{font-style:italic}\n\n.enRcg_bGBk.enRcg_dfBC,input.enRcg_bGBk[type].enRcg_dfBC{font-size:").concat(e.fontSizeXSmall||"inherit","}\n\n.enRcg_bGBk.enRcg_doqw,input.enRcg_bGBk[type].enRcg_doqw{font-size:").concat(e.fontSizeSmall||"inherit","}\n\n.enRcg_bGBk.enRcg_ycrn,input.enRcg_bGBk[type].enRcg_ycrn{font-size:").concat(e.fontSizeMedium||"inherit","}\n\n.enRcg_bGBk.enRcg_cMDj,input.enRcg_bGBk[type].enRcg_cMDj{font-size:").concat(e.fontSizeLarge||"inherit","}\n\n.enRcg_bGBk.enRcg_eoMd,input.enRcg_bGBk[type].enRcg_eoMd{font-size:").concat(e.fontSizeXLarge||"inherit","}\n\n.enRcg_bGBk.enRcg_fdca,input.enRcg_bGBk[type].enRcg_fdca{font-size:").concat(e.fontSizeXXLarge||"inherit","}\n\n.enRcg_bGBk.enRcg_fEWX,input.enRcg_bGBk[type].enRcg_fEWX{line-height:").concat(e.lineHeight||"inherit","}\n\n.enRcg_bGBk.enRcg_fNIu,input.enRcg_bGBk[type].enRcg_fNIu{line-height:").concat(e.lineHeightFit||"inherit","}\n\n.enRcg_bGBk.enRcg_dfDs,input.enRcg_bGBk[type].enRcg_dfDs{line-height:").concat(e.lineHeightCondensed||"inherit","}\n\n.enRcg_bGBk.enRcg_bDjL,input.enRcg_bGBk[type].enRcg_bDjL{line-height:").concat(e.lineHeightDouble||"inherit","}\n\n.enRcg_bGBk.enRcg_eQnG,input.enRcg_bGBk[type].enRcg_eQnG{letter-spacing:").concat(e.letterSpacingNormal||"inherit","}\n\n.enRcg_bGBk.enRcg_bbUA,input.enRcg_bGBk[type].enRcg_bbUA{letter-spacing:").concat(e.letterSpacingCondensed||"inherit","}\n\n.enRcg_bGBk.enRcg_bRWU,input.enRcg_bGBk[type].enRcg_bRWU{letter-spacing:").concat(e.letterSpacingExpanded||"inherit","}\n\n.enRcg_bGBk.enRcg_wZsr,input.enRcg_bGBk[type].enRcg_wZsr{text-transform:none}\n\n.enRcg_bGBk.enRcg_fCZK,input.enRcg_bGBk[type].enRcg_fCZK{text-transform:capitalize}\n\n.enRcg_bGBk.enRcg_dsRi,input.enRcg_bGBk[type].enRcg_dsRi{text-transform:uppercase}\n\n.enRcg_bGBk.enRcg_bLtD,input.enRcg_bGBk[type].enRcg_bLtD{text-transform:lowercase}")},root:"enRcg_bGBk","color-primary":"enRcg_qFsi","color-secondary":"enRcg_bLsb","color-primary-inverse":"enRcg_ezBQ","color-secondary-inverse":"enRcg_dlnd","color-success":"enRcg_cJLh","color-brand":"enRcg_fpfC","color-warning":"enRcg_eHcp","color-error":"enRcg_dwua","color-danger":"enRcg_NQMb","color-alert":"enRcg_eZgl","wrap-break-word":"enRcg_fbNi","weight-normal":"enRcg_drST","weight-light":"enRcg_pEgL","weight-bold":"enRcg_bdMA","style-normal":"enRcg_ijuF","style-italic":"enRcg_fetN","x-small":"enRcg_dfBC",small:"enRcg_doqw",medium:"enRcg_ycrn",large:"enRcg_cMDj","x-large":"enRcg_eoMd","xx-large":"enRcg_fdca","lineHeight-default":"enRcg_fEWX","lineHeight-fit":"enRcg_fNIu","lineHeight-condensed":"enRcg_dfDs","lineHeight-double":"enRcg_bDjL","letterSpacing-normal":"enRcg_eQnG","letterSpacing-condensed":"enRcg_bbUA","letterSpacing-expanded":"enRcg_bRWU","transform-none":"enRcg_wZsr","transform-capitalize":"enRcg_fCZK","transform-uppercase":"enRcg_dsRi","transform-lowercase":"enRcg_bLtD"}
var j=(v=Object(p["themeable"])(R,G),v(y=(B=w=function(e){Object(s["a"])(n,e)
function n(){Object(a["a"])(this,n)
return Object(i["a"])(this,Object(c["a"])(n).apply(this,arguments))}Object(o["a"])(n,[{key:"render",value:function(){var e
var r=this.props,a=r.wrap,o=r.weight,i=r.fontStyle,c=r.size,s=r.lineHeight,d=r.letterSpacing,l=r.transform,g=r.color,u=r.children
var p=Object(m["a"])(n,this.props)
return _.a.createElement(p,Object.assign({},Object(k["b"])(this.props),{className:b()((e={},Object(t["a"])(e,G.root,true),Object(t["a"])(e,G[c],c),Object(t["a"])(e,G["wrap-".concat(a)],a),Object(t["a"])(e,G["weight-".concat(o)],o),Object(t["a"])(e,G["style-".concat(i)],i),Object(t["a"])(e,G["transform-".concat(l)],l),Object(t["a"])(e,G["lineHeight-".concat(s)],s),Object(t["a"])(e,G["letterSpacing-".concat(d)],d),Object(t["a"])(e,G["color-".concat(g)],g),e)),ref:this.props.elementRef}),u)}}])
n.displayName="Text"
return n}(d["Component"]),w.propTypes={as:g.a.elementType,children:g.a.node,color:h["a"].deprecatePropValues(g.a.oneOf(["primary","secondary","brand","success","warning","error","danger","alert","primary-inverse","secondary-inverse"]),["error"],"It will be removed in version 8.0.0. Use `danger` instead."),elementRef:g.a.func,fontStyle:g.a.oneOf(["italic","normal"]),letterSpacing:g.a.oneOf(["normal","condensed","expanded"]),lineHeight:g.a.oneOf(["default","fit","condensed","double"]),size:g.a.oneOf(["x-small","small","medium","large","x-large","xx-large"]),transform:g.a.oneOf(["none","capitalize","uppercase","lowercase"]),weight:g.a.oneOf(["normal","light","bold"]),wrap:g.a.oneOf(["normal","break-word"])},w.defaultProps={as:"span",wrap:"normal",size:"medium",letterSpacing:"normal",children:null,elementRef:void 0,color:void 0,transform:void 0,lineHeight:void 0,fontStyle:void 0,weight:void 0},B))||y)},dqQ7:function(e,n,r){"use strict"
var t=r("An8g")
var a=r("q1tI")
var o=r.n(a)
r("17x9")
var i=r("i8i4")
var c=r.n(i)
var s=r("pQTu")
var d=r("m0r6")
Object(d["a"])(JSON.parse('{"ar":{"an_error_occurred_making_a_network_request_d1bda348":"حدث خطأ أثناء إجراء طلب شبكة","close_d634289d":"إغلاق","details_98a31b68":"التفاصيل"},"cy":{"an_error_occurred_making_a_network_request_d1bda348":"Gwall wrth wneud cais ar gyfer y rhwydwaith","close_d634289d":"Cau","details_98a31b68":"Manylion"},"da":{"an_error_occurred_making_a_network_request_d1bda348":"Der opstod en fejl under oprettelse af en netværksanmodning","close_d634289d":"Luk","details_98a31b68":"Nærmere oplysninger"},"da-x-k12":{"an_error_occurred_making_a_network_request_d1bda348":"Der opstod en fejl under oprettelse af en netværksanmodning","close_d634289d":"Luk","details_98a31b68":"Nærmere oplysninger"},"de":{"an_error_occurred_making_a_network_request_d1bda348":"Fehler beim einer Netzwerkanforderung","close_d634289d":"Schließen","details_98a31b68":"Details"},"el":{"close_d634289d":"Κλείσιμο","details_98a31b68":"Λεπτομέρειες"},"en-AU":{"an_error_occurred_making_a_network_request_d1bda348":"An error occurred making a network request","close_d634289d":"Close","details_98a31b68":"Details"},"en-CA":{"an_error_occurred_making_a_network_request_d1bda348":"An error occurred making a network request","close_d634289d":"Close","details_98a31b68":"Details"},"en-GB":{"an_error_occurred_making_a_network_request_d1bda348":"An error occurred making a network request","close_d634289d":"Close","details_98a31b68":"Details"},"es":{"an_error_occurred_making_a_network_request_d1bda348":"Se produjo un error al realizar una solicitud de red","close_d634289d":"Cerrar","details_98a31b68":"Detalles"},"fa":{"an_error_occurred_making_a_network_request_d1bda348":"برای یک  درخواست شبکه خطا رخ داده است","close_d634289d":"بستن","details_98a31b68":"اطلاعات"},"fi":{"an_error_occurred_making_a_network_request_d1bda348":"Ilmeni virhe tehtäessä verkkopyyntöä","close_d634289d":"Sulje","details_98a31b68":"Lisätiedot"},"fr":{"an_error_occurred_making_a_network_request_d1bda348":"Une erreur est survenue lors de la réalisation d\'une requête réseau","close_d634289d":"Fermer","details_98a31b68":"Détails"},"fr-CA":{"an_error_occurred_making_a_network_request_d1bda348":"Une erreur s\'est produite en faisant une demande de réseau","close_d634289d":"Fermer","details_98a31b68":"Informations"},"he":{"an_error_occurred_making_a_network_request_d1bda348":"אירעה שגיאה ביצירת בקשת רשת","close_d634289d":"סגירה","details_98a31b68":"פרטים"},"ht":{"an_error_occurred_making_a_network_request_d1bda348":"Gen yon erè ki fèt pandan demann rezo a","close_d634289d":"Fèmen","details_98a31b68":"Detay"},"hu":{"an_error_occurred_making_a_network_request_d1bda348":"Hiba történt egy hálózati kérelem létrehozásakor","close_d634289d":"Bezárás","details_98a31b68":"Részletek"},"hy":{"close_d634289d":"Փակել"},"is":{"an_error_occurred_making_a_network_request_d1bda348":"Villa kom upp við netbeiðni","close_d634289d":"Loka","details_98a31b68":"Upplýsingar"},"it":{"an_error_occurred_making_a_network_request_d1bda348":"Si è verificato un errore durante la creazione di una richiesta di rete","close_d634289d":"Chiudi","details_98a31b68":"Dettagli"},"ja":{"an_error_occurred_making_a_network_request_d1bda348":"ネットワーク要求の作成中にエラーが発生しました","close_d634289d":"閉じる","details_98a31b68":"詳細"},"ko":{"close_d634289d":"닫기"},"mi":{"an_error_occurred_making_a_network_request_d1bda348":"I puta he hapa i te wā e hanga ana i te tono whatunga","close_d634289d":"Katia","details_98a31b68":"Ngā taipitopito"},"nb":{"an_error_occurred_making_a_network_request_d1bda348":"Det oppstod en feil ved utførelse av en nettverksforespørsel","close_d634289d":"Lukk","details_98a31b68":"Detaljer"},"nb-x-k12":{"an_error_occurred_making_a_network_request_d1bda348":"Det oppstod en feil ved utførelse av en nettverksforespørsel","close_d634289d":"Lukk","details_98a31b68":"Detaljer"},"nl":{"an_error_occurred_making_a_network_request_d1bda348":"Er is een fout opgetreden bij het maken van een netwerkaanvraag","close_d634289d":"Sluiten","details_98a31b68":"Details"},"nn":{"an_error_occurred_making_a_network_request_d1bda348":"Det oppstod ein feil ved nettverksførespurnaden ","close_d634289d":"Lukk","details_98a31b68":"Detaljar"},"pl":{"an_error_occurred_making_a_network_request_d1bda348":"Wystąpił błąd podczas przesyłania żądania sieciowego","close_d634289d":"Zamknij","details_98a31b68":"Informacje szczegółowe:"},"pt":{"an_error_occurred_making_a_network_request_d1bda348":"Ocorreu um erro ao fazer uma solicitação de rede","close_d634289d":"Fechar","details_98a31b68":"Detalhes"},"pt-BR":{"an_error_occurred_making_a_network_request_d1bda348":"Um erro ocorreu ao fazer uma solicitação de rede","close_d634289d":"Fechar","details_98a31b68":"Detalhes"},"ru":{"an_error_occurred_making_a_network_request_d1bda348":"Произошла ошибка, что привело к созданию сетевого запроса","close_d634289d":"Закрыть","details_98a31b68":"Сведения"},"sl":{"an_error_occurred_making_a_network_request_d1bda348":"Med podajanjem omrežne zahteve je prišlo do napake.","close_d634289d":"Zapri","details_98a31b68":"Podrobnosti"},"sv":{"an_error_occurred_making_a_network_request_d1bda348":"Ett fel uppstod vid försök att göra en nätverksförfrågan","close_d634289d":"Stäng","details_98a31b68":"Information"},"sv-x-k12":{"an_error_occurred_making_a_network_request_d1bda348":"Ett fel uppstod vid försök att göra en nätverksförfrågan","close_d634289d":"Stäng","details_98a31b68":"Information"},"tr":{"an_error_occurred_making_a_network_request_d1bda348":"Ağ isteğinde bulunurken bir hata oluştu","close_d634289d":"Kapat","details_98a31b68":"Ayrıntılar"},"uk":{"an_error_occurred_making_a_network_request_d1bda348":"Сталася помилка при виконанні запиту мережі","close_d634289d":"Закрити","details_98a31b68":"Подробиці"},"zh-Hans":{"an_error_occurred_making_a_network_request_d1bda348":"发出网络请求时出错","close_d634289d":"关闭","details_98a31b68":"详细信息、细节"},"zh-Hant":{"an_error_occurred_making_a_network_request_d1bda348":"發出連線請求時發生錯誤","close_d634289d":"關閉","details_98a31b68":"詳細資料"}}'))
r("jQeR")
r("0sPK")
var _=s["default"].scoped("ajaxflashalert")
var l=r("L+/K")
var g=r("Xx/m")
var u=r("ZbPE")
var b=r("CO+y")
var p=r("6SzX")
var m=r("XQb/")
r.d(n,"a",(function(){return y}))
r.d(n,"b",(function(){return w}))
r.d(n,"c",(function(){return B}))
const k="flashalert_message_holder"
const h="flash_screenreader_holder"
const f=1e4
var R=Object(t["a"])("br",{})
class v extends o.a.Component{constructor(e){super(e)
this.showDetails=()=>{this.setState({showDetails:true})
clearTimeout(this.timerId)
this.timerId=setTimeout(()=>this.closeAlert(),this.props.timeout)}
this.closeAlert=()=>{this.setState({isOpen:false},()=>{setTimeout(()=>{clearTimeout(this.timerId)
this.props.onClose()},500)})}
this.state={showDetails:false,isOpen:true}
this.timerId=0}getLiveRegion(){let e=document.getElementById(h)
if(!e){e=document.createElement("div")
e.id=h
e.setAttribute("role","alert")
document.body.appendChild(e)}return e}findDetailMessage(){const e=this.props.error
let n=e.message
let r
if(e.response&&e.response.data)try{if(Array.isArray(e.response.data.errors)){n=e.response.data.errors[0].message
r=e.message}else if(e.response.data.message){n=e.response.data.message
r=e.message}}catch(r){n=e.message}return{a:n,b:r}}renderDetailMessage(){const e=this.findDetailMessage(),n=e.a,r=e.b
return Object(t["a"])(u["a"],{as:"p",fontStyle:"italic"},void 0,Object(t["a"])(u["a"],{},void 0,n),r?R:null,r?Object(t["a"])(u["a"],{},void 0,r):null)}render(){let e=null
this.props.error&&(e=this.state.showDetails?this.renderDetailMessage():Object(t["a"])("span",{},void 0,Object(t["a"])(b["a"],{},void 0,Object(t["a"])(g["a"],{variant:"link",onClick:this.showDetails},void 0,_.t("Details"))),Object(t["a"])(p["a"],{},void 0,this.renderDetailMessage())))
return Object(t["a"])(m["a"],{transitionOnMount:true,in:this.state.isOpen,type:"fade"},void 0,Object(t["a"])(l["a"],{variant:this.props.variant,renderCloseButtonLabel:_.t("Close"),onDismiss:this.closeAlert,margin:"small auto",timeout:this.props.timeout,liveRegion:this.getLiveRegion,transition:"fade",screenReaderOnly:this.props.screenReaderOnly},void 0,Object(t["a"])("div",{},void 0,Object(t["a"])("p",{style:{margin:"0 -5px"}},void 0,this.props.message),e)))}}v.defaultProps={error:null,variant:"info",timeout:f,screenReaderOnly:false}
function y(e){let n=e.message,r=e.err,a=e.type,o=void 0===a?r?"error":"info":a,i=e.srOnly,s=void 0!==i&&i
function d(e){c.a.unmountComponentAtNode(e)
e.remove()}function _(){let e=document.getElementById(k)
if(!e){e=document.createElement("div")
e.classList.add("clickthrough-container")
e.id=k
e.setAttribute("style","position: fixed; top: 0; left: 0; width: 100%; z-index: 100000;")
document.body.appendChild(e)}return e}function l(e){c.a.render(Object(t["a"])(v,{message:n,timeout:isNaN(ENV.flashAlertTimeout)?f:ENV.flashAlertTimeout,error:r,variant:o,onClose:d.bind(null,e),screenReaderOnly:s}),e)}const g=document.createElement("div")
g.setAttribute("style","max-width:50em;margin:1rem auto;")
g.setAttribute("class","flashalert-message")
_().appendChild(g)
l(g)}function w(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:_.t("An error occurred making a network request")
return n=>y({message:e,err:n,type:"error"})}function B(e){return()=>y({message:e,type:"success"})}}}])

//# sourceMappingURL=34-c-6db797c6d2.js.map