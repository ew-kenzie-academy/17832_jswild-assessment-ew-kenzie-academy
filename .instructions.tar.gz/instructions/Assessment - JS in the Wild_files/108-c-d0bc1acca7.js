(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[108],{"+Gzo":function(e,n,t){"use strict"
t.d(n,"a",(function(){return p}))
var a=t("VTBJ")
var i=t("1OyB")
var r=t("vuIU")
var o=t("md7G")
var c=t("foSv")
var l=t("Ji7U")
var s=t("q1tI")
var d=t.n(s)
var f=t("hPGw")
var b=d.a.createElement("path",{d:"M1706.235 1807.059H350.941V112.94h903.53v451.765h451.764v1242.353zm-338.823-1670.74l315.443 315.447h-315.443V136.32zm402.182 242.487L1440.372 49.58C1408.296 17.62 1365.717 0 1320.542 0H238v1920h1581.175V498.635c0-45.176-17.618-87.755-49.58-119.83zM576.823 1242.353h790.589v-112.94H576.823v112.94zm0-451.765h903.53V677.647h-903.53v112.941zm0 677.647h451.765v-112.941H576.823v112.941zm0-451.764h677.648V903.53H576.823v112.941zm0-451.765h451.765V451.765H576.823v112.941z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(l["a"])(n,e)
function n(){Object(i["a"])(this,n)
return Object(o["a"])(this,Object(c["a"])(n).apply(this,arguments))}Object(r["a"])(n,[{key:"render",value:function(){return d.a.createElement(f["a"],Object.assign({},this.props,{name:"IconDocument",viewBox:"0 0 1920 1920",bidirectional:true}),b)}}])
n.displayName="IconDocumentLine"
return n}(s["Component"])
p.glyphName="document"
p.variant="Line"
p.propTypes=Object(a["a"])({},f["a"].propTypes)},"+Pml":function(e,n,t){"use strict"
t.d(n,"a",(function(){return p}))
var a=t("VTBJ")
var i=t("1OyB")
var r=t("vuIU")
var o=t("md7G")
var c=t("foSv")
var l=t("Ji7U")
var s=t("q1tI")
var d=t.n(s)
var f=t("hPGw")
var b=d.a.createElement("path",{d:"M1807.059 1637.706c0 31.172-25.412 56.47-56.47 56.47H169.411c-31.06 0-56.47-25.298-56.47-56.47V225.94h590.907L854.4 451.824H225.882v112.94H1807.06v1072.942zM990.269 451.824L764.385 113H0v1524.706c0 93.402 76.01 169.412 169.412 169.412h1581.176c93.403 0 169.412-76.01 169.412-169.412V451.824H990.268z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(l["a"])(n,e)
function n(){Object(i["a"])(this,n)
return Object(o["a"])(this,Object(c["a"])(n).apply(this,arguments))}Object(r["a"])(n,[{key:"render",value:function(){return d.a.createElement(f["a"],Object.assign({},this.props,{name:"IconFolder",viewBox:"0 0 1920 1920",bidirectional:true}),b)}}])
n.displayName="IconFolderLine"
return n}(s["Component"])
p.glyphName="folder"
p.variant="Line"
p.propTypes=Object(a["a"])({},f["a"].propTypes)},"97gy":function(e,n,t){"use strict"
t.d(n,"a",(function(){return p}))
var a=t("VTBJ")
var i=t("1OyB")
var r=t("vuIU")
var o=t("md7G")
var c=t("foSv")
var l=t("Ji7U")
var s=t("q1tI")
var d=t.n(s)
var f=t("hPGw")
var b=d.a.createElement("path",{d:"M1743.858 267.012L710.747 1300.124 176.005 765.382 0 941.387l710.747 710.871 1209.24-1209.116z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(l["a"])(n,e)
function n(){Object(i["a"])(this,n)
return Object(o["a"])(this,Object(c["a"])(n).apply(this,arguments))}Object(r["a"])(n,[{key:"render",value:function(){return d.a.createElement(f["a"],Object.assign({},this.props,{name:"IconCheckMark",viewBox:"0 0 1920 1920"}),b)}}])
n.displayName="IconCheckMarkSolid"
return n}(s["Component"])
p.glyphName="check-mark"
p.variant="Solid"
p.propTypes=Object(a["a"])({},f["a"].propTypes)},T4PM:function(e,n,t){"use strict"
var a=t("VTBJ")
var i=t("rePB")
var r=t("Ff2n")
var o=t("1OyB")
var c=t("vuIU")
var l=t("md7G")
var s=t("foSv")
var d=t("Ji7U")
var f=t("q1tI")
var b=t.n(f)
var p=t("17x9")
var m=t.n(p)
var h=t("TSYQ")
var u=t.n(h)
var g=t("n12J")
var O=t("J2CL")
var _=t("nAyT")
var v=t("jtGx")
var B=t("1I77")
var T=t("oXx0")
function y(){return{effectTransitionDuration:"1s",imageBlurAmount:"0.25em"}}t.d(n,"a",(function(){return x}))
var C,w,S,k,z,j
var W={componentId:"bzhOW",template:function(e){return"\n\n.bzhOW_EtBB{bottom:auto;float:none;left:auto;line-height:normal;margin:0;max-height:none;max-width:100%;min-height:0;min-width:0;padding:0;position:static;right:auto;top:auto;transform:none}\n\n[dir=ltr] .bzhOW_EtBB,[dir=rtl] .bzhOW_EtBB{float:none}\n\n.bzhOW_fJwG{display:inline-block;vertical-align:middle}\n\n.bzhOW_cYkL{height:100%;left:0px;position:absolute;top:0px;width:100%}\n\n.bzhOW_fqss{display:block}\n\n.bzhOW_dIXK,.bzhOW_cYkL{transition:all ".concat(e.effectTransitionDuration||"inherit","}\n\n.bzhOW_fZcw,.bzhOW_dETD,.bzhOW_bPct,.bzhOW_eJVL{height:100%;width:100%}\n\n.bzhOW_eJVL{object-fit:cover}\n\n.bzhOW_fZcw{object-fit:contain}\n\n.bzhOW_fZcw.bzhOW_fqss{height:auto;max-height:100%;max-width:100%;width:auto}\n\n.bzhOW_baUy{height:inherit}\n\n.bzhOW_dETD{background-position:50%;background-repeat:no-repeat}\n\n.bzhOW_dETD.bzhOW_baUy{background-size:contain}\n\n.bzhOW_dETD.bzhOW_bPct{background-size:cover}\n\n.bzhOW_rUUn{overflow:hidden;position:relative}")},image:"bzhOW_EtBB",overlayLayout:"bzhOW_fJwG",overlay:"bzhOW_cYkL","has-overlay":"bzhOW_fqss","has-filter":"bzhOW_dIXK",contain:"bzhOW_fZcw","container--has-background":"bzhOW_dETD","container--has-cover":"bzhOW_bPct",cover:"bzhOW_eJVL","container--has-contain":"bzhOW_baUy","container--has-overlay":"bzhOW_rUUn"}
var x=(C=Object(_["a"])("8.0.0",{grayscale:"withGrayscale",blur:"withBlur",inline:"display"}),w=Object(T["a"])(),S=Object(O["themeable"])(y,W),C(k=w(k=S(k=(j=z=function(e){Object(d["a"])(n,e)
function n(){Object(o["a"])(this,n)
return Object(l["a"])(this,Object(s["a"])(n).apply(this,arguments))}Object(c["a"])(n,[{key:"renderFilter",value:function(){var e="blur(".concat(this.theme.imageBlurAmount,")")
var n="grayscale(1)"
return(this.props.withGrayscale||this.props.grayscale)&&(this.props.withBlur||this.props.blur)?"".concat(e," ").concat(n):this.props.withGrayscale||this.props.grayscale?n:this.props.withBlur||this.props.blur?e:null}},{key:"render",value:function(){var e
var n=this.props,t=n.src,o=n.alt,c=n.margin,l=n.display,s=n.overlay,d=n.withGrayscale,f=n.withBlur,p=n.constrain,m=n.width,h=n.height,O=n.elementRef,_=n.inline,B=n.blur,T=n.grayscale,y=Object(r["a"])(n,["src","alt","margin","display","overlay","withGrayscale","withBlur","constrain","width","height","elementRef","inline","blur","grayscale"])
var C={alt:o||""}
var w={className:u()((e={},Object(i["a"])(e,W.image,true),Object(i["a"])(e,W["has-overlay"],s),Object(i["a"])(e,W["has-filter"],f||d||B||T),Object(i["a"])(e,W.cover,this.supportsObjectFit&&"cover"===p),Object(i["a"])(e,W.contain,this.supportsObjectFit&&"contain"===p),e)),style:{filter:f||d||B||T?this.renderFilter():"none"},src:t}
var S=Object(a["a"])({},Object(v["b"])(y),{width:m,height:h,margin:c,display:"block"===l||false===_?"block":"inline-block",elementRef:O})
var k=!this.supportsObjectFit&&this.props.constrain
if(s||k){var z
var j=k?Object(a["a"])({},C,{},S):S
return b.a.createElement(g["a"],Object.assign({},j,{as:"span",className:u()((z={},Object(i["a"])(z,W["container--has-overlay"],s),Object(i["a"])(z,W["container--has-cover"],"cover"===p),Object(i["a"])(z,W["container--has-contain"],"contain"===p),Object(i["a"])(z,W["container--has-background"],k),z)),style:{backgroundImage:k?"url(".concat(t,")"):void 0}}),!k&&b.a.createElement("img",Object.assign({},w,C)),s&&b.a.createElement("span",{className:W.overlay,style:{backgroundColor:s.color,opacity:.1*s.opacity,mixBlendMode:s.blend?s.blend:null}}))}return b.a.createElement(g["a"],Object.assign({},S,w,C,{as:"img"}))}},{key:"supportsObjectFit",get:function(){return Object(B["a"])()}}])
n.displayName="Img"
return n}(f["Component"]),z.propTypes={src:m.a.string.isRequired,alt:m.a.string,display:m.a.oneOf(["inline-block","block"]),margin:O["ThemeablePropTypes"].spacing,overlay:m.a.shape({color:m.a.string.isRequired,opacity:m.a.oneOf([0,1,2,3,4,5,6,7,8,9,10]).isRequired,blend:m.a.oneOf(["normal","multiply","screen","overlay","color-burn"])}),withGrayscale:m.a.bool,withBlur:m.a.bool,constrain:m.a.oneOf(["cover","contain"]),elementRef:m.a.func,height:m.a.oneOfType([m.a.string,m.a.number]),width:m.a.oneOfType([m.a.string,m.a.number]),inline:m.a.bool,grayscale:m.a.bool,blur:m.a.bool},z.defaultProps={margin:void 0,overlay:void 0,constrain:void 0,elementRef:void 0,height:void 0,width:void 0,alt:"",display:"inline-block",withGrayscale:false,withBlur:false},j))||k)||k)||k)},TU4e:function(e,n,t){"use strict"
var a=t("VTBJ")
var i=t("1OyB")
var r=t("vuIU")
var o=t("md7G")
var c=t("foSv")
var l=t("Ji7U")
var s=t("q1tI")
var d=t.n(s)
var f=t("17x9")
var b=t.n(f)
var p=t("3zPy")
var m=t.n(p)
var h=t("+Pml")
var u=t("+Gzo")
var g=t("J2CL")
var O=t("jtGx")
var _=t("cClk")
var v=t("oXx0")
var B=t("rePB")
var T=t("TSYQ")
var y=t.n(T)
var C=t("8S//")
var w=t("M4Ft")
var S=t("T4PM")
function k(e){var n=e.colors,t=e.spacing,a=e.typography,i=e.borders
return{hoverBackgroundColor:n.backgroundBrand,hoverTextColor:n.textLightest,focusOutlineWidth:i.widthMedium,focusOutlineColor:n.borderBrand,focusOutlineStyle:i.style,iconColor:n.textDarkest,iconsMarginRight:t.xSmall,descriptorMarginTop:t.xxxSmall,descriptorTextColor:n.textDarkest,descriptorFontSizeSmall:a.fontSizeXSmall,descriptorFontSizeMedium:a.fontSizeXSmall,descriptorFontSizeLarge:a.fontSizeSmall,nameTextColor:n.textBrand,nameFontSizeSmall:a.fontSizeXSmall,nameFontSizeMedium:a.fontSizeSmall,nameFontSizeLarge:a.fontSizeMedium,baseSpacingSmall:t.xSmall,baseSpacingMedium:t.small,baseSpacingLarge:"1rem",borderWidth:i.widthSmall,borderRadius:i.radiusMedium,borderColor:n.borderDark,textLineHeight:a.lineHeightCondensed,selectedTextColor:n.textLightest,selectedBackgroundColor:n.backgroundDark,selectedOutlineWidth:i.widthLarge}}k["canvas"]=function(e){return{iconColor:e["ic-brand-font-color-dark"],hoverBackgroundColor:e["ic-brand-primary"],focusOutlineColor:e["ic-brand-primary"],nameTextColor:e["ic-brand-primary"],descriptorTextColor:e["ic-brand-font-color-dark"]}}
var z,j,W,x,I
var X={componentId:"bfBOT",template:function(e){return"\n\n@keyframes bfBOT_EwaR{50%{opacity:0.5;transform:translate3d(2%,0,0)}to{opacity:1;transform:translateZ(0)}}\n\n.bfBOT_bGBk{-moz-user-select:none;-ms-user-select:none;-webkit-user-select:none;animation-delay:0.2s;animation-duration:0.2s;animation-fill-mode:forwards;animation-name:bfBOT_EwaR;animation-timing-function:ease-out;background-color:transparent;border:none;border-radius:".concat(e.borderRadius||"inherit",";box-sizing:border-box;cursor:pointer;display:block;font-family:inherit;margin:0;opacity:0.01;outline:0;position:relative;text-align:start;transform:translate3d(-2%,0,0);transform-origin:left center;user-select:none;width:100%;z-index:1}\n\n[dir=ltr] .bfBOT_bGBk{text-align:left}\n\n[dir=rtl] .bfBOT_bGBk{text-align:right}\n\n.bfBOT_bGBk:not(.bfBOT_eoSs):after{border:").concat(e.focusOutlineWidth||"inherit"," ").concat(e.focusOutlineStyle||"inherit"," ").concat(e.focusOutlineColor||"inherit",";border-radius:calc(").concat(e.borderRadius||"inherit",'*1.5);bottom:-0.25rem;box-sizing:border-box;content:"";display:block;left:-0.25rem;opacity:0;pointer-events:none;position:absolute;right:-0.25rem;top:-0.25rem;transform:scale(0.95);transition:all 0.2s}\n\n.bfBOT_bGBk:hover{background-color:').concat(e.hoverBackgroundColor||"inherit","}\n\n.bfBOT_bGBk:hover.bfBOT_fGhm{background-color:").concat(e.selectedBackgroundColor||"inherit","}\n\n.bfBOT_bGBk:hover.bfBOT_ewdC:before{visibility:hidden}\n\n.bfBOT_bGBk:hover .bfBOT_dnnz,.bfBOT_bGBk:hover .bfBOT_biFO,.bfBOT_bGBk:hover .bfBOT_sTpL{color:").concat(e.hoverTextColor||"inherit","}\n\n.bfBOT_bGBk.bfBOT_cVYB:not(.bfBOT_eoSs):after{opacity:1;transform:scale(1)}\n\n.bfBOT_bGBk.bfBOT_cVYB.bfBOT_eoSs{outline:").concat(e.focusOutlineWidth||"inherit"," ").concat(e.focusOutlineStyle||"inherit"," ").concat(e.focusOutlineColor||"inherit","}\n\n.bfBOT_byIz{align-items:center;display:flex;line-height:1;min-height:2rem}\n\n.bfBOT_dnnz,.bfBOT_eWKC{min-width:0.0625rem}\n\n.bfBOT_dnnz{color:").concat(e.iconColor||"inherit",";position:relative;z-index:1}\n\n.bfBOT_eWKC{flex:1;line-height:").concat(e.textLineHeight||"inherit","}\n\n.bfBOT_biFO,.bfBOT_sTpL{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n\n.bfBOT_sTpL{color:").concat(e.nameTextColor||"inherit","}\n\n.bfBOT_biFO{color:").concat(e.descriptorTextColor||"inherit",";margin-top:").concat(e.descriptorMarginTop||"inherit","}\n\n.bfBOT_ewdC:before{background:").concat(e.borderColor||"inherit",';content:"";height:').concat(e.borderWidth||"inherit",";inset-inline-end:auto;inset-inline-start:0;pointer-events:none;position:absolute;top:50%}\n\n[dir=ltr] .bfBOT_ewdC:before{left:0;right:auto}\n\n[dir=rtl] .bfBOT_ewdC:before{left:auto;right:0}\n\n.bfBOT_doqw.bfBOT_ewdC{padding:calc(").concat(e.baseSpacingSmall||"inherit","/3) ").concat(e.baseSpacingSmall||"inherit","}\n\n.bfBOT_doqw.bfBOT_ewdC:before{width:calc(").concat(e.baseSpacingSmall||"inherit"," - 0.0625rem)}\n\n.bfBOT_doqw.bfBOT_ewdC .bfBOT_dnnz,.bfBOT_doqw.bfBOT_ewdC .bfBOT_dXYn{-webkit-margin-end:").concat(e.baseSpacingSmall||"inherit",";-webkit-margin-start:0;margin-inline-end:").concat(e.baseSpacingSmall||"inherit",";margin-inline-start:0}\n\n[dir=ltr] .bfBOT_doqw.bfBOT_ewdC .bfBOT_dnnz,[dir=ltr] .bfBOT_doqw.bfBOT_ewdC .bfBOT_dXYn{margin-left:0;margin-right:").concat(e.baseSpacingSmall||"inherit","}\n\n[dir=rtl] .bfBOT_doqw.bfBOT_ewdC .bfBOT_dnnz,[dir=rtl] .bfBOT_doqw.bfBOT_ewdC .bfBOT_dXYn{margin-left:").concat(e.baseSpacingSmall||"inherit",";margin-right:0}\n\n.bfBOT_doqw.bfBOT_ewdC .bfBOT_dnnz{font-size:calc(").concat(e.baseSpacingSmall||"inherit","*2)}\n\n.bfBOT_doqw.bfBOT_ewdC .bfBOT_dXYn{height:calc(").concat(e.baseSpacingSmall||"inherit","*2);width:calc(").concat(e.baseSpacingSmall||"inherit","*2)}\n\n.bfBOT_doqw.bfBOT_cIHp{padding:calc(").concat(e.baseSpacingSmall||"inherit","/3) calc(").concat(e.baseSpacingSmall||"inherit","/2)}\n\n.bfBOT_doqw.bfBOT_cIHp .bfBOT_dnnz,.bfBOT_doqw.bfBOT_cIHp .bfBOT_dXYn{-webkit-margin-end:calc(").concat(e.baseSpacingSmall||"inherit","/2);-webkit-margin-start:0;margin-inline-end:calc(").concat(e.baseSpacingSmall||"inherit","/2);margin-inline-start:0}\n\n[dir=ltr] .bfBOT_doqw.bfBOT_cIHp .bfBOT_dnnz,[dir=ltr] .bfBOT_doqw.bfBOT_cIHp .bfBOT_dXYn{margin-left:0;margin-right:calc(").concat(e.baseSpacingSmall||"inherit","/2)}\n\n[dir=rtl] .bfBOT_doqw.bfBOT_cIHp .bfBOT_dnnz,[dir=rtl] .bfBOT_doqw.bfBOT_cIHp .bfBOT_dXYn{margin-left:calc(").concat(e.baseSpacingSmall||"inherit","/2);margin-right:0}\n\n.bfBOT_doqw.bfBOT_cIHp .bfBOT_dnnz{font-size:calc(").concat(e.baseSpacingSmall||"inherit","*2)}\n\n.bfBOT_doqw.bfBOT_cIHp .bfBOT_dXYn{height:calc(").concat(e.baseSpacingSmall||"inherit","*2);width:calc(").concat(e.baseSpacingSmall||"inherit","*2)}\n\n.bfBOT_doqw .bfBOT_sTpL{font-size:").concat(e.nameFontSizeSmall||"inherit","}\n\n.bfBOT_doqw .bfBOT_biFO{font-size:").concat(e.descriptorFontSizeSmall||"inherit","}\n\n.bfBOT_ycrn.bfBOT_ewdC{padding:calc(").concat(e.baseSpacingMedium||"inherit","/3) ").concat(e.baseSpacingMedium||"inherit","}\n\n.bfBOT_ycrn.bfBOT_ewdC:before{width:calc(").concat(e.baseSpacingMedium||"inherit"," - 0.0625rem)}\n\n.bfBOT_ycrn.bfBOT_ewdC .bfBOT_dnnz,.bfBOT_ycrn.bfBOT_ewdC .bfBOT_dXYn{-webkit-margin-end:").concat(e.baseSpacingMedium||"inherit",";-webkit-margin-start:0;margin-inline-end:").concat(e.baseSpacingMedium||"inherit",";margin-inline-start:0}\n\n[dir=ltr] .bfBOT_ycrn.bfBOT_ewdC .bfBOT_dnnz,[dir=ltr] .bfBOT_ycrn.bfBOT_ewdC .bfBOT_dXYn{margin-left:0;margin-right:").concat(e.baseSpacingMedium||"inherit","}\n\n[dir=rtl] .bfBOT_ycrn.bfBOT_ewdC .bfBOT_dnnz,[dir=rtl] .bfBOT_ycrn.bfBOT_ewdC .bfBOT_dXYn{margin-left:").concat(e.baseSpacingMedium||"inherit",";margin-right:0}\n\n.bfBOT_ycrn.bfBOT_ewdC .bfBOT_dnnz{font-size:calc(").concat(e.baseSpacingMedium||"inherit","*2)}\n\n.bfBOT_ycrn.bfBOT_ewdC .bfBOT_dXYn{height:calc(").concat(e.baseSpacingMedium||"inherit","*2);width:calc(").concat(e.baseSpacingMedium||"inherit","*2)}\n\n.bfBOT_ycrn.bfBOT_cIHp{padding:calc(").concat(e.baseSpacingMedium||"inherit","/3) calc(").concat(e.baseSpacingMedium||"inherit","/2)}\n\n.bfBOT_ycrn.bfBOT_cIHp .bfBOT_dnnz,.bfBOT_ycrn.bfBOT_cIHp .bfBOT_dXYn{-webkit-margin-end:calc(").concat(e.baseSpacingMedium||"inherit","/2);-webkit-margin-start:0;margin-inline-end:calc(").concat(e.baseSpacingMedium||"inherit","/2);margin-inline-start:0}\n\n[dir=ltr] .bfBOT_ycrn.bfBOT_cIHp .bfBOT_dnnz,[dir=ltr] .bfBOT_ycrn.bfBOT_cIHp .bfBOT_dXYn{margin-left:0;margin-right:calc(").concat(e.baseSpacingMedium||"inherit","/2)}\n\n[dir=rtl] .bfBOT_ycrn.bfBOT_cIHp .bfBOT_dnnz,[dir=rtl] .bfBOT_ycrn.bfBOT_cIHp .bfBOT_dXYn{margin-left:calc(").concat(e.baseSpacingMedium||"inherit","/2);margin-right:0}\n\n.bfBOT_ycrn.bfBOT_cIHp .bfBOT_dnnz{font-size:calc(").concat(e.baseSpacingMedium||"inherit","*2)}\n\n.bfBOT_ycrn.bfBOT_cIHp .bfBOT_dXYn{height:calc(").concat(e.baseSpacingMedium||"inherit","*2);width:calc(").concat(e.baseSpacingMedium||"inherit","*2)}\n\n.bfBOT_ycrn .bfBOT_sTpL{font-size:").concat(e.nameFontSizeMedium||"inherit","}\n\n.bfBOT_ycrn .bfBOT_biFO{font-size:").concat(e.descriptorFontSizeMedium||"inherit","}\n\n.bfBOT_cMDj.bfBOT_ewdC{padding:calc(").concat(e.baseSpacingLarge||"inherit","/3) ").concat(e.baseSpacingLarge||"inherit","}\n\n.bfBOT_cMDj.bfBOT_ewdC:before{width:calc(").concat(e.baseSpacingLarge||"inherit"," - 0.0625rem)}\n\n.bfBOT_cMDj.bfBOT_ewdC .bfBOT_dnnz,.bfBOT_cMDj.bfBOT_ewdC .bfBOT_dXYn{-webkit-margin-end:").concat(e.baseSpacingLarge||"inherit",";-webkit-margin-start:0;margin-inline-end:").concat(e.baseSpacingLarge||"inherit",";margin-inline-start:0}\n\n[dir=ltr] .bfBOT_cMDj.bfBOT_ewdC .bfBOT_dnnz,[dir=ltr] .bfBOT_cMDj.bfBOT_ewdC .bfBOT_dXYn{margin-left:0;margin-right:").concat(e.baseSpacingLarge||"inherit","}\n\n[dir=rtl] .bfBOT_cMDj.bfBOT_ewdC .bfBOT_dnnz,[dir=rtl] .bfBOT_cMDj.bfBOT_ewdC .bfBOT_dXYn{margin-left:").concat(e.baseSpacingLarge||"inherit",";margin-right:0}\n\n.bfBOT_cMDj.bfBOT_ewdC .bfBOT_dnnz{font-size:calc(").concat(e.baseSpacingLarge||"inherit","*2)}\n\n.bfBOT_cMDj.bfBOT_ewdC .bfBOT_dXYn{height:calc(").concat(e.baseSpacingLarge||"inherit","*2);width:calc(").concat(e.baseSpacingLarge||"inherit","*2)}\n\n.bfBOT_cMDj.bfBOT_cIHp{padding:calc(").concat(e.baseSpacingLarge||"inherit","/3) calc(").concat(e.baseSpacingLarge||"inherit","/2)}\n\n.bfBOT_cMDj.bfBOT_cIHp .bfBOT_dnnz,.bfBOT_cMDj.bfBOT_cIHp .bfBOT_dXYn{-webkit-margin-end:calc(").concat(e.baseSpacingLarge||"inherit","/2);-webkit-margin-start:0;margin-inline-end:calc(").concat(e.baseSpacingLarge||"inherit","/2);margin-inline-start:0}\n\n[dir=ltr] .bfBOT_cMDj.bfBOT_cIHp .bfBOT_dnnz,[dir=ltr] .bfBOT_cMDj.bfBOT_cIHp .bfBOT_dXYn{margin-left:0;margin-right:calc(").concat(e.baseSpacingLarge||"inherit","/2)}\n\n[dir=rtl] .bfBOT_cMDj.bfBOT_cIHp .bfBOT_dnnz,[dir=rtl] .bfBOT_cMDj.bfBOT_cIHp .bfBOT_dXYn{margin-left:calc(").concat(e.baseSpacingLarge||"inherit","/2);margin-right:0}\n\n.bfBOT_cMDj.bfBOT_cIHp .bfBOT_dnnz{font-size:calc(").concat(e.baseSpacingLarge||"inherit","*2)}\n\n.bfBOT_cMDj.bfBOT_cIHp .bfBOT_dXYn{height:calc(").concat(e.baseSpacingLarge||"inherit","*2);width:calc(").concat(e.baseSpacingLarge||"inherit","*2)}\n\n.bfBOT_cMDj .bfBOT_sTpL{font-size:").concat(e.nameFontSizeLarge||"inherit","}\n\n.bfBOT_cMDj .bfBOT_biFO{font-size:").concat(e.descriptorFontSizeLarge||"inherit","}\n\n.bfBOT_fGhm{background-color:").concat(e.selectedBackgroundColor||"inherit","}\n\n.bfBOT_fGhm.bfBOT_ewdC:before{visibility:hidden}\n\n.bfBOT_fGhm .bfBOT_dnnz,.bfBOT_fGhm .bfBOT_biFO,.bfBOT_fGhm .bfBOT_sTpL{color:").concat(e.selectedTextColor||"inherit","}")},root:"bfBOT_bGBk",button:"bfBOT_EwaR",ie11:"bfBOT_eoSs",selected:"bfBOT_fGhm",folderTree:"bfBOT_ewdC",icon:"bfBOT_dnnz",textDescriptor:"bfBOT_biFO",textName:"bfBOT_sTpL",focused:"bfBOT_cVYB",layout:"bfBOT_byIz",text:"bfBOT_eWKC",small:"bfBOT_doqw",thumbnail:"bfBOT_dXYn",indent:"bfBOT_cIHp",medium:"bfBOT_ycrn",large:"bfBOT_cMDj"}
var M=(z=Object(v["a"])(),j=Object(g["themeable"])(k,X),z(W=j(W=(I=x=function(e){Object(l["a"])(n,e)
function n(){Object(i["a"])(this,n)
return Object(o["a"])(this,Object(c["a"])(n).apply(this,arguments))}Object(r["a"])(n,[{key:"renderImage",value:function(){var e=this.props.type
switch(e){case"collection":return this.renderCollectionIcon()
case"item":return this.renderItemImage()}}},{key:"renderCollectionIcon",value:function(){var e=this.props.expanded?this.props.collectionIconExpanded:this.props.collectionIcon
if(e)return d.a.createElement(e,{className:X.icon})}},{key:"renderItemImage",value:function(){var e=this.props.thumbnail
var n=this.props.itemIcon
if(e)return d.a.createElement("div",{className:X.thumbnail},d.a.createElement(S["a"],{src:e,constrain:"cover",alt:""}))
if(n)return d.a.createElement(n,{className:X.icon})}},{key:"render",value:function(){var e
var n=this.props,t=n.name,a=n.descriptor,i=n.expanded,r=n.selected,o=n.focused,c=n.variant,l=n.size
var s=(e={},Object(B["a"])(e,X.root,true),Object(B["a"])(e,X[l],true),Object(B["a"])(e,X[c],true),Object(B["a"])(e,X.expanded,i),Object(B["a"])(e,X.selected,r),Object(B["a"])(e,X.focused,o),Object(B["a"])(e,X.ie11,w["a"]),e)
return d.a.createElement("button",{tabIndex:-1,type:"button",className:y()(s)},d.a.createElement("span",{className:X.layout},this.renderImage(),d.a.createElement("span",{className:X.text},d.a.createElement("span",{className:X.textName},t),a?d.a.createElement("span",{className:X.textDescriptor,title:a},a):null)))}}])
n.displayName="TreeButton"
return n}(s["Component"]),x.propTypes={id:b.a.oneOfType([b.a.string,b.a.number]),name:b.a.string,descriptor:b.a.string,type:b.a.string,size:b.a.oneOf(["small","medium","large"]),variant:b.a.oneOf(["folderTree","indent"]),collectionIcon:b.a.func,collectionIconExpanded:b.a.func,itemIcon:b.a.func,thumbnail:b.a.string,onClick:b.a.func,expanded:b.a.bool,selected:b.a.bool,focused:b.a.bool},x.defaultProps={type:"treeButton",size:"medium",variant:"folderTree",selected:false,focused:false,onClick:function(){},id:void 0,name:void 0,collectionIcon:void 0,collectionIconExpanded:void 0,itemIcon:void 0,thumbnail:void 0,expanded:false,descriptor:void 0},I))||W)||W)
var L=function(e){var n=e.colors,t=e.spacing,a=e.typography,i=e.borders
return{fontFamily:a.fontFamily,baseSpacingSmall:t.xSmall,baseSpacingMedium:t.small,baseSpacingLarge:"1rem",borderWidth:i.widthSmall,borderColor:n.borderDark}}
var D,E,H,N,F
var G={componentId:"fXaWe",template:function(e){return"\n\n@keyframes fXaWe_cpmC{to{transform:scaleY(1)}}\n\n.fXaWe_cpmC{box-sizing:border-box;font-family:".concat(e.fontFamily||"inherit",';list-style-type:none;position:relative}\n\n.fXaWe_cpmC,.fXaWe_fjNS{margin:0;padding:0}\n\n.fXaWe_ewEu:focus,.fXaWe_fjNS:focus{outline:0}\n\n.fXaWe_ewdC .fXaWe_cpmC:before{animation-duration:0.2s;animation-fill-mode:forwards;animation-name:fXaWe_cpmC;animation-timing-function:ease-out;bottom:1.1875rem;content:"";inset-inline-end:auto;inset-inline-start:0;pointer-events:none;position:absolute;top:0.25rem;transform:scaleY(0.01);transform-origin:center top}\n\n[dir=ltr] .fXaWe_ewdC .fXaWe_cpmC:before{left:0;right:auto}\n\n[dir=rtl] .fXaWe_ewdC .fXaWe_cpmC:before{left:auto;right:0}\n\n.fXaWe_ewdC:not(.fXaWe_bUWG) .fXaWe_cpmC:before{background:').concat(e.borderColor||"inherit",";width:").concat(e.borderWidth||"inherit","}\n\n.fXaWe_ewdC.fXaWe_bUWG .fXaWe_cpmC:before{background:#73818c;width:0.0625rem}\n\n.fXaWe_doqw.fXaWe_cIHp .fXaWe_cpmC{-webkit-margin-end:0;-webkit-margin-start:calc(").concat(e.baseSpacingSmall||"inherit","*3);margin-inline-end:0;margin-inline-start:calc(").concat(e.baseSpacingSmall||"inherit","*3)}\n\n[dir=ltr] .fXaWe_doqw.fXaWe_cIHp .fXaWe_cpmC{margin-left:calc(").concat(e.baseSpacingSmall||"inherit","*3);margin-right:0}\n\n[dir=rtl] .fXaWe_doqw.fXaWe_cIHp .fXaWe_cpmC{margin-left:0;margin-right:calc(").concat(e.baseSpacingSmall||"inherit","*3)}\n\n.fXaWe_doqw.fXaWe_ewdC .fXaWe_cpmC{-webkit-margin-end:0;-webkit-margin-start:calc(").concat(e.baseSpacingSmall||"inherit","*2);margin-inline-end:0;margin-inline-start:calc(").concat(e.baseSpacingSmall||"inherit","*2);margin-top:calc(-1*").concat(e.baseSpacingSmall||"inherit",");padding-top:").concat(e.baseSpacingSmall||"inherit","}\n\n[dir=ltr] .fXaWe_doqw.fXaWe_ewdC .fXaWe_cpmC{margin-left:calc(").concat(e.baseSpacingSmall||"inherit","*2);margin-right:0}\n\n[dir=rtl] .fXaWe_doqw.fXaWe_ewdC .fXaWe_cpmC{margin-left:0;margin-right:calc(").concat(e.baseSpacingSmall||"inherit","*2)}\n\n.fXaWe_ycrn.fXaWe_cIHp .fXaWe_cpmC{-webkit-margin-end:0;-webkit-margin-start:calc(").concat(e.baseSpacingMedium||"inherit","*3);margin-inline-end:0;margin-inline-start:calc(").concat(e.baseSpacingMedium||"inherit","*3)}\n\n[dir=ltr] .fXaWe_ycrn.fXaWe_cIHp .fXaWe_cpmC{margin-left:calc(").concat(e.baseSpacingMedium||"inherit","*3);margin-right:0}\n\n[dir=rtl] .fXaWe_ycrn.fXaWe_cIHp .fXaWe_cpmC{margin-left:0;margin-right:calc(").concat(e.baseSpacingMedium||"inherit","*3)}\n\n.fXaWe_ycrn.fXaWe_ewdC .fXaWe_cpmC{-webkit-margin-end:0;-webkit-margin-start:calc(").concat(e.baseSpacingMedium||"inherit","*2);margin-inline-end:0;margin-inline-start:calc(").concat(e.baseSpacingMedium||"inherit","*2);margin-top:calc(-1*").concat(e.baseSpacingMedium||"inherit",");padding-top:").concat(e.baseSpacingMedium||"inherit","}\n\n[dir=ltr] .fXaWe_ycrn.fXaWe_ewdC .fXaWe_cpmC{margin-left:calc(").concat(e.baseSpacingMedium||"inherit","*2);margin-right:0}\n\n[dir=rtl] .fXaWe_ycrn.fXaWe_ewdC .fXaWe_cpmC{margin-left:0;margin-right:calc(").concat(e.baseSpacingMedium||"inherit","*2)}\n\n.fXaWe_cMDj.fXaWe_cIHp .fXaWe_cpmC{-webkit-margin-end:0;-webkit-margin-start:calc(").concat(e.baseSpacingLarge||"inherit","*3);margin-inline-end:0;margin-inline-start:calc(").concat(e.baseSpacingLarge||"inherit","*3)}\n\n[dir=ltr] .fXaWe_cMDj.fXaWe_cIHp .fXaWe_cpmC{margin-left:calc(").concat(e.baseSpacingLarge||"inherit","*3);margin-right:0}\n\n[dir=rtl] .fXaWe_cMDj.fXaWe_cIHp .fXaWe_cpmC{margin-left:0;margin-right:calc(").concat(e.baseSpacingLarge||"inherit","*3)}\n\n.fXaWe_cMDj.fXaWe_ewdC .fXaWe_cpmC{-webkit-margin-end:0;-webkit-margin-start:calc(").concat(e.baseSpacingLarge||"inherit","*2);margin-inline-end:0;margin-inline-start:calc(").concat(e.baseSpacingLarge||"inherit","*2);margin-top:calc(-1*").concat(e.baseSpacingLarge||"inherit",");padding-top:").concat(e.baseSpacingLarge||"inherit","}\n\n[dir=ltr] .fXaWe_cMDj.fXaWe_ewdC .fXaWe_cpmC{margin-left:calc(").concat(e.baseSpacingLarge||"inherit","*2);margin-right:0}\n\n[dir=rtl] .fXaWe_cMDj.fXaWe_ewdC .fXaWe_cpmC{margin-left:0;margin-right:calc(").concat(e.baseSpacingLarge||"inherit","*2)}")},list:"fXaWe_cpmC",node:"fXaWe_fjNS",item:"fXaWe_ewEu",folderTree:"fXaWe_ewdC",edge:"fXaWe_bUWG",small:"fXaWe_doqw",indent:"fXaWe_cIHp",medium:"fXaWe_ycrn",large:"fXaWe_cMDj"}
var q=(D=Object(v["a"])(),E=Object(g["themeable"])(L,G),D(H=E(H=(F=N=function(e){Object(l["a"])(n,e)
function n(e){var t
Object(i["a"])(this,n)
t=Object(o["a"])(this,Object(c["a"])(n).call(this,e))
t.handleFocus=function(e,n){e.stopPropagation()
t.setState({focused:"".concat(n.type,"_").concat(n.id)})}
t.handleBlur=function(e,n){e.stopPropagation()
t.setState({focused:""})}
t.handleCollectionClick=function(e){var n=t.props,a=n.id,i=n.onCollectionClick,r=n.expanded
var o={id:a,expanded:!r,type:"collection"}
i&&"function"===typeof i&&i(e,o)}
t.handleCollectionKeyDown=function(e){var n=t.props,a=n.id,i=n.onKeyDown,r=n.expanded
var o={id:a,expanded:!r,type:"collection"}
i&&"function"===typeof i&&i(e,o)}
t.state={focused:""}
return t}Object(r["a"])(n,[{key:"renderChildren",value:function(){var e=this
var n=this.props,t=n.expanded,a=n.collections,i=n.items,r=n.name
return t&&this.childCount>0&&d.a.createElement("ul",{"aria-label":r,className:G.list,role:"group"},a.map((function(n,t){return e.renderCollectionNode(n,t,e.childCount)})),i.map((function(n,t){return e.renderItemNode(n,t,e.childCount,e.collectionsCount)})))}},{key:"renderCollectionNode",value:function(e,t,a){return d.a.createElement(n,Object.assign({},this.props,{key:"c".concat(t),id:e.id,name:e.name,descriptor:e.descriptor,expanded:e.expanded,items:e.items,collections:e.collections,numChildren:a,level:this.props.level+1,position:t+1}))}},{key:"renderItemNode",value:function(e,n,t,a){var i=this
var r={}
this.props.selection&&(r["aria-selected"]=this.props.selection==="item_".concat(e.id))
var o={id:e.id,type:"item"}
return d.a.createElement("li",Object.assign({key:"i".concat(n),tabIndex:"-1",role:"treeitem","aria-label":e.name,className:G.item,"aria-level":this.props.level+1,"aria-posinset":n+1+a,"aria-setsize":t,onClick:function(e,n){return i.props.onItemClick(e,o)},onKeyDown:function(e,n){return i.props.onKeyDown(e,o)},onFocus:function(e,n){return i.handleFocus(e,o)},onBlur:function(e,n){return i.handleBlur(e,o)}},r),d.a.createElement(M,Object.assign({},this.getCommonButtonProps(),{id:e.id,name:e.name,descriptor:e.descriptor,thumbnail:e.thumbnail,selected:this.props.selection==="item_".concat(e.id),focused:this.state.focused==="item_".concat(e.id),type:"item"})))}},{key:"getCommonButtonProps",value:function(){return{id:this.props.id,name:this.props.name,descriptor:this.props.descriptor,size:this.props.size,variant:this.props.variant,itemIcon:this.props.itemIcon}}},{key:"render",value:function(){var e,n=this
var t=this.props,a=t.id,i=t.size,r=t.variant,o=t.expanded,c=t.collectionIcon,l=t.collectionIconExpanded,s=t.level,f=t.position
var b=(e={},Object(B["a"])(e,G.root,true),Object(B["a"])(e,G.edge,C["a"]),Object(B["a"])(e,G[i],true),Object(B["a"])(e,G[r],true),Object(B["a"])(e,G.expanded,o),Object(B["a"])(e,G.node,true),e)
var p={}
this.props.selection&&(p["aria-selected"]=this.props.selection==="collection_".concat(a))
return d.a.createElement("li",Object.assign({className:y()(b),tabIndex:"-1",role:"treeitem","aria-label":this.props.name,"aria-level":s,"aria-posinset":f,"aria-setsize":this.props.numChildren,"aria-expanded":o,onClick:this.handleCollectionClick,onKeyDown:this.handleCollectionKeyDown,onFocus:function(e,t){return n.handleFocus(e,{id:a,type:"collection"})},onBlur:function(e,t){return n.handleBlur(e,{id:a,type:"collection"})}},p),d.a.createElement(M,Object.assign({},this.getCommonButtonProps(),{expanded:o,collectionIcon:c,collectionIconExpanded:l,type:"collection",selected:this.props.selection==="collection_".concat(a),focused:this.state.focused==="collection_".concat(a)})),this.renderChildren())}},{key:"collectionsCount",get:function(){var e=this.props.collections
return e&&e.length>0?e.length:0}},{key:"itemsCount",get:function(){var e=this.props.items
return e&&e.length>0?e.length:0}},{key:"childCount",get:function(){return this.collectionsCount+this.itemsCount}}])
n.displayName="TreeCollection"
return n}(s["Component"]),N.propTypes={id:b.a.oneOfType([b.a.string,b.a.number]),name:b.a.string,descriptor:b.a.string,items:b.a.array,collections:b.a.array,expanded:b.a.bool,selection:b.a.string,size:b.a.oneOf(["small","medium","large"]),variant:b.a.oneOf(["folderTree","indent"]),collectionIcon:b.a.func,collectionIconExpanded:b.a.func,itemIcon:b.a.func,onItemClick:b.a.func,onCollectionClick:b.a.func,onKeyDown:b.a.func,numChildren:b.a.number,level:b.a.number,position:b.a.number},N.defaultProps={collections:[],items:[],expanded:false,selection:"",size:"medium",variant:"folderTree",onItemClick:function(){},onCollectionClick:function(){},onKeyDown:function(){},id:void 0,name:void 0,descriptor:void 0,collectionIconExpanded:void 0,collectionIcon:void 0,itemIcon:void 0,numChildren:void 0,level:void 0,position:void 0},F))||H)||H)
var Y=function(e){var n=e.colors,t=e.spacing,a=(e.typography,e.borders)
return{controlsTopMargin:t.small,borderRadius:a.radiusMedium,focusOutlineWidth:a.widthMedium,focusOutlineColor:n.borderBrand,focusOutlineStyle:a.style}}
t.d(n,"a",(function(){return A}))
var P,R,U,J,V
var K={componentId:"DBzxS",template:function(e){return"\n\n.DBzxS_cBsQ{margin-top:".concat(e.controlsTopMargin||"inherit","}\n\n.DBzxS_cpmC{list-style-type:none;margin:0;outline:none;padding:0;position:relative}\n\n.DBzxS_cpmC,.DBzxS_cpmC:before{box-sizing:border-box}\n\n.DBzxS_cpmC:before{border:").concat(e.focusOutlineWidth||"inherit"," ").concat(e.focusOutlineStyle||"inherit"," ").concat(e.focusOutlineColor||"inherit",";border-radius:calc(").concat(e.borderRadius||"inherit",'*1.5);bottom:-0.25rem;content:"";display:block;left:-0.25rem;opacity:0;pointer-events:none;position:absolute;right:-0.25rem;top:-0.25rem;transform:scale(0.95);transition:all 0.2s}\n\n.DBzxS_cpmC:focus:before{opacity:1;transform:scale(1)}')},controls:"DBzxS_cBsQ",list:"DBzxS_cpmC"}
var A=(P=Object(v["a"])(),R=Object(g["themeable"])(Y,K),P(U=R(U=(V=J=function(e){Object(l["a"])(n,e)
function n(e){var t
Object(i["a"])(this,n)
t=Object(o["a"])(this,Object(c["a"])(n).call(this,e))
t.handleCollectionClick=function(e,n){var a=!(arguments.length>2&&void 0!==arguments[2])||arguments[2]
e.stopPropagation()
var i=t.props.onCollectionClick
a&&t.expandOrCollapseNode(n)
i(n.id,n)
t.handleSelection(n.id,"collection")}
t.handleItemClick=function(e,n){e.stopPropagation()
var a=t.props.onItemClick
a(n)
t.handleSelection(n.id,"item")}
t.handleKeyDown=function(e,n){e.stopPropagation()
switch(e.keyCode){case m.a.codes.down:case m.a.codes.j:t.moveFocus(1)
break
case m.a.codes.up:case m.a.codes.k:t.moveFocus(-1)
break
case m.a.codes.home:case m.a.codes.end:t.homeOrEnd(e.keyCode)
break
case m.a.codes.left:case m.a.codes.right:t.handleLeftOrRightArrow(e.keyCode,n)
break
case m.a.codes.enter:case m.a.codes.space:t.handleActivation(e,n)
break
default:return}e.preventDefault()}
t.state={selection:""}
"undefined"===typeof t.props.expanded&&(t.state.expanded=e.defaultExpanded)
return t}Object(r["a"])(n,[{key:"getExpanded",value:function(e,n){return"undefined"===typeof n.expanded?e.expanded:n.expanded}},{key:"expandOrCollapseNode",value:function(e){var n=this
this.props.onCollectionToggle(e)
"undefined"===typeof this.props.expanded&&this.setState((function(t,a){var i=[].concat(n.getExpanded(t,a))
var r=n.getExpandedIndex(i,e.id)
e.expanded&&r<0?i.push(e.id):r>=0&&i.splice(r,1)
return{expanded:i}}))}},{key:"handleSelection",value:function(e,n){var t=this.props.selectionType
"single"===t&&this.setState((function(t){var a="".concat(n,"_").concat(e)
return t.selection!==a?{selection:a}:t}))}},{key:"getNavigableNodes",value:function(){return Array.from(this._root.querySelectorAll('[role="treeitem"]'))}},{key:"moveFocus",value:function(e){var n=this.getNavigableNodes()
var t=n.indexOf(window.document.activeElement)
var a=t+e
a<0?a=0:a>=n.length&&(a=n.length-1)
n.forEach((function(e){e.setAttribute("tabindex","-1")}))
n[a].setAttribute("tabindex","0")
n[a].focus()}},{key:"homeOrEnd",value:function(e){var n=this.getNavigableNodes().length
e===m.a.codes.home?this.moveFocus(1-n):this.moveFocus(n-1)}},{key:"handleLeftOrRightArrow",value:function(e,n){var t=!("rtl"===this._root.parentElement.dir||"rtl"===document.dir)
t&&e===m.a.codes.left||!t&&e==m.a.codes.right?this.handleCloseOrPrevious(n):this.handleOpenOrNext(n)}},{key:"handleOpenOrNext",value:function(e){e&&!this.expanded.includes(e.id)&&"collection"===e.type?this.expandOrCollapseNode(e):this.moveFocus(1)}},{key:"handleCloseOrPrevious",value:function(e){e&&this.expanded.includes(e.id)&&"collection"===e.type?this.expandOrCollapseNode(e):this.moveFocus(-1)}},{key:"handleActivation",value:function(e,n){if(null==n)return
"collection"===n.type?this.handleCollectionClick(e,n,"none"===this.props.selectionType):this.handleItemClick(e,n)}},{key:"getSubCollections",value:function(e){var n=this
var t=[].concat(e.collections||[])
return t.map((function(e){return n.getCollectionProps(n.props.collections[e])})).filter((function(e){return null!=e}))}},{key:"getItems",value:function(e){var n=this
if(e.items){var t=[].concat(e.items)
return t.map((function(e){return Object(a["a"])({},n.props.items[e])})).filter((function(e){return null!=e}))}return[]}},{key:"getCollectionProps",value:function(e){var n={id:e.id,name:e.name,descriptor:e.descriptor,expanded:this.getExpandedIndex(this.expanded,e.id)>=0,items:this.getItems(e),collections:this.getSubCollections(e)}
return n}},{key:"getExpandedIndex",value:function(e,n){return e.findIndex((function(e){return String(e)===String(n)}))}},{key:"renderRoot",value:function(){var e=this
return this.collections.map((function(n,t){return d.a.createElement(q,Object.assign({key:t},Object(O["c"])(e.props,q.propTypes),e.getCollectionProps(n),{selection:e.state.selection,onItemClick:e.handleItemClick,onCollectionClick:e.handleCollectionClick,onKeyDown:e.handleKeyDown,numChildren:e.collections.length,level:1,position:1}))}))}},{key:"render",value:function(){var e=this
return d.a.createElement("ul",{className:K.list,tabIndex:0,role:"tree",onKeyDown:this.handleKeyDown,ref:function(n){e._root=n},"aria-label":this.props.treeLabel},this.renderRoot())}},{key:"collections",get:function(){var e=this.props,n=e.collections,t=e.rootId,a=e.showRootCollection
return"undefined"!==typeof t&&a?[n[t]]:"undefined"!==typeof t?n[t].collections.map((function(e){return n[e]})).filter((function(e){return null!=e})):Object.keys(n).map((function(e){return n[e]})).filter((function(e){return null!=e}))}},{key:"expanded",get:function(){return this.getExpanded(this.state,this.props)}}])
n.displayName="TreeBrowser"
return n}(s["Component"]),J.propTypes={collections:b.a.object.isRequired,items:b.a.object.isRequired,rootId:b.a.number,expanded:Object(_["a"])(b.a.arrayOf(b.a.oneOfType([b.a.string,b.a.number])),"onCollectionToggle"),defaultExpanded:b.a.arrayOf(b.a.oneOfType([b.a.string,b.a.number])),selectionType:b.a.oneOf(["none","single"]),size:b.a.oneOf(["small","medium","large"]),variant:b.a.oneOf(["folderTree","indent"]),collectionIcon:b.a.func,collectionIconExpanded:b.a.func,itemIcon:b.a.func,showRootCollection:b.a.bool,onCollectionClick:b.a.func,onCollectionToggle:b.a.func,onItemClick:b.a.func,treeLabel:b.a.string},J.defaultProps={size:"medium",variant:"folderTree",showRootCollection:true,collectionIcon:h["a"],collectionIconExpanded:h["a"],itemIcon:u["a"],defaultExpanded:[],selectionType:"none",onItemClick:function(e){},onCollectionClick:function(e,n){},onCollectionToggle:function(e){},rootId:void 0,expanded:void 0,treeLabel:void 0},V))||U)||U)},XHgw:function(e,n,t){"use strict"
t.d(n,"a",(function(){return p}))
var a=t("VTBJ")
var i=t("1OyB")
var r=t("vuIU")
var o=t("md7G")
var c=t("foSv")
var l=t("Ji7U")
var s=t("q1tI")
var d=t.n(s)
var f=t("hPGw")
var b=d.a.createElement("path",{d:"M225.882 564.765V451.824h764.386L764.386 113H0v1524.706c0 93.402 76.01 169.412 169.412 169.412h1581.176c93.403 0 169.412-76.01 169.412-169.412V564.765H225.882z",fillRule:"evenodd",stroke:"none",strokeWidth:"1"})
var p=function(e){Object(l["a"])(n,e)
function n(){Object(i["a"])(this,n)
return Object(o["a"])(this,Object(c["a"])(n).apply(this,arguments))}Object(r["a"])(n,[{key:"render",value:function(){return d.a.createElement(f["a"],Object.assign({},this.props,{name:"IconFolder",viewBox:"0 0 1920 1920",bidirectional:true}),b)}}])
n.displayName="IconFolderSolid"
return n}(s["Component"])
p.glyphName="folder"
p.variant="Solid"
p.propTypes=Object(a["a"])({},f["a"].propTypes)}}])

//# sourceMappingURL=108-c-d0bc1acca7.js.map