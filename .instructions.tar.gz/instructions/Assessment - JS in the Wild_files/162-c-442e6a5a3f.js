(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[162],{"0Pgl":function(t,e,n){"use strict"
var r=n("GLiE")
var o=n.n(r)
var i=n("FIFq")
var a=n("fPNa")
var _=function(t,e){for(var n in e)d.call(e,n)&&(t[n]=e[n])
function r(){this.constructor=t}r.prototype=e.prototype
t.prototype=new r
t.__super__=e.prototype
return t},d={}.hasOwnProperty
e["a"]=function(t){_(e,t)
function e(){return e.__super__.constructor.apply(this,arguments)}e.mixin(a["a"])
e.prototype.initialize=function(){e.__super__.initialize.apply(this,arguments)
if(o.a.has(this,"url"))return delete this.url}
e.prototype.resourceName="external_tools"
e.prototype.computedAttributes=[{name:"custom_fields_string",deps:["custom_fields"]}]
e.prototype.urlRoot=function(){return"/api/v1/"+this._contextPath()+"/create_tool_with_verification"}
e.prototype.custom_fields_string=function(){var t,e
return function(){var n,r
n=this.get("custom_fields")
r=[]
for(t in n){e=n[t]
r.push(t+"="+e)}return r}.call(this).join("\n")}
e.prototype.launchUrl=function(t,e){var n,r,o,i
null==e&&(e={})
r=function(){var t
t=[]
for(n in e){i=e[n]
t.push(n+"="+i)}return t}()
o="/"+this._contextPath()+"/external_tools/"+this.id+"/resource_selection?launch_type="+t
r.length>0&&(o=o+"&"+r.join("&"))
return o}
e.prototype.assetString=function(){return"context_external_tool_"+this.id}
return e}(i["Model"])},"Ds/H":function(t,e,n){"use strict"
n.d(e,"a",(function(){return o}))
var r=n("vknZ")
function o(t){const e=r["a"].fromEvent(t,i)
if(e)return e.process()}async function i(){if(this.contentItems.length>0)return this.contentItems[0]}},iLq2:function(t,e,n){"use strict"
var r=n("ouhR")
var o=n.n(r)
var i=n("FIFq")
var a=n.n(i)
var _=n("3O+N")
var d=n.n(_)
var s=n("pQTu")
var l=n("m0r6")
Object(l["a"])(JSON.parse('{"ar":{"the_following_content_is_partner_provided_ed1da756":"المحتوى التالي تم إدخاله بواسطة شريك","the_preceding_content_is_partner_provided_d753928c":"المحتوى السابق تم إدخاله بواسطة شريك","tool_content_2924d18f":"محتوى الأداة"},"cy":{"the_following_content_is_partner_provided_ed1da756":"Mae’r cynnwys canlynol yn cael ei ddarparu gan bartner","the_preceding_content_is_partner_provided_d753928c":"Mae’r cynnwys blaenorol yn cael ei ddarparu gan bartner","tool_content_2924d18f":"Cynnwys adnodd"},"da":{"the_following_content_is_partner_provided_ed1da756":"Følgende indhold er partnerleveret","the_preceding_content_is_partner_provided_d753928c":"Foregående indhold er partnerleveret","tool_content_2924d18f":"Værktøjsindhold"},"da-x-k12":{"the_following_content_is_partner_provided_ed1da756":"Følgende indhold er partnerleveret","the_preceding_content_is_partner_provided_d753928c":"Foregående indhold er partnerleveret","tool_content_2924d18f":"Værktøjsindhold"},"de":{"the_following_content_is_partner_provided_ed1da756":"Der folgende Content stammt von einem Partner.","the_preceding_content_is_partner_provided_d753928c":"Der vorhergehende Content stammt von einem Partner.","tool_content_2924d18f":"Tool-Inhalt"},"el":{"tool_content_2924d18f":"Περιεχόμενο εργαλείου"},"en-AU":{"the_following_content_is_partner_provided_ed1da756":"The following content is partner provided","the_preceding_content_is_partner_provided_d753928c":"The preceding content is partner provided","tool_content_2924d18f":"Tool content"},"en-CA":{"the_following_content_is_partner_provided_ed1da756":"The following content is partner provided","the_preceding_content_is_partner_provided_d753928c":"The preceding content is partner provided","tool_content_2924d18f":"Tool content"},"en-GB":{"the_following_content_is_partner_provided_ed1da756":"The following content is partner provided","the_preceding_content_is_partner_provided_d753928c":"The preceding content is partner provided","tool_content_2924d18f":"Tool content"},"es":{"the_following_content_is_partner_provided_ed1da756":"El siguiente contenido está proporcionado por un socio","the_preceding_content_is_partner_provided_d753928c":"El contenido anterior está proporcionado por un socio","tool_content_2924d18f":"Contenido de herramienta"},"fa":{"the_following_content_is_partner_provided_ed1da756":"محتوای زیر توسط شریک فراهم شده است","the_preceding_content_is_partner_provided_d753928c":"محتوای پیشین توسط شریک ارائه شده است","tool_content_2924d18f":"محتوای ابزار"},"fi":{"the_following_content_is_partner_provided_ed1da756":"Seuraava sisältö on kumppanin toimittajaa","the_preceding_content_is_partner_provided_d753928c":"edeltävä sisältö on kumppanin toimittamaa","tool_content_2924d18f":"Työkalun sisältö"},"fr":{"the_following_content_is_partner_provided_ed1da756":"Le contenu suivant est fourni par un partenaire","the_preceding_content_is_partner_provided_d753928c":"Le contenu qui précède était fourni par un partenaire","tool_content_2924d18f":"Contenu de l\'outil"},"fr-CA":{"the_following_content_is_partner_provided_ed1da756":"Le contenu suivant est fourni par le partenaire","the_preceding_content_is_partner_provided_d753928c":"Le contenu précédent est fourni par le partenaire","tool_content_2924d18f":"Contenu de l\'outil"},"he":{"tool_content_2924d18f":"תוכן הכלי"},"ht":{"the_following_content_is_partner_provided_ed1da756":"Kontni annapre a se yon asosye ki bay li","the_preceding_content_is_partner_provided_d753928c":"Kontni anvan an se yon asosye ki bay li","tool_content_2924d18f":"Zouti kontni"},"hu":{"the_following_content_is_partner_provided_ed1da756":"A következő tartalmat partner biztosítja","the_preceding_content_is_partner_provided_d753928c":"Az előző tartalmat partner biztosítja","tool_content_2924d18f":"Eszköztartalom"},"hy":{"tool_content_2924d18f":"Գործիքակազմի բովանդակություն"},"is":{"the_following_content_is_partner_provided_ed1da756":"Eftirfarandi efni er gefið upp af samstarfsaðila","the_preceding_content_is_partner_provided_d753928c":"Framangreint efni er gefið upp af samstarfsaðila","tool_content_2924d18f":"Tólaefni"},"it":{"the_following_content_is_partner_provided_ed1da756":"I contenuti seguenti sono forniti dal partner","the_preceding_content_is_partner_provided_d753928c":"I contenuti precedenti sono forniti dal partner","tool_content_2924d18f":"Contenuto strumento"},"ja":{"the_following_content_is_partner_provided_ed1da756":"以下のコンテンツはパートナーが提供しています","the_preceding_content_is_partner_provided_d753928c":"上記のコンテンツはパートナーが提供しています","tool_content_2924d18f":"ツールコンテンツ"},"mi":{"the_following_content_is_partner_provided_ed1da756":"Ko ngā kōrero e whai ake nei he hoa mahi","the_preceding_content_is_partner_provided_d753928c":"Ko te tuhinga o mua he hoa mahi","tool_content_2924d18f":"ihirangi taputapu"},"nb":{"the_following_content_is_partner_provided_ed1da756":"Følgende innhold er gitt av en partner","the_preceding_content_is_partner_provided_d753928c":"Det foregående innholdet er gitt av en partner","tool_content_2924d18f":"Verktøy-innhold"},"nb-x-k12":{"the_following_content_is_partner_provided_ed1da756":"Følgende innhold er gitt av en partner","the_preceding_content_is_partner_provided_d753928c":"Det foregående innholdet er gitt av en partner","tool_content_2924d18f":"Verktøy-innhold"},"nl":{"the_following_content_is_partner_provided_ed1da756":"De volgende inhoud is door een partner geleverd","the_preceding_content_is_partner_provided_d753928c":"De voorgaande inhoud is door een partner geleverd","tool_content_2924d18f":"Toolinhoud"},"nn":{"the_following_content_is_partner_provided_ed1da756":"Følgande innhald er lagt til av partnar","the_preceding_content_is_partner_provided_d753928c":"Det føregåande innhaldet er lagt til av partnar","tool_content_2924d18f":"Verktøyinnhald"},"pl":{"the_following_content_is_partner_provided_ed1da756":"Następującą zawartość dostarcza partner","the_preceding_content_is_partner_provided_d753928c":"Poprzednią zawartość dostarcza partner","tool_content_2924d18f":"Zawartość narzędzi"},"pt":{"the_following_content_is_partner_provided_ed1da756":"O parceiro fornece o seguinte conteúdo","the_preceding_content_is_partner_provided_d753928c":"O conteúdo anterior é parceiro fornecido","tool_content_2924d18f":"Conteúdo de Ferramentas"},"pt-BR":{"the_following_content_is_partner_provided_ed1da756":"O seguinte conteúdo é fornecido por parceiro","the_preceding_content_is_partner_provided_d753928c":"O conteúdo precedente é fornecido por parceiro","tool_content_2924d18f":"Conteúdo de ferramentas"},"ru":{"the_following_content_is_partner_provided_ed1da756":"Последующий контент предоставляется партнером","the_preceding_content_is_partner_provided_d753928c":"Предыдущий контент предоставляется партнером","tool_content_2924d18f":"Контент инструмента"},"sl":{"the_following_content_is_partner_provided_ed1da756":"Naslednjo vsebino zagotavljajo partnerji.","the_preceding_content_is_partner_provided_d753928c":"Predhodno vsebino zagotavljajo partnerji.","tool_content_2924d18f":"Vsebina orodja"},"sv":{"the_following_content_is_partner_provided_ed1da756":"Följande innehåll har tillhandahållits av partner","the_preceding_content_is_partner_provided_d753928c":"Det föregående innehållet har tillhandahållits av partner","tool_content_2924d18f":"Verktygsinnehåll"},"sv-x-k12":{"the_following_content_is_partner_provided_ed1da756":"Följande innehåll har tillhandahållits av partner","the_preceding_content_is_partner_provided_d753928c":"Det föregående innehållet har tillhandahållits av partner","tool_content_2924d18f":"Verktygsinnehåll"},"tr":{"tool_content_2924d18f":"Araç içeriği"},"uk":{"the_following_content_is_partner_provided_ed1da756":"Наступний контент наданий партнером","the_preceding_content_is_partner_provided_d753928c":"Попередній контент наданий партнером","tool_content_2924d18f":"Контент інструменту"},"zh-Hans":{"the_following_content_is_partner_provided_ed1da756":"以下内容由合作伙伴提供","the_preceding_content_is_partner_provided_d753928c":"以上内容由合作伙伴提供","tool_content_2924d18f":"工具内容"},"zh-Hant":{"the_following_content_is_partner_provided_ed1da756":"以下內容由合作夥伴提供","the_preceding_content_is_partner_provided_d753928c":"上述內容由合作夥伴提供","tool_content_2924d18f":"工具內容"}}'))
n("jQeR")
n("0sPK")
s["default"].scoped("external_tools.external_content_return_view")
n("DfGn")
var c=d.a.default
var p=c.template,h=c.templates=c.templates||{}
var u="ExternalTools/ExternalContentReturnView"
h[u]=p((function(t,e,n,r,o){this.compilerInfo=[4,">= 1.0.0"]
n=this.merge(n,t.helpers)
o=o||{}
var i,a,_,d="",s=n.helperMissing,l=this.escapeExpression,c="function"
d+='<div class="before_external_content_info_alert screenreader-only" tabindex="0">\n  <div class="ic-flash-info">\n    <div class="ic-flash__icon" aria-hidden="true">\n      <i class="icon-info"></i>\n    </div>\n    '+l((a=n.t||e&&e.t,_={hash:{scope:"external_tools.external_content_return_view"},data:o},a?a.call(e,"The following content is partner provided",_):s.call(e,"t","The following content is partner provided",_)))+'\n  </div>\n</div>\n<iframe\n  tabindex="0"\n  class="tool_launch"\n  src="'
if(a=n.launch_url)i=a.call(e,{hash:{},data:o})
else{a=e&&e.launch_url
i=typeof a===c?a.call(e,{hash:{},data:o}):a}d+=l(i)+'"\n  title="'+l((a=n.t||e&&e.t,_={hash:{i18n_inferred_key:true},data:o},a?a.call(e,"tool_content_2924d18f","Tool content",_):s.call(e,"t","tool_content_2924d18f","Tool content",_)))+'"\n  allow="'
if(a=n.allowances)i=a.call(e,{hash:{},data:o})
else{a=e&&e.allowances
i=typeof a===c?a.call(e,{hash:{},data:o}):a}d+=l(i)+'"\n  data-lti-launch="true"\n>\n</iframe>\n<div class="after_external_content_info_alert screenreader-only" tabindex="0">\n  <div class="ic-flash-info">\n    <div class="ic-flash__icon" aria-hidden="true">\n      <i class="icon-info"></i>\n    </div>\n    '+l((a=n.t||e&&e.t,_={hash:{scope:"external_tools.external_content_return_view"},data:o},a?a.call(e,"The preceding content is partner provided",_):s.call(e,"t","The preceding content is partner provided",_)))+"\n  </div>\n</div>\n"
return d}))
var f=h[u]
var g=n("mykf")
var v=function(t,e){return function(){return t.apply(e,arguments)}},m=function(t,e){for(var n in e)y.call(e,n)&&(t[n]=e[n])
function r(){this.constructor=t}r.prototype=e.prototype
t.prototype=new r
t.__super__=e.prototype
return t},y={}.hasOwnProperty
e["a"]=function(t){m(e,t)
function e(){this._contentCancel=v(this._contentCancel,this)
this._contentReady=v(this._contentReady,this)
this.removeDialog=v(this.removeDialog,this)
this.handleAlertBlur=v(this.handleAlertBlur,this)
return e.__super__.constructor.apply(this,arguments)}e.prototype.template=f
e.optionProperty("launchType")
e.optionProperty("launchParams")
e.optionProperty("displayAsModal")
e.prototype.defaults={displayAsModal:true}
e.prototype.els={"iframe.tool_launch":"$iframe"}
e.prototype.events={"focus .before_external_content_info_alert":"handleAlertFocus","focus .after_external_content_info_alert":"handleAlertFocus","blur .before_external_content_info_alert":"handleAlertBlur","blur .after_external_content_info_alert":"handleAlertBlur"}
e.prototype.handleAlertFocus=function(t){o()(t.target).removeClass("screenreader-only")
return this.$el.find("iframe").addClass("info_alert_outline")}
e.prototype.handleAlertBlur=function(t){o()(t.target).addClass("screenreader-only")
return this.$el.find("iframe").removeClass("info_alert_outline")}
e.prototype.attach=function(){return this.model.on("change",(t=this,function(){return t.render()}))
var t}
e.prototype.toJSON=function(){var t
t=e.__super__.toJSON.apply(this,arguments)
t.allowances=Object(g["a"])()
t.launch_url=this.model.launchUrl(this.launchType,this.launchParams)
return t}
e.prototype.afterRender=function(){var t,e
this.attachLtiEvents()
e=this.model.get(this.launchType)||{}
this.$iframe.width("100%")
this.$iframe.height(e.selection_height)
if(this.displayAsModal)return this.$el.dialog({title:(null!=(t=this.model.get(this.launchType))?t.label:void 0)||"",width:e.selection_width,height:e.selection_height,resizable:true,close:this.removeDialog})}
e.prototype.attachLtiEvents=function(){o()(window).on("externalContentReady",this._contentReady)
return o()(window).on("externalContentCancel",this._contentCancel)}
e.prototype.detachLtiEvents=function(){o()(window).off("externalContentReady",this._contentReady)
return o()(window).off("externalContentCancel",this._contentCancel)}
e.prototype.removeDialog=function(){this.detachLtiEvents()
return this.remove()}
e.prototype._contentReady=function(t,e){this.trigger("ready",e)
return this.removeDialog()}
e.prototype._contentCancel=function(t,e){this.trigger("cancel",e)
return this.removeDialog()}
return e}(a.a.View)},vknZ:function(t,e,n){"use strict"
var r=n("ouhR")
var o=n.n(r)
var i=n("mykf")
class a{constructor(t){this.assignProperties(t)}toHtmlString(){}assignProperties(t){this.properties.forEach(e=>{this[e]=t[e]})}linkThumbnail(){return this.imageTag(this.thumbnail)}iframeTag(){const t=this.iframe
if(t){const e=document.createElement("iframe")
e.setAttribute("src",t.src)
e.setAttribute("title",this.title||"")
e.setAttribute("allowfullscreen","true")
e.setAttribute("allow",Object(i["a"])())
t.width&&(e.style.width="".concat(t.width,"px"))
t.height&&(e.style.height="".concat(t.height,"px"))
return e.outerHTML}}imageTag(t,e,n){const r=document.createElement("img")
r.setAttribute("src",t)
this.text&&r.setAttribute("alt",this.text)
e&&r.setAttribute("width",e)
n&&r.setAttribute("height",n)
return r.outerHTML}anchorTag(t){const e=document.createElement("a")
e.setAttribute("href",this.safeUrl())
e.setAttribute("title",this.title)
e.setAttribute("target","_blank")
e.innerHTML=t
return e.outerHTML}safeUrl(){return this.url.replace(/^(data:text\/html|javascript:)/,"#$1")}}class _ extends a{constructor(t,e,n){super(t)
this.type=_.type
n&&""!==n&&(this.text=n)}get properties(){return Object.freeze(["url","title","text","icon","thumbnail","iframe"])}toHtmlString(){if(this.iframe&&this.iframe.src)return this.iframeTag()
return this.anchorTag(this.linkBody())}linkText(){return this.text&&this.text.trim()||this.title&&this.title.trim()}linkBody(){if(this.thumbnail)return this.linkThumbnail()
return this.linkText()}}_.type="link"
class d extends _{constructor(t,e,n){super(t,e,n)
this.url="".concat(e,"?").concat(this.ltiEndpointParams(t.url))}ltiEndpointParams(t){return"display=borderless&url=".concat(encodeURIComponent(t))}toHtmlString(){if(this.iframe){this.iframe.src=this.safeUrl()
return this.iframeTag()}return this.anchorTag(this.linkBody())}}class s extends a{constructor(t){super(t)
this.type=s.type}get properties(){return Object.freeze(["url","title","thumbnail","text","width","height"])}toHtmlString(){if(this.thumbnail)return this.anchorTag(this.linkThumbnail())
return this.imageTag(this.safeUrl(),this.width,this.height)}}s.type="image"
class l extends a{constructor(t){super(t)
this.type=l.type}get properties(){return Object.freeze(["html","title","text"])}toHtmlString(){return this.html}}l.type="html"
n.d(e,"a",(function(){return c}))
class c{constructor(t,e,n,r,o){this.contentItems=t
this.messages=e
this.logs=n
this.ltiEndpoint=r
this.processHandler=o
this.showMessages()
this.showLogs()}get loggingEnabled(){return ENV&&ENV.DEEP_LINKING_LOGGING}get typeMap(){return{link:_,ltiResourceLink:d,image:s,html:l}}static fromEvent(t,e){const n=t.data,r=n.content_items,o=n.msg,i=n.log,a=n.errormsg,_=n.errorlog,d=n.ltiEndpoint,s=n.messageType
if("LtiDeepLinkingResponse"!==s)return
return new this(r,{msg:o,errormsg:a},{log:i,errorlog:_},d,e)}process(){return this.processHandler(...arguments)}showMessages(){this.messages.errormsg&&o.a.flashError(this.messages.errormsg)
this.messages.msg&&o.a.flashMessage(this.messages.msg)}showLogs(){if(this.loggingEnabled){this.logs.errorlog&&console.error(this.logs.errorlog)
this.logs.log&&console.log(this.logs.log)}}}}}])

//# sourceMappingURL=162-c-442e6a5a3f.js.map