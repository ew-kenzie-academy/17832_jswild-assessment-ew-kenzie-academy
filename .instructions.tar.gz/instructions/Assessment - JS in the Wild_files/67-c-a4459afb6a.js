(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[67],{"5JRF":function(n,t,e){"use strict"
var r=e("rePB")
var o=e("1OyB")
var i=e("vuIU")
var c=e("md7G")
var a=e("foSv")
var b=e("Ji7U")
var l=e("q1tI")
var y=e.n(l)
var s=e("17x9")
var u=e.n(s)
var p=e("TSYQ")
var f=e.n(p)
var j=e("J2CL")
var d=e("nAyT")
var U=e("KgFQ")
var h=e("jtGx")
var _=e("VTBJ")
function g(n){var t=n.typography,e=n.colors,r=n.spacing
return Object(_["a"])({},t,{primaryInverseColor:e.textLightest,primaryColor:e.textDarkest,secondaryColor:e.textDark,secondaryInverseColor:e.textLight,warningColor:e.textWarning,brandColor:e.textBrand,errorColor:e.textDanger,successColor:e.textSuccess,alertColor:e.textAlert,paragraphMargin:"".concat(r.medium," 0")})}g.canvas=function(n){return{primaryColor:n["ic-brand-font-color-dark"],brandColor:n["ic-brand-primary"]}}
e.d(t,"a",(function(){return x}))
var m,v,k,w,B
var G={componentId:"cjUyb",template:function(n){return"\n\n.cjUyb_bGBk{font-family:".concat(n.fontFamily||"inherit","}\n\n.cjUyb_bGBk sub,.cjUyb_bGBk sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}\n\n.cjUyb_bGBk sup{top:-0.4em}\n\n.cjUyb_bGBk sub{bottom:-0.4em}\n\n.cjUyb_bGBk code,.cjUyb_bGBk pre{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;empty-cells:show;float:none;font-family:serif;font-family:").concat(n.fontFamilyMonospace||"inherit",";font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n.cjUyb_bGBk em,.cjUyb_bGBk i{font-style:italic}\n\n.cjUyb_bGBk b,.cjUyb_bGBk strong{font-weight:").concat(n.fontWeightBold||"inherit","}\n\n.cjUyb_bGBk p{display:block;margin:").concat(n.paragraphMargin||"inherit",";padding:0}\n\ninput.cjUyb_bGBk[type]{-moz-appearance:none;-webkit-appearance:none;appearance:none;background:none;border:none;border-radius:0;box-shadow:none;box-sizing:border-box;color:inherit;display:block;height:auto;line-height:inherit;margin:0;outline:0;padding:0;text-align:start;width:100%}\n\n[dir=ltr] input.cjUyb_bGBk[type]{text-align:left}\n\n[dir=rtl] input.cjUyb_bGBk[type]{text-align:right}\n\n.cjUyb_bGBk:focus,input.cjUyb_bGBk[type]:focus{outline:none}\n\n.cjUyb_bGBk.cjUyb_qFsi,input.cjUyb_bGBk[type].cjUyb_qFsi{color:").concat(n.primaryColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bLsb,input.cjUyb_bGBk[type].cjUyb_bLsb{color:").concat(n.secondaryColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ezBQ,input.cjUyb_bGBk[type].cjUyb_ezBQ{color:").concat(n.primaryInverseColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dlnd,input.cjUyb_bGBk[type].cjUyb_dlnd{color:").concat(n.secondaryInverseColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_cJLh,input.cjUyb_bGBk[type].cjUyb_cJLh{color:").concat(n.successColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fpfC,input.cjUyb_bGBk[type].cjUyb_fpfC{color:").concat(n.brandColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eHcp,input.cjUyb_bGBk[type].cjUyb_eHcp{color:").concat(n.warningColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dwua,input.cjUyb_bGBk[type].cjUyb_dwua{color:").concat(n.errorColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eZgl,input.cjUyb_bGBk[type].cjUyb_eZgl{color:").concat(n.alertColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fbNi,input.cjUyb_bGBk[type].cjUyb_fbNi{-ms-hyphens:auto;-webkit-hyphens:auto;hyphens:auto;overflow-wrap:break-word;word-break:break-word}\n\n.cjUyb_bGBk.cjUyb_drST,input.cjUyb_bGBk[type].cjUyb_drST{font-weight:").concat(n.fontWeightNormal||"inherit","}\n\n.cjUyb_bGBk.cjUyb_pEgL,input.cjUyb_bGBk[type].cjUyb_pEgL{font-weight:").concat(n.fontWeightLight||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bdMA,input.cjUyb_bGBk[type].cjUyb_bdMA{font-weight:").concat(n.fontWeightBold||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ijuF,input.cjUyb_bGBk[type].cjUyb_ijuF{font-style:normal}\n\n.cjUyb_bGBk.cjUyb_fetN,input.cjUyb_bGBk[type].cjUyb_fetN{font-style:italic}\n\n.cjUyb_bGBk.cjUyb_dfBC,input.cjUyb_bGBk[type].cjUyb_dfBC{font-size:").concat(n.fontSizeXSmall||"inherit","}\n\n.cjUyb_bGBk.cjUyb_doqw,input.cjUyb_bGBk[type].cjUyb_doqw{font-size:").concat(n.fontSizeSmall||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ycrn,input.cjUyb_bGBk[type].cjUyb_ycrn{font-size:").concat(n.fontSizeMedium||"inherit","}\n\n.cjUyb_bGBk.cjUyb_cMDj,input.cjUyb_bGBk[type].cjUyb_cMDj{font-size:").concat(n.fontSizeLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eoMd,input.cjUyb_bGBk[type].cjUyb_eoMd{font-size:").concat(n.fontSizeXLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fdca,input.cjUyb_bGBk[type].cjUyb_fdca{font-size:").concat(n.fontSizeXXLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fEWX,input.cjUyb_bGBk[type].cjUyb_fEWX{line-height:").concat(n.lineHeight||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fNIu,input.cjUyb_bGBk[type].cjUyb_fNIu{line-height:").concat(n.lineHeightFit||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dfDs,input.cjUyb_bGBk[type].cjUyb_dfDs{line-height:").concat(n.lineHeightCondensed||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bDjL,input.cjUyb_bGBk[type].cjUyb_bDjL{line-height:").concat(n.lineHeightDouble||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eQnG,input.cjUyb_bGBk[type].cjUyb_eQnG{letter-spacing:").concat(n.letterSpacingNormal||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bbUA,input.cjUyb_bGBk[type].cjUyb_bbUA{letter-spacing:").concat(n.letterSpacingCondensed||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bRWU,input.cjUyb_bGBk[type].cjUyb_bRWU{letter-spacing:").concat(n.letterSpacingExpanded||"inherit","}\n\n.cjUyb_bGBk.cjUyb_wZsr,input.cjUyb_bGBk[type].cjUyb_wZsr{text-transform:none}\n\n.cjUyb_bGBk.cjUyb_fCZK,input.cjUyb_bGBk[type].cjUyb_fCZK{text-transform:capitalize}\n\n.cjUyb_bGBk.cjUyb_dsRi,input.cjUyb_bGBk[type].cjUyb_dsRi{text-transform:uppercase}\n\n.cjUyb_bGBk.cjUyb_bLtD,input.cjUyb_bGBk[type].cjUyb_bLtD{text-transform:lowercase}")},root:"cjUyb_bGBk","color-primary":"cjUyb_qFsi","color-secondary":"cjUyb_bLsb","color-primary-inverse":"cjUyb_ezBQ","color-secondary-inverse":"cjUyb_dlnd","color-success":"cjUyb_cJLh","color-brand":"cjUyb_fpfC","color-warning":"cjUyb_eHcp","color-error":"cjUyb_dwua","color-alert":"cjUyb_eZgl","wrap-break-word":"cjUyb_fbNi","weight-normal":"cjUyb_drST","weight-light":"cjUyb_pEgL","weight-bold":"cjUyb_bdMA","style-normal":"cjUyb_ijuF","style-italic":"cjUyb_fetN","x-small":"cjUyb_dfBC",small:"cjUyb_doqw",medium:"cjUyb_ycrn",large:"cjUyb_cMDj","x-large":"cjUyb_eoMd","xx-large":"cjUyb_fdca","lineHeight-default":"cjUyb_fEWX","lineHeight-fit":"cjUyb_fNIu","lineHeight-condensed":"cjUyb_dfDs","lineHeight-double":"cjUyb_bDjL","letterSpacing-normal":"cjUyb_eQnG","letterSpacing-condensed":"cjUyb_bbUA","letterSpacing-expanded":"cjUyb_bRWU","transform-none":"cjUyb_wZsr","transform-capitalize":"cjUyb_fCZK","transform-uppercase":"cjUyb_dsRi","transform-lowercase":"cjUyb_bLtD"}
var x=(m=Object(d["a"])("7.0.0",null,"Use Text from ui-text instead."),v=Object(j["themeable"])(g,G),m(k=v(k=(B=w=function(n){Object(b["a"])(t,n)
function t(){Object(o["a"])(this,t)
return Object(c["a"])(this,Object(a["a"])(t).apply(this,arguments))}Object(i["a"])(t,[{key:"render",value:function(){var n
var e=this.props,o=e.wrap,i=e.weight,c=e.fontStyle,a=e.size,b=e.lineHeight,l=e.letterSpacing,s=e.transform,u=e.color,p=e.children
var j=Object(U["a"])(t,this.props)
return y.a.createElement(j,Object.assign({},Object(h["a"])(this.props,t.propTypes),{className:f()((n={},Object(r["a"])(n,G.root,true),Object(r["a"])(n,G[a],a),Object(r["a"])(n,G["wrap-".concat(o)],o),Object(r["a"])(n,G["weight-".concat(i)],i),Object(r["a"])(n,G["style-".concat(c)],c),Object(r["a"])(n,G["transform-".concat(s)],s),Object(r["a"])(n,G["lineHeight-".concat(b)],b),Object(r["a"])(n,G["letterSpacing-".concat(l)],l),Object(r["a"])(n,G["color-".concat(u)],u),n)),ref:this.props.elementRef}),p)}}])
t.displayName="Text"
return t}(l["Component"]),w.propTypes={as:u.a.elementType,wrap:u.a.oneOf(["normal","break-word"]),weight:u.a.oneOf(["normal","light","bold"]),fontStyle:u.a.oneOf(["italic","normal"]),size:u.a.oneOf(["x-small","small","medium","large","x-large","xx-large"]),lineHeight:u.a.oneOf(["default","fit","condensed","double"]),letterSpacing:u.a.oneOf(["normal","condensed","expanded"]),transform:u.a.oneOf(["none","capitalize","uppercase","lowercase"]),color:u.a.oneOf(["primary","secondary","primary-inverse","secondary-inverse","success","error","alert","warning","brand"]),children:u.a.node,elementRef:u.a.func},w.defaultProps={as:"span",wrap:"normal",size:"medium",letterSpacing:"normal",children:null,elementRef:void 0,color:void 0,transform:void 0,lineHeight:void 0,fontStyle:void 0,weight:void 0},B))||k)||k)},HMVb:function(n,t,e){"use strict"
var r=e("ODXe")
var o=e("i/8D")
var i=e("DUTp")
var c=e("IPIv")
var a={}
function b(n,t){if(!o["a"])return 16
var e=n||Object(i["a"])(n).documentElement
if(!t&&a[e])return a[e]
var r=parseInt(Object(c["a"])(e).getPropertyValue("font-size"))
a[e]=r
return r}var l=e("CyAq")
e.d(t,"a",(function(){return y}))
function y(n,t){var e=t||document.body
if(!n||"number"===typeof n)return n
var o=Object(l["a"])(n),i=Object(r["a"])(o,2),c=i[0],a=i[1]
return"rem"===a?c*b():"em"===a?c*b(e):c}},cClk:function(n,t,e){"use strict"
e.d(t,"a",(function(){return r}))
function r(n){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"onChange"
var e=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"defaultValue"
return function(r,o,i){var c=n.apply(null,arguments)
if(c)return c
if(r[o]&&"function"!==typeof r[t])return new Error(["You provided a '".concat(o,"' prop without an '").concat(t,"' handler on '").concat(i,"'. This will render a controlled component. If the component should be uncontrolled and manage its own state, use '").concat(e,"'. Otherwise, set '").concat(t,"'.")].join(""))}}},eGSd:function(n,t,e){"use strict"
e.d(t,"a",(function(){return r}))
function r(n){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0
var e=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}
var r,o,i,c
var a=0
var b=[]
var l=false
if("function"!==typeof n)throw new TypeError("Expected a function")
var y=!!e.leading
var s="maxWait"in e
var u=!("trailing"in e)||!!e.trailing
var p=s?Math.max(+e.maxWait||0,t):0
function f(t){var e=r
var c=o
r=o=void 0
a=t
if(true!==l){i=n.apply(c,e)
return i}}function j(n){a=n
b.push(setTimeout(h,t))
return y?f(n):i}function d(n){var e=n-c
var r=n-a
var o=t-e
return s?Math.min(o,p-r):o}function U(n){var e=n-c
var r=n-a
return"undefined"===typeof c||e>=t||e<0||s&&r>=p}function h(){var n=Date.now()
if(U(n))return _(n)
b.push(setTimeout(h,d(n)))}function _(n){v()
if(u&&r)return f(n)
r=o=void 0
return i}function g(){l=true
v()
a=0
r=c=o=void 0}function m(){return 0===b.length?i:_(Date.now())}function v(){b.forEach((function(n){return clearTimeout(n)}))
b=[]}function k(){var n=Date.now()
var e=U(n)
for(var a=arguments.length,l=new Array(a),y=0;y<a;y++)l[y]=arguments[y]
r=l
o=this
c=n
if(e){if(0===b.length)return j(c)
if(s){b.push(setTimeout(h,t))
return f(c)}}0===b.length&&b.push(setTimeout(h,t))
return i}k.cancel=g
k.flush=m
return k}},gCYW:function(n,t,e){"use strict"
e.d(t,"a",(function(){return a}))
var r=e("QF4Q")
var o=e("i/8D")
var i=e("EgqM")
var c=e("DUTp")
function a(n){var t={top:0,left:0,height:0,width:0}
if(!o["a"])return t
var e=Object(r["a"])(n)
if(!e)return t
if(e===window)return{left:window.pageXOffset,top:window.pageYOffset,width:window.innerWidth,height:window.innerHeight,right:window.innerWidth+window.pageXOffset,bottom:window.innerHeight+window.pageYOffset}
var b=n===document?document:Object(c["a"])(e)
var l=b&&b.documentElement
if(!l||!Object(i["a"])(l,e))return t
var y=e.getBoundingClientRect()
var s
for(s in y)t[s]=y[s]
if(b!==document){var u=b.defaultView.frameElement
if(u){var p=a(u)
t.top+=p.top
t.bottom+=p.top
t.left+=p.left
t.right+=p.left}}return{top:t.top+(window.pageYOffset||l.scrollTop)-(l.clientTop||0),left:t.left+(window.pageXOffset||l.scrollLeft)-(l.clientLeft||0),width:(null==t.width?e.offsetWidth:t.width)||0,height:(null==t.height?e.offsetHeight:t.height)||0,right:b.body.clientWidth-t.width-t.left,bottom:b.body.clientHeight-t.height-t.top}}},tLB3:function(n,t,e){var r=e("GoyQ"),o=e("/9aa")
var i=NaN
var c=/^\s+|\s+$/g
var a=/^[-+]0x[0-9a-f]+$/i
var b=/^0b[01]+$/i
var l=/^0o[0-7]+$/i
var y=parseInt
function s(n){if("number"==typeof n)return n
if(o(n))return i
if(r(n)){var t="function"==typeof n.valueOf?n.valueOf():n
n=r(t)?t+"":t}if("string"!=typeof n)return 0===n?n:+n
n=n.replace(c,"")
var e=b.test(n)
return e||l.test(n)?y(n.slice(2),e?2:8):a.test(n)?i:+n}n.exports=s},zZ0H:function(n,t){function e(n){return n}n.exports=e}}])

//# sourceMappingURL=67-c-a4459afb6a.js.map