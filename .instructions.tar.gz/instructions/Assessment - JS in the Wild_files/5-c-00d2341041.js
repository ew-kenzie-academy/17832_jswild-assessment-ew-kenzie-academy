(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[5],{sTNg:function(e,n,t){"use strict"
t.r(n)
var r=t("1OyB")
var a=t("vuIU")
var i=t("md7G")
var o=t("foSv")
var s=t("Ji7U")
var l=t("q1tI")
var c=t.n(l)
var d=t("17x9")
var p=t.n(d)
var u=t("jtGx")
var m={message:p.a.shape({text:p.a.string,type:p.a.oneOf(["error","hint","success","screenreader-only"])})}
var b=t("VTBJ")
var h=t("rePB")
t("DEX3")
var f=t("TSYQ")
var g=t.n(f)
var v=t("rW8M")
var y=t("6SzX")
var O=t("pZ4s")
var j=t("J2CL")
var k=t("KgFQ")
var w=t("BTe1")
function C(e){var n=e.colors,t=e.typography
return{color:n.textDarkest,fontFamily:t.fontFamily,fontWeight:t.fontWeightBold,fontSize:t.fontSizeMedium,lineHeight:t.lineHeightFit}}C.canvas=function(e){return{color:e["ic-brand-font-color-dark"]}}
var x,_,F,A
var I={componentId:"fCrpb",template:function(e){return"\n\n.fCrpb_bGBk,.fCrpb_bGBk.fCrpb_fVUh,label.fCrpb_bGBk{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n.fCrpb_bGBk.fCrpb_fVUh{display:table;width:100%}\n\n.fCrpb_egrg,.fCrpb_egrg.fCrpb_fVUh,label.fCrpb_egrg{color:".concat(e.color||"inherit",";font-family:").concat(e.fontFamily||"inherit",";font-size:").concat(e.fontSize||"inherit",";font-weight:").concat(e.fontWeight||"inherit",";line-height:").concat(e.lineHeight||"inherit",";margin:0;text-align:inherit}\n\n[dir=ltr] .fCrpb_egrg,[dir=ltr] .fCrpb_egrg.fCrpb_fVUh,[dir=ltr] label.fCrpb_egrg,[dir=rtl] .fCrpb_egrg,[dir=rtl] .fCrpb_egrg.fCrpb_fVUh,[dir=rtl] label.fCrpb_egrg{text-align:inherit}")},root:"fCrpb_bGBk",legend:"fCrpb_fVUh","has-content":"fCrpb_egrg"}
var S=(x=Object(j["themeable"])(C,I),x(_=(A=F=function(e){Object(s["a"])(n,e)
function n(){Object(r["a"])(this,n)
return Object(i["a"])(this,Object(o["a"])(n).apply(this,arguments))}Object(a["a"])(n,[{key:"render",value:function(){var e
var t=Object(k["a"])(n,this.props)
var r=(e={},Object(h["a"])(e,I.root,true),Object(h["a"])(e,I["has-content"],Object(v["a"])(this.props.children)),e)
return c.a.createElement(t,Object.assign({},Object(u["a"])(this.props,n.propTypes),{className:g()(r)}),this.props.children)}}])
n.displayName="FormFieldLabel"
return n}(l["Component"]),F.propTypes={as:p.a.elementType,children:p.a.node.isRequired},F.defaultProps={as:"span"},A))||_)
function T(e){var n=e.spacing
return{topMargin:n.xxSmall}}function E(e){var n=e.colors,t=e.typography
return{colorHint:n.textDarkest,colorError:n.textDanger,colorSuccess:n.textSuccess,fontFamily:t.fontFamily,fontWeight:t.fontWeightNormal,fontSize:t.fontSizeSmall,lineHeight:t.lineHeight}}E.canvas=function(e){return{colorHint:e["ic-brand-font-color-dark"]}}
var L,B,N,R
var V={componentId:"bVlfD",template:function(e){return"\n\n.bVlfD_bGBk{display:block;font-family:".concat(e.fontFamily||"inherit",";font-size:").concat(e.fontSize||"inherit",";font-weight:").concat(e.fontWeight||"inherit",";line-height:").concat(e.lineHeight||"inherit","}\n\n.bVlfD_dYYb{color:").concat(e.colorHint||"inherit","}\n\n.bVlfD_ddvR{color:").concat(e.colorError||"inherit","}\n\n.bVlfD_cOXX{color:").concat(e.colorSuccess||"inherit","}")},root:"bVlfD_bGBk",hint:"bVlfD_dYYb",error:"bVlfD_ddvR",success:"bVlfD_cOXX"}
var z=(L=Object(j["themeable"])(E,V),L(B=(R=N=function(e){Object(s["a"])(n,e)
function n(){Object(r["a"])(this,n)
return Object(i["a"])(this,Object(o["a"])(n).apply(this,arguments))}Object(a["a"])(n,[{key:"render",value:function(){var e
var n=(e={},Object(h["a"])(e,V.root,true),Object(h["a"])(e,V[this.props.variant],true),e)
return"screenreader-only"!==this.props.variant?c.a.createElement("span",{className:g()(n)},this.props.children):c.a.createElement(y["a"],null,this.props.children)}}])
n.displayName="FormFieldMessage"
return n}(l["Component"]),N.propTypes={variant:p.a.oneOf(["error","hint","success","screenreader-only"]),children:p.a.node},N.defaultProps={variant:"hint",children:null},R))||B)
var G,W,M,D
var J={componentId:"fAfJj",template:function(e){return"\n\n.fAfJj_bGBk{margin:calc(-1*".concat(e.topMargin||"inherit",") 0 0 0;padding:0}\n\n.fAfJj_elxg,.fAfJj_bGBk{display:block}")},root:"fAfJj_bGBk",message:"fAfJj_elxg"}
var P=(G=Object(j["themeable"])(T,J),G(W=(D=M=function(e){Object(s["a"])(n,e)
function n(){Object(r["a"])(this,n)
return Object(i["a"])(this,Object(o["a"])(n).apply(this,arguments))}Object(a["a"])(n,[{key:"render",value:function(){var e=this.props.messages
return e&&e.length>0?c.a.createElement("span",Object.assign({className:J.root},Object(u["a"])(this.props,n.propTypes)),e.map((function(e,n){return c.a.createElement("span",{key:"error".concat(n),className:J.message},c.a.createElement(z,{variant:e.type},e.text))}))):null}}])
n.displayName="FormFieldMessages"
return n}(l["Component"]),M.propTypes={messages:p.a.arrayOf(m.message)},M.defaultProps={messages:void 0},D))||W)
var X=function(){return{}}
var H,U,q,Y
var Q={componentId:"cWmNi",template:function(e){return"\n\n.cWmNi_bGBk{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border:0;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;direction:inherit;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;opacity:inherit;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align:start;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;width:100%;word-spacing:normal;z-index:auto}\n\n[dir=ltr] .cWmNi_bGBk{text-align:left}\n\n[dir=rtl] .cWmNi_bGBk{text-align:right}\n\n.cWmNi_eXrk{display:inline-block;vertical-align:middle;width:auto}"},root:"cWmNi_bGBk",inline:"cWmNi_eXrk"}
var K=(H=Object(j["themeable"])(X,Q),H(U=(Y=q=function(e){Object(s["a"])(n,e)
function n(e){var t
Object(r["a"])(this,n)
t=Object(i["a"])(this,Object(o["a"])(n).call(this))
t.handleInputContainerRef=function(e){t.props.inputContainerRef&&t.props.inputContainerRef(e)}
t._messagesId=e.messagesId||Object(w["a"])("FormFieldLayout-messages")
"undefined"!==typeof e.width||!e.inline||e.layout
return t}Object(a["a"])(n,[{key:"renderLabel",value:function(){return this.hasVisibleLabel?c.a.createElement(O["a"].Col,{textAlign:this.props.labelAlign,width:this.inlineContainerAndLabel?"auto":3},c.a.createElement(S,{"aria-hidden":"fieldset"===this.elementType?"true":null},this.props.label)):"fieldset"!==this.elementType?this.props.label:null}},{key:"renderLegend",value:function(){return c.a.createElement(y["a"],{as:"legend"},this.props.label,this.hasMessages&&c.a.createElement(P,{messages:this.props.messages}))}},{key:"renderMessages",value:function(){return c.a.createElement(P,{id:this._messagesId,messages:this.props.messages})}},{key:"renderVisibleMessages",value:function(){return this.hasMessages?c.a.createElement(O["a"].Row,null,c.a.createElement(O["a"].Col,{offset:this.inlineContainerAndLabel?null:3,textAlign:this.inlineContainerAndLabel?"end":null},c.a.createElement(P,{id:this._messagesId,messages:this.props.messages}))):null}},{key:"render",value:function(){var e
var t=this.elementType
var r=(e={},Object(h["a"])(e,Q.root,true),Object(h["a"])(e,Q.inline,this.props.inline),e)
return c.a.createElement(t,Object.assign({},Object(u["a"])(this.props,Object(b["a"])({},n.propTypes,{},O["a"].propTypes)),{className:g()(r),style:{width:this.props.width},"aria-describedby":this.hasMessages?this._messagesId:null}),"fieldset"===this.elementType&&this.renderLegend(),c.a.createElement(O["a"],Object.assign({rowSpacing:"small",colSpacing:"small",startAt:"inline"===this.props.layout&&this.hasVisibleLabel?"medium":null},Object(u["c"])(this.props,O["a"].propTypes)),c.a.createElement(O["a"].Row,null,this.renderLabel(),c.a.createElement(O["a"].Col,{width:this.inlineContainerAndLabel?"auto":null,elementRef:this.handleInputContainerRef},this.props.children)),this.renderVisibleMessages()))}},{key:"hasVisibleLabel",get:function(){return this.props.label&&Object(v["a"])(this.props.label)}},{key:"hasMessages",get:function(){return this.props.messages&&this.props.messages.length>0}},{key:"elementType",get:function(){return Object(k["a"])(n,this.props)}},{key:"inlineContainerAndLabel",get:function(){return this.props.inline&&"inline"===this.props.layout}}])
n.displayName="FormFieldLayout"
return n}(l["Component"]),q.propTypes={label:p.a.node.isRequired,id:p.a.string,as:p.a.elementType,messages:p.a.arrayOf(m.message),messagesId:p.a.string,children:p.a.node,inline:p.a.bool,layout:p.a.oneOf(["stacked","inline"]),labelAlign:p.a.oneOf(["start","end"]),width:p.a.string,inputContainerRef:p.a.func},q.defaultProps={id:void 0,width:void 0,messages:void 0,messagesId:void 0,children:null,inline:false,layout:"stacked",as:"label",labelAlign:"end",inputContainerRef:void 0},Y))||U)
var Z=function(e){Object(s["a"])(n,e)
function n(){Object(r["a"])(this,n)
return Object(i["a"])(this,Object(o["a"])(n).apply(this,arguments))}Object(a["a"])(n,[{key:"render",value:function(){return c.a.createElement(K,Object.assign({},Object(u["a"])(this.props,n.propTypes),Object(u["c"])(this.props,K.propTypes),{vAlign:this.props.vAlign,as:"label",htmlFor:this.props.id}))}}])
n.displayName="FormField"
return n}(l["Component"])
Z.propTypes={label:p.a.node.isRequired,id:p.a.string.isRequired,messages:p.a.arrayOf(m.message),messagesId:p.a.string,children:p.a.node,inline:p.a.bool,layout:p.a.oneOf(["stacked","inline"]),labelAlign:p.a.oneOf(["start","end"]),vAlign:p.a.oneOf(["top","middle","bottom"]),width:p.a.string,inputContainerRef:p.a.func}
Z.defaultProps={inline:false,layout:"stacked",labelAlign:"end",vAlign:"middle",messages:void 0,messagesId:void 0,children:null,width:void 0,inputContainerRef:void 0}
var $=function(e){var n=e.borders,t=e.colors,r=e.spacing
return{borderWidth:n.widthSmall,borderStyle:n.style,borderColor:"transparent",borderRadius:n.radiusMedium,errorBorderColor:t.borderDanger,errorFieldsPadding:r.xSmall}}
var ee,ne,te,re
var ae={componentId:"efIdg",template:function(e){return"\n\n.efIdg_cLpc{border:".concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";display:block}\n\n.efIdg_cLpc.efIdg_fszt{border-color:").concat(e.errorBorderColor||"inherit",";padding:").concat(e.errorFieldsPadding||"inherit","}\n\n.efIdg_cLpc.efIdg_ywdX{cursor:not-allowed;opacity:0.6;pointer-events:none}")},fields:"efIdg_cLpc",invalid:"efIdg_fszt",disabled:"efIdg_ywdX"}
var ie=(ee=Object(j["themeable"])($,ae),ee(ne=(re=te=function(e){Object(s["a"])(n,e)
function n(){Object(r["a"])(this,n)
return Object(i["a"])(this,Object(o["a"])(n).apply(this,arguments))}Object(a["a"])(n,[{key:"renderColumns",value:function(){return l["Children"].map(this.props.children,(function(e,n){return e?c.a.createElement(O["a"].Col,{width:e.props&&e.props.width?"auto":null,key:n},e):null}))}},{key:"renderChildren",value:function(){return c.a.createElement(O["a"],{colSpacing:this.props.colSpacing,rowSpacing:this.props.rowSpacing,vAlign:this.props.vAlign,startAt:this.props.startAt||("columns"===this.props.layout?"medium":null)},c.a.createElement(O["a"].Row,null,this.renderColumns()))}},{key:"renderFields",value:function(){var e
return c.a.createElement("span",{key:"fields",className:g()((e={},Object(h["a"])(e,ae.fields,true),Object(h["a"])(e,ae.invalid,this.invalid),Object(h["a"])(e,ae.disabled,this.props.disabled),e))},this.renderChildren())}},{key:"render",value:function(){return c.a.createElement(K,Object.assign({},Object(u["a"])(this.props,n.propTypes),Object(u["c"])(this.props,K.propTypes),{vAlign:this.props.vAlign,layout:"inline"===this.props.layout?"inline":"stacked",label:this.props.description,"aria-disabled":this.props.disabled?"true":null,"aria-invalid":this.invalid?"true":null}),this.renderFields())}},{key:"invalid",get:function(){return this.props.messages&&this.props.messages.findIndex((function(e){return"error"===e.type}))>=0}}])
n.displayName="FormFieldGroup"
return n}(l["Component"]),te.propTypes={description:p.a.node.isRequired,as:p.a.elementType,messages:p.a.arrayOf(m.message),messagesId:p.a.string,disabled:p.a.bool,children:p.a.node,layout:p.a.oneOf(["stacked","columns","inline"]),rowSpacing:p.a.oneOf(["none","small","medium","large"]),colSpacing:p.a.oneOf(["none","small","medium","large"]),vAlign:p.a.oneOf(["top","middle","bottom"]),startAt:p.a.oneOf(["small","medium","large","x-large",null])},te.defaultProps={children:null,layout:void 0,startAt:void 0,messages:void 0,messagesId:void 0,as:"fieldset",disabled:false,rowSpacing:"medium",colSpacing:"small",vAlign:"middle"},re))||ne)
t.d(n,"FormField",(function(){return Z}))
t.d(n,"FormFieldLabel",(function(){return S}))
t.d(n,"FormFieldMessage",(function(){return z}))
t.d(n,"FormFieldMessages",(function(){return P}))
t.d(n,"FormFieldLayout",(function(){return K}))
t.d(n,"FormFieldGroup",(function(){return ie}))
t.d(n,"FormPropTypes",(function(){return m}))}}])

//# sourceMappingURL=5-c-00d2341041.js.map