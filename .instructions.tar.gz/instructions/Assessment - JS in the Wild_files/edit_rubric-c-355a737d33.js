(window["canvasWebpackJsonp"]=window["canvasWebpackJsonp"]||[]).push([[298,573,580,591,594,648],{"/iD7":function(e,t,n){"use strict"
var o=n("pQTu")
var i=n("m0r6")
Object(i["a"])(JSON.parse('{"ar":{"editor":{"keyboard_shortcuts":{"dialog_title":"اختصارات لوحة المفاتيح","keybindings":{"close_submenu":"إغلاق القائمة أو مربع الحوار يعيدك أيضاً إلى المحرر","navigate_toolbar":"الانتقال إلى اليمين/اليسار من خلال القائمة/شريط الأدوات","open_menubar":"فتح شريط القوائم الخاص بالمحرر","open_toolbar":"فتح شريط الأدوات الخاص بالمحرر"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"افتح مربع حوار اختصارات لوحة المفاتيح هذا"},"cy":{"editor":{"keyboard_shortcuts":{"dialog_title":"Bysellau Hwylus","keybindings":{"close_submenu":"Gallwch hefyd fynd yn ôl i ardal y golygydd drwy gau’r ddewislen neu’r blwch deialog","navigate_toolbar":"Mynd i’r chwith/dde drwy’r ddewislen/bar offer","open_menubar":"Agor bar dewislen y golygydd","open_toolbar":"Agor bar offer y golygydd"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Agor y ddeialog bysellau hwylus"},"da":{"editor":{"keyboard_shortcuts":{"dialog_title":"Genvejstaster","keybindings":{"close_submenu":"Lukning af menu eller dialog bringer dig også tilbage til redigeringsområdet","navigate_toolbar":"Naviger til venstre/højre gennem menuen/værktøjslinjen","open_menubar":"Åbn redigeringsprogrammets menulinje","open_toolbar":"Åbn redigeringsprogrammets værktøjslinje"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Åbn dialogen for denne genvejstast"},"da-x-k12":{"editor":{"keyboard_shortcuts":{"dialog_title":"Genvejstaster","keybindings":{"close_submenu":"Lukning af menu eller dialog bringer dig også tilbage til redigeringsområdet","navigate_toolbar":"Naviger til venstre/højre gennem menuen/værktøjslinjen","open_menubar":"Åbn redigeringsprogrammets menulinje","open_toolbar":"Åbn redigeringsprogrammets værktøjslinje"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Åbn dialogen for denne genvejstast"},"de":{"editor":{"keyboard_shortcuts":{"dialog_title":"Tastenkombinationen","keybindings":{"close_submenu":"Schließen des Menüs oder Dialogs bringt Sie ebenfalls in den Editor-Bereich zurück.","navigate_toolbar":"Links/rechts Navigation durch Menü/Symbolleiste","open_menubar":"Editor-Menüleiste öffnen","open_toolbar":"Symbolleiste des Editors öffnen"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Diesen Tastenkombinationsdialog öffnen"},"el":{"editor":{"keyboard_shortcuts":{"dialog_title":"Συντομεύσεις Πληκτορολογίου","keybindings":{"close_submenu":"Το κλείσιμο του μενού ή του διαλόγου επίσης σας γυρίζει πίσω στον χώρο του επεξεργαστή","navigate_toolbar":"Πλοήγηση αριστερά/δεξιά μέσω του μενού/της γραμμής εργαλείων","open_menubar":"Άνοιγμα της γραμμής μενού του επεξεργαστή","open_toolbar":"Άνοιγμα της γραμμής εργαλείων του επεξεργαστή"}}}},"en-AU":{"editor":{"keyboard_shortcuts":{"dialog_title":"Keyboard Shortcuts","keybindings":{"close_submenu":"Close Menu or Dialogue, also gets you back to the editor area.","navigate_toolbar":"Navigate left/right through the menu/toolbar.","open_menubar":"Open the editor\'s menu bar.","open_toolbar":"Open the editor\'s toolbar"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Open this keyboard shortcuts dialog"},"en-CA":{"editor":{"keyboard_shortcuts":{"dialog_title":"Keyboard Shortcuts","keybindings":{"close_submenu":"Close menu or dialog, also gets you back to editor area","navigate_toolbar":"Navigate left/right through menu/toolbar","open_menubar":"Open the editor\'s menubar","open_toolbar":"Open the editor\'s toolbar"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Open this keyboard shortcuts dialog"},"en-GB":{"editor":{"keyboard_shortcuts":{"dialog_title":"Keyboard shortcuts","keybindings":{"close_submenu":"Close menu or dialog box; also gets you back to editor area","navigate_toolbar":"Navigate left/right through menu/toolbar","open_menubar":"Open the editor\'s menu bar","open_toolbar":"Open the editor\'s toolbar"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Open this keyboard shortcuts dialogue"},"es":{"editor":{"keyboard_shortcuts":{"dialog_title":"Atajos del teclado","keybindings":{"close_submenu":"Cerrar el menú o cuadro de diálogo, también le regresa al área de editor","navigate_toolbar":"Navegar a la izquierda/derecha a través del menú/barra de herramientas","open_menubar":"Abrir la barra de menú del editor","open_toolbar":"Abrir la barra de herramientas del editor"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Abrir este cuadro de diálogo de atajos de teclado"},"fa":{"editor":{"keyboard_shortcuts":{"dialog_title":"میانبرهای صفحه کلید","keybindings":{"close_submenu":"بستن منو یا گفتگو نیز شما را به قسمت ویرایشگر برمی گرداند","navigate_toolbar":"پیمایش به سمت چپ/راست از طریق منو/نوار ابزار","open_menubar":"باز کردن نوار ابزار ویرایشگر","open_toolbar":"باز کردن نوار ابزار ویرایشگر"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"باز کردن این کادر گفتکوی میانبرهای صفحه کلید"},"fi":{"editor":{"keyboard_shortcuts":{"dialog_title":"Pikanäppäimet","keybindings":{"close_submenu":"Sulje valikko tai valintaruutu, niin pääset myös takaisin editori-alueelle","navigate_toolbar":"Siirry vasemmalle/oikealle valikon/työkalupalkin kautta","open_menubar":"Avaa editorin valikkopalkki","open_toolbar":"Avaa editorin työkalupalkki"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Avaa tämä näppäimistön pikakuvakkeiden valintaruutu"},"fr":{"editor":{"keyboard_shortcuts":{"dialog_title":"Raccourcis clavier","keybindings":{"close_submenu":"Fermer le menu ou dialogue, vous ramènera aussi sur l\'éditeur","navigate_toolbar":"Naviguer à gauche/à droite dans le menu/la barre d\'outils","open_menubar":"Ouvrir la barre des menus de l’éditeur","open_toolbar":"Ouvrir la barre d’outils de l’éditeur"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Ouvrir cette boîte de dialogues des raccourcis clavier"},"fr-CA":{"editor":{"keyboard_shortcuts":{"dialog_title":"Raccourcis clavier","keybindings":{"close_submenu":"Fermer le menu ou dialogue, vous ramènera aussi sur l\'éditeur","navigate_toolbar":"Naviguer à gauche/à droite dans le menu/la barre d\'outils","open_menubar":"Ouvrir la barre des menus de l’éditeur","open_toolbar":"Ouvrir la barre d’outils de l’éditeur"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Ouvrir cette boîte de dialogues des raccourcis clavier"},"he":{"editor":{"keyboard_shortcuts":{"dialog_title":"קיצורי דרך מקלדת ","keybindings":{"close_submenu":"סגירת תפריט או דיאלוג, גם כן תחזירך אל איזור העריכה","navigate_toolbar":"ניווט שמאלי/ימני בעזרת תפריט/סרגל הכלים","open_menubar":"פתיחת סרגל תפריט העריכה ","open_toolbar":"פתיחת סרגל העריכה"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"פתיחת חלון דיאלוג של מקשי קיצור"},"ht":{"editor":{"keyboard_shortcuts":{"dialog_title":"Rakousi Klavye","keybindings":{"close_submenu":"Fèmen mesi oswa dyalòg, ap mennen w retounen tou nan zòn editè a tou","navigate_toolbar":"Navige agoch/adwat atravè meni/ba zouti a","open_menubar":"Ouvri ba meni editè a","open_toolbar":"Ouvri ba zouti editè a"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Ouvri dyalòg rakousi klavye sa a"},"hu":{"editor":{"keyboard_shortcuts":{"dialog_title":"Billentyűparancsok","keybindings":{"close_submenu":"Menü vagy párbeszédablak bezárása, visszavisz a szerkesztő felületre","navigate_toolbar":"Navigáljon balra/jobbra a menün/eszköztáron át","open_menubar":"Szerkesztői menüsor megnyitása","open_toolbar":"Szerkesztői eszköztár megnyitása"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Nyissa meg a billentyűkombinációk párbeszédablakot"},"hy":{"editor":{"keyboard_shortcuts":{"dialog_title":"Արագ հասանելիության ստեղներ","keybindings":{"close_submenu":"Եթե փակեք մենյուն կամ երկխոսության պատուհանը, կվերադառնաք խմբագրի տեղը","navigate_toolbar":"Նավարկեք ձախ/աջ մենյուի/գործիքների տողով","open_menubar":"Բացել խմբագրի մենյուի տողը","open_toolbar":"Բացել խմբագրի գործիքների տողը"}}}},"is":{"editor":{"keyboard_shortcuts":{"dialog_title":"Flýtilyklar","keybindings":{"close_submenu":"Með því að loka valmynd eða samtali ferðu aftur á breytingasvæði","navigate_toolbar":"Fara til vinstri/hægri gegnum valmynd/tólaslá","open_menubar":"Opna valslá ritils","open_toolbar":"Opna tólaslá ritils"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Opna svarglugga flýtilykla"},"it":{"editor":{"keyboard_shortcuts":{"dialog_title":"Scelte rapide da tastiera","keybindings":{"close_submenu":"Chiude il menu o la finestra di dialogo e riporta all\'area dell\'editor","navigate_toolbar":"Spostati a sinistra/destra nel menu o nella barra degli strumenti","open_menubar":"Apri la barra dei menu dell\'editor","open_toolbar":"Apri la barra degli strumenti dell\'editor"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Apri questa finestra di dialogo delle scelte rapide da tastiera"},"ja":{"editor":{"keyboard_shortcuts":{"dialog_title":"キーボード ショートカット","keybindings":{"close_submenu":"メニューまたはダイアログを閉じて、編集エリアに戻ります","navigate_toolbar":"メニュー/ツールバーを通して左/右をナビゲート","open_menubar":"編集のメニューバーを開く","open_toolbar":"エディタのツールバーを表示"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"このキーボードショートカットダイアログを開く"},"ko":{"editor":{"keyboard_shortcuts":{"dialog_title":"키보드 단축키"}}},"mi":{"editor":{"keyboard_shortcuts":{"dialog_title":"Pokatata papapātuhi","keybindings":{"close_submenu":"Katia tahua kōrero rānei anō, whiwhi koe hoki ki te wāhi ētita","navigate_toolbar":"Whakatere maui/matau ki roto i te tahua/paeutauta","open_menubar":"Whakatūwhera paetahua o te ētita","open_toolbar":"Whakatūwhera paeutauta o te ētita"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Huaki tēnei pokatata papapātuhi kōrero"},"nb":{"editor":{"keyboard_shortcuts":{"dialog_title":"Snarveier","keybindings":{"close_submenu":"Lukk meny eller dialogboks, får deg også tilbake til redigeringsområde","navigate_toolbar":"Naviger med venstre/høyre gjennom menyen/verktøylinjen","open_menubar":"Åpne editor-verktøylinje","open_toolbar":"Åpne redigerings-verktøylinje"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Åpne denne tastatursnarveidialogen"},"nb-x-k12":{"editor":{"keyboard_shortcuts":{"dialog_title":"Snarveier","keybindings":{"close_submenu":"Lukk meny eller dialogboks, får deg også tilbake til redigeringsområde","navigate_toolbar":"Naviger med venstre/høyre gjennom menyen/verktøylinjen","open_menubar":"Åpne editor-verktøylinje","open_toolbar":"Åpne redigerings-verktøylinje"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Åpne denne tastatursnarveidialogen"},"nl":{"editor":{"keyboard_shortcuts":{"dialog_title":"Sneltoetsen","keybindings":{"close_submenu":"Menu of dialoog sluiten, brengt u ook terug naar editorgebied","navigate_toolbar":"Naar links/rechts navigeren via menu/werkbalk","open_menubar":"De werkbalk van de editor openen","open_toolbar":"De toolbalk van de editor openen"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Open dit dialoogvenster met sneltoetsen"},"nn":{"editor":{"keyboard_shortcuts":{"dialog_title":"Hurtigtastar","keybindings":{"close_submenu":"Om du lukkar menyen eller dialogen, kjem du tilbake til redigeringsområdet","navigate_toolbar":"Naviger venstre/høgre gjennom menyen/verktøylinja","open_menubar":"Opne menylinja i redigeringsprogrammet","open_toolbar":"Opne verktøylinja i redigeringsprogrammet"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Opne denne hurtigtastar-dialogen"},"pl":{"editor":{"keyboard_shortcuts":{"dialog_title":"Skróty klawiaturowe","keybindings":{"close_submenu":"Zamknij menu lub dialog, również powraca do strefy edycji","navigate_toolbar":"Nawigacja w lewo/prawo przez menu/pasek narzędzi","open_menubar":"Otwórz pasek menu edytora","open_toolbar":"Otwórz pasek narzędzi edytora"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Otwórz to okno dialogowe skrótów klawiatury"},"pt":{"editor":{"keyboard_shortcuts":{"dialog_title":"Atalhos de teclado","keybindings":{"close_submenu":"Fechar menu ou diálogo, transporta-o de volta para a área de editor","navigate_toolbar":"Navegue para a esquerda/direita pelo menu/barra de ferramentas","open_menubar":"Abrir a barra de menu do editor","open_toolbar":"Abrir a barra de ferramentas do editor"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Abrir esta caixa de diálogo de atalhos do teclado"},"pt-BR":{"editor":{"keyboard_shortcuts":{"dialog_title":"Atalhos de Teclado","keybindings":{"close_submenu":"Fechar menu ou diálogo, também o leva de volta para a área do editor","navigate_toolbar":"Navegar para esquerda/direita pelo menu/barra de ferramentas","open_menubar":"Abrir a barra de menu do editor","open_toolbar":"Abrir a barra de ferramentas do editor"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Abrir esta caixa de atalhos do teclado"},"ru":{"editor":{"keyboard_shortcuts":{"dialog_title":"Клавиши быстрого доступа","keybindings":{"close_submenu":"Если вы закроете меню или диалоговое окно, то также перейдете обратно в область редактора","navigate_toolbar":"Перейдите влево / вправо по меню / панели инструментов","open_menubar":"Откройте панель меню редактора","open_toolbar":"Открыть панель инструментов редактора"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Открыть этот диалог комбинаций клавиш"},"sl":{"editor":{"keyboard_shortcuts":{"dialog_title":"Bližnjice","keybindings":{"close_submenu":"Zaprite meni ali pogovorno okno; tako se boste premaknili tudi na območje urejevalnika.","navigate_toolbar":"Navigirajte levo/desno prek menija/orodne vrstice","open_menubar":"Odprite menijsko vrstico urejevalnika","open_toolbar":"Odprite orodno vrstico urejevalnika"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Odpri to pogovorno okno z bližnjicami"},"sv":{"editor":{"keyboard_shortcuts":{"dialog_title":"Kortkommandon","keybindings":{"close_submenu":"Stäng meny eller dialog, tar dig också tillbaka till redigeringsområdet","navigate_toolbar":"Navigera till vänster/höger genom menyn/verktygsfältet","open_menubar":"Öppna redigerarens menyfält","open_toolbar":"Öppna redigerarens verktygsfält"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Öppna den här dialogen för tangentbordsgenvägar"},"sv-x-k12":{"editor":{"keyboard_shortcuts":{"dialog_title":"Kortkommandon","keybindings":{"close_submenu":"Stäng meny eller dialog, tar dig också tillbaka till redigeringsområdet","navigate_toolbar":"Navigera till vänster/höger genom menyn/verktygsfältet","open_menubar":"Öppna redigerarens menyfält","open_toolbar":"Öppna redigerarens verktygsfält"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Öppna den här dialogen för tangentbordsgenvägar"},"tr":{"editor":{"keyboard_shortcuts":{"dialog_title":"Klavye Kısayolları","keybindings":{"close_submenu":"Menü veya diyaloğu kapat, düzenleyici alan geri dönersiniz","navigate_toolbar":"Menü/araç çubuğu ile sola/sağa gezinin","open_menubar":"Düzenleyici menü çubuğunu aç","open_toolbar":"Düzenleyici araç çubuğunu aç"}}}},"uk":{"editor":{"keyboard_shortcuts":{"dialog_title":"Гарячі клавіши","keybindings":{"close_submenu":"Закрийте меню або діалог, це також поверне вас назад до області редактора","navigate_toolbar":"Переміщайтесь вліво / вправо за допомогою меню / панелі інструментів","open_menubar":"Відкрити панель меню редактора","open_toolbar":"Відкрити панель інструментів редактора"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"Вікрити діалогове вікно гарячих клавіш"},"zh-Hans":{"editor":{"keyboard_shortcuts":{"dialog_title":"键盘快捷方式","keybindings":{"close_submenu":"关闭了菜单或对话框，您还可以回到编辑区域。","navigate_toolbar":"通过菜单/工具栏，导航左/右。","open_menubar":"打开编辑器的菜单栏","open_toolbar":"打开编辑器的工具栏"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"打开此键盘快捷方式对话框"},"zh-Hant":{"editor":{"keyboard_shortcuts":{"dialog_title":"鍵盤快捷鍵","keybindings":{"close_submenu":"關閉菜單或對話之後，您還可以回到編輯區域","navigate_toolbar":"透過菜單/工具欄左/右導航","open_menubar":"打開編輯器的菜單欄","open_toolbar":"打開編輯器的工具欄"}}},"open_this_keyboard_shortcuts_dialog_9658b83a":"打開此鍵盤的快捷鍵對話框"}}'))
n("jQeR")
n("0sPK")
var a=o["default"].scoped("editor.keyboard_shortcuts")
var r=n("ouhR")
var s=n.n(r)
var l=n("FIFq")
var c=n.n(l)
var d=n("3O+N")
var u=n.n(d)
n("DfGn")
var b=n("EvX+")
var h=u.a.default
var _=h.template,p=h.templates=h.templates||{}
var g="editor/KeyboardShortcuts"
p[g]=_((function(e,t,n,o,i){this.compilerInfo=[4,">= 1.0.0"]
n=this.merge(n,e.helpers)
i=i||{}
var a,r="",s="function",l=this.escapeExpression,c=this
function d(e,t){var o,i,a=""
a+="\n    <li>\n      <code>"
if(i=n.key)o=i.call(e,{hash:{},data:t})
else{i=e&&e.key
o=typeof i===s?i.call(e,{hash:{},data:t}):i}a+=l(o)+"</code>\n      <span>"
if(i=n.description)o=i.call(e,{hash:{},data:t})
else{i=e&&e.description
o=typeof i===s?i.call(e,{hash:{},data:t}):i}a+=l(o)+"</span>\n    </li>\n  "
return a}r+='<ul class="tinymce-keyboard-shortcuts">\n  '
a=n.each.call(t,t&&t.keybindings,{hash:{},inverse:c.noop,fn:c.program(1,d,i),data:i});(a||0===a)&&(r+=a)
r+="\n</ul>\n"
return r}))
b["a"].loadStylesheet("jst/editor/KeyboardShortcuts",{new_styles_normal_contrast:{combinedChecksum:"f4493af988"},new_styles_high_contrast:{combinedChecksum:"f4493af988"},responsive_layout_normal_contrast:{combinedChecksum:"f4493af988"},responsive_layout_high_contrast:{combinedChecksum:"f4493af988"},new_styles_normal_contrast_rtl:{combinedChecksum:"9b568bbcaf"},new_styles_high_contrast_rtl:{combinedChecksum:"9b568bbcaf"},responsive_layout_normal_contrast_rtl:{combinedChecksum:"9b568bbcaf"},responsive_layout_high_contrast_rtl:{combinedChecksum:"9b568bbcaf"}}[b["a"].getCssVariant()])
var f=p[g]
var m,y
m=[48,119]
y=c.a.View.extend({className:"tinymce-keyboard-shortcuts-toggle",tagName:"a",events:{click:"openDialog"},keybindings:[{key:"ALT+F9",description:a.t("keybindings.open_menubar","Open the editor's menubar")},{key:"ALT+F10",description:a.t("keybindings.open_toolbar","Open the editor's toolbar")},{key:"ESC",description:a.t("keybindings.close_submenu","Close menu or dialog, also gets you back to editor area")},{key:"TAB/Arrows",description:a.t("keybindings.navigate_toolbar","Navigate left/right through menu/toolbar")},{key:"ALT+F8",description:a.t("Open this keyboard shortcuts dialog")}],template:f,initialize:function(){this.el.href="#"
s()(this.el).attr("title",a.t("dialog_title","Keyboard Shortcuts"))
s()('<i class="icon-keyboard-shortcuts" aria-hidden="true" />').appendTo(this.el)
return s()('<span class="screenreader-only" />').text(a.t("dialog_title","Keyboard Shortcuts")).appendTo(this.el)},render:function(){var e
e={keybindings:this.keybindings}
this.$dialog=s()(this.template(e)).dialog({title:a.t("dialog_title","Keyboard Shortcuts"),width:600,resizable:true,autoOpen:false})
this.bindEvents()
return this},bindEvents:function(){if(!ENV.use_rce_enhancements){s()(document).on("keyup.tinymce_keyboard_shortcuts",this.openDialogByKeybinding.bind(this))
return s()(document).on("editorKeyUp",function(e,t){return this.openDialogByKeybinding(t)}.bind(this))}},remove:function(){s()(document).off("keyup.tinymce_keyboard_shortcuts")
s()(document).off("editorKeyUp")
return this.$dialog.dialog("destroy")},openDialog:function(){if(!this.$dialog.dialog("isOpen"))return this.$dialog.dialog("open")},openDialogByKeybinding:function(e){if(m.indexOf(e.keyCode)>-1&&e.altKey)return this.openDialog()}})
t["a"]=y},"0crz":function(e,t,n){"use strict"
var o=n("ouhR")
var i=n.n(o)
var a=n("pQTu")
var r=n("m0r6")
Object(r["a"])(JSON.parse('{"ar":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"إظهار النص المقتبس","word_separator":" "}}},"cy":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"dangos testun wedi’i ddyfynnu","word_separator":" "}}},"da":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"vis tekst i gåseøjne","word_separator":" "}}},"da-x-k12":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"vis tekst i gåseøjne","word_separator":" "}}},"de":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"zitierten Text zeigen","word_separator":" "}}},"el":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"προβολή κειμένου που παρατίθεται"}}},"en-AU":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"show quoted text","word_separator":" "}}},"en-CA":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"show quoted text","word_separator":" "}}},"en-GB":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"show quoted text","word_separator":" "}}},"es":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"mostrar texto citado","word_separator":" "}}},"fa":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"نمایش متن نقل شده","word_separator":" "}}},"fi":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"näytä lainattu teksti","word_separator":" "}}},"fr":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"afficher le texte entre guillemets","word_separator":" "}}},"fr-CA":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"afficher le texte entre guillemets","word_separator":" "}}},"he":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"מציג ציטוט","word_separator":" "}}},"ht":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"afiche tèks site","word_separator":" "}}},"hu":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"idézett szöveg megjelenítése","word_separator":" "}}},"hy":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"ցույց տալ մեջբերվող տեքստը","word_separator":"-"}}},"is":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"Sýna ívitnaðan texta","word_separator":" "}}},"it":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"mostra testo citato","word_separator":" "}}},"ja":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"引用したテキストを表示","word_separator":" "}}},"ko":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"인용된 텍스트 표시","word_separator":" "}}},"mi":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"whakaatu kuputuhi faahiti","word_separator":"-"}}},"nb":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"vis den merkede teksten","word_separator":" "}}},"nb-x-k12":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"vis den merkede teksten","word_separator":" "}}},"nl":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"geciteerde tekst tonen","word_separator":" "}}},"nn":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"vis sitert tekst","word_separator":" "}}},"pl":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"pokaż cytowany fragment tekstu","word_separator":" "}}},"pt":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"exibir texto citado","word_separator":" "}}},"pt-BR":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"exibir texto citado","word_separator":" "}}},"ru":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"показать цитированный текст","word_separator":" "}}},"sl":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"prikaži citirano besedilo","word_separator":" "}}},"sv":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"visa citerad text","word_separator":" "}}},"sv-x-k12":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"visa citerad text","word_separator":" "}}},"tr":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"alıntılanan metni göster","word_separator":" "}}},"uk":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"Показати цитований текст","word_separator":" "}}},"zh-Hans":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"显示引用的文本","word_separator":" "}}},"zh-Hant":{"lib":{"text_helper":{"ellipsis":"...","quoted_text_toggle":"顯示引用的文字","word_separator":" "}}}}'))
n("jQeR")
n("0sPK")
var s=a["default"].scoped("lib.text_helper")
var l=n("5Ky4")
var c,d,u
c="LINK-PLACEHOLDER"
d=/\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\([^\s()<>]*\))+(?:\([^\s()<>]*\)|[^\s`!()\[\]{};:'".,<>?«»“”‘’]))|(LINK-PLACEHOLDER)/gi
t["a"]=u={quoteClump:function(e){return"<div class='quoted_text_holder'> <a href='#' class='show_quoted_text_link'>"+Object(l["a"])(s.t("quoted_text_toggle","show quoted text"))+"</a> <div class='quoted_text' style='display: none;'> "+i.a.raw(e.join("\n"))+" </div> </div>"},formatMessage:function(e){var t,n,o,i,a,r,s,b
i=[]
a=[]
e=e.replace(d,(function(e,t){var n
a.push(e===c?c:(n=e,"http://"===n.slice(0,7)||"https://"===n.slice(0,8)||(n="http://"+n),i.push(n),"<a href='"+Object(l["a"])(n)+"'>"+Object(l["a"])(e)+"</a>"))
return c}))
e=Object(l["a"])(e)
e=e.replace(new RegExp(c,"g"),(function(e,t){return a.shift()}))
e=e.replace(/\n/g,"<br />\n")
r=[]
s=[]
b=e.split("\n")
for(t=0,n=b.length;t<n;t++){o=b[t]
if(o.match(/^(&gt;|>)/))s.push(o)
else{s.length&&r.push(u.quoteClump(s))
s=[]
r.push(o)}}s.length&&r.push(u.quoteClump(s))
return r.join("\n")},delimit:function(e){var t,n,o,i,a
if(isNaN(e))return String(e)
a=e<0?"-":""
t=Math.abs(e)
if(Infinity===t)return String(e)
n=Math.floor(t)
i=t===n?"":String(t).replace(/^\d+\./,".")
while(n>=1e3){o=String(n).replace(/\d+(\d\d\d)$/,",$1")
n=Math.floor(n/1e3)
i=o+i}return a+String(n)+i},truncateText:function(e,t){var n,o,i,a,r,l
null==t&&(t={})
o=null!=(a=t.max)?a:30
n=s.t("ellipsis","...")
l=s.t("word_separator"," ")
e=(null!=e?e:"").replace(/\s+/g,l).trim()
if(!e||e.length<=o)return e
r=0
while(true){i=e.indexOf(l,r+1)
if(i<0||i>o-n.length)break
r=i}r||(r=o-n.length)
return e.substring(0,r)+n},plainText:function(e){return e.replace(/(<([^>]+)>)/gi,"")}}},"5JRF":function(e,t,n){"use strict"
var o=n("rePB")
var i=n("1OyB")
var a=n("vuIU")
var r=n("md7G")
var s=n("foSv")
var l=n("Ji7U")
var c=n("q1tI")
var d=n.n(c)
var u=n("17x9")
var b=n.n(u)
var h=n("TSYQ")
var _=n.n(h)
var p=n("J2CL")
var g=n("nAyT")
var f=n("KgFQ")
var m=n("jtGx")
var y=n("VTBJ")
function v(e){var t=e.typography,n=e.colors,o=e.spacing
return Object(y["a"])({},t,{primaryInverseColor:n.textLightest,primaryColor:n.textDarkest,secondaryColor:n.textDark,secondaryInverseColor:n.textLight,warningColor:n.textWarning,brandColor:n.textBrand,errorColor:n.textDanger,successColor:n.textSuccess,alertColor:n.textAlert,paragraphMargin:"".concat(o.medium," 0")})}v.canvas=function(e){return{primaryColor:e["ic-brand-font-color-dark"],brandColor:e["ic-brand-primary"]}}
n.d(t,"a",(function(){return U}))
var k,j,w,x,B
var O={componentId:"cjUyb",template:function(e){return"\n\n.cjUyb_bGBk{font-family:".concat(e.fontFamily||"inherit","}\n\n.cjUyb_bGBk sub,.cjUyb_bGBk sup{font-size:75%;line-height:0;position:relative;vertical-align:baseline}\n\n.cjUyb_bGBk sup{top:-0.4em}\n\n.cjUyb_bGBk sub{bottom:-0.4em}\n\n.cjUyb_bGBk code,.cjUyb_bGBk pre{all:initial;animation:none 0s ease 0s 1 normal none running;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;border:medium none currentColor;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;caption-side:top;clear:none;clip:auto;color:#000;column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;empty-cells:show;float:none;font-family:serif;font-family:").concat(e.fontFamilyMonospace||"inherit",";font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;word-spacing:normal;z-index:auto}\n\n.cjUyb_bGBk em,.cjUyb_bGBk i{font-style:italic}\n\n.cjUyb_bGBk b,.cjUyb_bGBk strong{font-weight:").concat(e.fontWeightBold||"inherit","}\n\n.cjUyb_bGBk p{display:block;margin:").concat(e.paragraphMargin||"inherit",";padding:0}\n\ninput.cjUyb_bGBk[type]{-moz-appearance:none;-webkit-appearance:none;appearance:none;background:none;border:none;border-radius:0;box-shadow:none;box-sizing:border-box;color:inherit;display:block;height:auto;line-height:inherit;margin:0;outline:0;padding:0;text-align:start;width:100%}\n\n[dir=ltr] input.cjUyb_bGBk[type]{text-align:left}\n\n[dir=rtl] input.cjUyb_bGBk[type]{text-align:right}\n\n.cjUyb_bGBk:focus,input.cjUyb_bGBk[type]:focus{outline:none}\n\n.cjUyb_bGBk.cjUyb_qFsi,input.cjUyb_bGBk[type].cjUyb_qFsi{color:").concat(e.primaryColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bLsb,input.cjUyb_bGBk[type].cjUyb_bLsb{color:").concat(e.secondaryColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ezBQ,input.cjUyb_bGBk[type].cjUyb_ezBQ{color:").concat(e.primaryInverseColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dlnd,input.cjUyb_bGBk[type].cjUyb_dlnd{color:").concat(e.secondaryInverseColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_cJLh,input.cjUyb_bGBk[type].cjUyb_cJLh{color:").concat(e.successColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fpfC,input.cjUyb_bGBk[type].cjUyb_fpfC{color:").concat(e.brandColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eHcp,input.cjUyb_bGBk[type].cjUyb_eHcp{color:").concat(e.warningColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dwua,input.cjUyb_bGBk[type].cjUyb_dwua{color:").concat(e.errorColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eZgl,input.cjUyb_bGBk[type].cjUyb_eZgl{color:").concat(e.alertColor||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fbNi,input.cjUyb_bGBk[type].cjUyb_fbNi{-ms-hyphens:auto;-webkit-hyphens:auto;hyphens:auto;overflow-wrap:break-word;word-break:break-word}\n\n.cjUyb_bGBk.cjUyb_drST,input.cjUyb_bGBk[type].cjUyb_drST{font-weight:").concat(e.fontWeightNormal||"inherit","}\n\n.cjUyb_bGBk.cjUyb_pEgL,input.cjUyb_bGBk[type].cjUyb_pEgL{font-weight:").concat(e.fontWeightLight||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bdMA,input.cjUyb_bGBk[type].cjUyb_bdMA{font-weight:").concat(e.fontWeightBold||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ijuF,input.cjUyb_bGBk[type].cjUyb_ijuF{font-style:normal}\n\n.cjUyb_bGBk.cjUyb_fetN,input.cjUyb_bGBk[type].cjUyb_fetN{font-style:italic}\n\n.cjUyb_bGBk.cjUyb_dfBC,input.cjUyb_bGBk[type].cjUyb_dfBC{font-size:").concat(e.fontSizeXSmall||"inherit","}\n\n.cjUyb_bGBk.cjUyb_doqw,input.cjUyb_bGBk[type].cjUyb_doqw{font-size:").concat(e.fontSizeSmall||"inherit","}\n\n.cjUyb_bGBk.cjUyb_ycrn,input.cjUyb_bGBk[type].cjUyb_ycrn{font-size:").concat(e.fontSizeMedium||"inherit","}\n\n.cjUyb_bGBk.cjUyb_cMDj,input.cjUyb_bGBk[type].cjUyb_cMDj{font-size:").concat(e.fontSizeLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eoMd,input.cjUyb_bGBk[type].cjUyb_eoMd{font-size:").concat(e.fontSizeXLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fdca,input.cjUyb_bGBk[type].cjUyb_fdca{font-size:").concat(e.fontSizeXXLarge||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fEWX,input.cjUyb_bGBk[type].cjUyb_fEWX{line-height:").concat(e.lineHeight||"inherit","}\n\n.cjUyb_bGBk.cjUyb_fNIu,input.cjUyb_bGBk[type].cjUyb_fNIu{line-height:").concat(e.lineHeightFit||"inherit","}\n\n.cjUyb_bGBk.cjUyb_dfDs,input.cjUyb_bGBk[type].cjUyb_dfDs{line-height:").concat(e.lineHeightCondensed||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bDjL,input.cjUyb_bGBk[type].cjUyb_bDjL{line-height:").concat(e.lineHeightDouble||"inherit","}\n\n.cjUyb_bGBk.cjUyb_eQnG,input.cjUyb_bGBk[type].cjUyb_eQnG{letter-spacing:").concat(e.letterSpacingNormal||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bbUA,input.cjUyb_bGBk[type].cjUyb_bbUA{letter-spacing:").concat(e.letterSpacingCondensed||"inherit","}\n\n.cjUyb_bGBk.cjUyb_bRWU,input.cjUyb_bGBk[type].cjUyb_bRWU{letter-spacing:").concat(e.letterSpacingExpanded||"inherit","}\n\n.cjUyb_bGBk.cjUyb_wZsr,input.cjUyb_bGBk[type].cjUyb_wZsr{text-transform:none}\n\n.cjUyb_bGBk.cjUyb_fCZK,input.cjUyb_bGBk[type].cjUyb_fCZK{text-transform:capitalize}\n\n.cjUyb_bGBk.cjUyb_dsRi,input.cjUyb_bGBk[type].cjUyb_dsRi{text-transform:uppercase}\n\n.cjUyb_bGBk.cjUyb_bLtD,input.cjUyb_bGBk[type].cjUyb_bLtD{text-transform:lowercase}")},root:"cjUyb_bGBk","color-primary":"cjUyb_qFsi","color-secondary":"cjUyb_bLsb","color-primary-inverse":"cjUyb_ezBQ","color-secondary-inverse":"cjUyb_dlnd","color-success":"cjUyb_cJLh","color-brand":"cjUyb_fpfC","color-warning":"cjUyb_eHcp","color-error":"cjUyb_dwua","color-alert":"cjUyb_eZgl","wrap-break-word":"cjUyb_fbNi","weight-normal":"cjUyb_drST","weight-light":"cjUyb_pEgL","weight-bold":"cjUyb_bdMA","style-normal":"cjUyb_ijuF","style-italic":"cjUyb_fetN","x-small":"cjUyb_dfBC",small:"cjUyb_doqw",medium:"cjUyb_ycrn",large:"cjUyb_cMDj","x-large":"cjUyb_eoMd","xx-large":"cjUyb_fdca","lineHeight-default":"cjUyb_fEWX","lineHeight-fit":"cjUyb_fNIu","lineHeight-condensed":"cjUyb_dfDs","lineHeight-double":"cjUyb_bDjL","letterSpacing-normal":"cjUyb_eQnG","letterSpacing-condensed":"cjUyb_bbUA","letterSpacing-expanded":"cjUyb_bRWU","transform-none":"cjUyb_wZsr","transform-capitalize":"cjUyb_fCZK","transform-uppercase":"cjUyb_dsRi","transform-lowercase":"cjUyb_bLtD"}
var U=(k=Object(g["a"])("7.0.0",null,"Use Text from ui-text instead."),j=Object(p["themeable"])(v,O),k(w=j(w=(B=x=function(e){Object(l["a"])(t,e)
function t(){Object(i["a"])(this,t)
return Object(r["a"])(this,Object(s["a"])(t).apply(this,arguments))}Object(a["a"])(t,[{key:"render",value:function(){var e
var n=this.props,i=n.wrap,a=n.weight,r=n.fontStyle,s=n.size,l=n.lineHeight,c=n.letterSpacing,u=n.transform,b=n.color,h=n.children
var p=Object(f["a"])(t,this.props)
return d.a.createElement(p,Object.assign({},Object(m["a"])(this.props,t.propTypes),{className:_()((e={},Object(o["a"])(e,O.root,true),Object(o["a"])(e,O[s],s),Object(o["a"])(e,O["wrap-".concat(i)],i),Object(o["a"])(e,O["weight-".concat(a)],a),Object(o["a"])(e,O["style-".concat(r)],r),Object(o["a"])(e,O["transform-".concat(u)],u),Object(o["a"])(e,O["lineHeight-".concat(l)],l),Object(o["a"])(e,O["letterSpacing-".concat(c)],c),Object(o["a"])(e,O["color-".concat(b)],b),e)),ref:this.props.elementRef}),h)}}])
t.displayName="Text"
return t}(c["Component"]),x.propTypes={as:b.a.elementType,wrap:b.a.oneOf(["normal","break-word"]),weight:b.a.oneOf(["normal","light","bold"]),fontStyle:b.a.oneOf(["italic","normal"]),size:b.a.oneOf(["x-small","small","medium","large","x-large","xx-large"]),lineHeight:b.a.oneOf(["default","fit","condensed","double"]),letterSpacing:b.a.oneOf(["normal","condensed","expanded"]),transform:b.a.oneOf(["none","capitalize","uppercase","lowercase"]),color:b.a.oneOf(["primary","secondary","primary-inverse","secondary-inverse","success","error","alert","warning","brand"]),children:b.a.node,elementRef:b.a.func},x.defaultProps={as:"span",wrap:"normal",size:"medium",letterSpacing:"normal",children:null,elementRef:void 0,color:void 0,transform:void 0,lineHeight:void 0,fontStyle:void 0,weight:void 0},B))||w)||w)},B1vq:function(e,t,n){"use strict"
var o=n("ouhR")
var i=n.n(o)
n("s/PJ")
i.a.fn.scrollToVisible=function(e){const t={}
const n=i()(e)
if(0===n.length)return
let o=n.offset(),a=n.outerWidth(),r=n.outerHeight(),s=o.top,l=s+r,c=o.left,d=c+a,u="html,body"==this.selector?i.a.windowScrollTop():this.scrollTop(),b=this.scrollLeft(),h=this.outerHeight(),_=this.outerWidth()
if("html,body"!=this.selector){let e=i()("body").offset()
this.each((function(){try{e=i()(this).offset()
return false}catch(e){}}))
s-=e.top
l-=e.top
c-=e.left
d-=e.left}if("HTML"==this[0].tagName||"BODY"==this[0].tagName){h=i()(window).height()
i()("#wizard_box:visible").length>0&&(h-=i()("#wizard_box:visible").height())
_=i()(window).width()
s-=u
c-=b
l-=u
d-=b}s<0||h<r&&l>h?t.scrollTop=s+u:l>h&&(t.scrollTop=l+u-h+20)
c<0?t.scrollLeft=c+b:d>_&&(t.scrollLeft=d+b-_+20)
1==t.scrollTop&&(t.scrollTop=0)
1==t.scrollLeft&&(t.scrollLeft=0)
this.scrollTop(t.scrollTop)
this.scrollLeft(t.scrollLeft)
return this}},BYL3:function(e,t,n){"use strict"
var o=n("ouhR")
var i=n.n(o)
var a=n("xe+K")
const r=/^(?:select|textarea)/i
const s=/\r?\n/g
const l=/^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week|file)$/i
function c(){if(this.elements)return i.a.makeArray(this.elements)
{const e=i()(this).find(":input")
return e.length?e:this}}function d(){return this.name&&!this.disabled&&(this.checked||r.test(this.nodeName)||l.test(this.type))}function u(e,t){"string"===typeof t&&(t=t.replace(s,"\r\n"))
return{name:e,value:t}}function b(){const e=i()(this)
const t=(()=>{if("file"!==this.type)return e.hasClass("datetime_field_enabled")?""===e.val()?null:e.data("date")||null:e.data("rich_text")?Object(a["d"])(e,"get_code",false):e.val()
if(e.val())return this})()
return i.a.isArray(t)?t.map(e=>u(this.name,e)):u(this.name,t)}i.a.fn.serializeForm=function(){return this.map(c).filter(d).map(b).get()}},"EvX+":function(e,t,n){"use strict"
var o=n("HIhM")
const i={}
const a={getCssVariant(){const e=window.ENV.use_responsive_layout?"responsive_layout":"new_styles"
const t=window.ENV.use_high_contrast?"high_contrast":"normal_contrast"
const n=Object(o["c"])()?"_rtl":""
return"".concat(e,"_").concat(t).concat(n)},urlFor(e,t){let n=t.combinedChecksum,o=t.includesNoVariables
const i=o?"no_variables":a.getCssVariant()
return[window.ENV.ASSET_HOST||"","dist","brandable_css",i,"".concat(e,"-").concat(n,".css")].join("/")},loadStylesheet(e,t){if(e in i)return
const n=document.createElement("link")
n.rel="stylesheet"
n.href=a.urlFor(e,t)
n.setAttribute("data-loaded-by-brandableCss",true)
document.head.appendChild(n)
window.canvasCssVariablesPolyfill&&window.canvasCssVariablesPolyfill(n)}}
t["a"]=a},HMVb:function(e,t,n){"use strict"
var o=n("ODXe")
var i=n("i/8D")
var a=n("DUTp")
var r=n("IPIv")
var s={}
function l(e,t){if(!i["a"])return 16
var n=e||Object(a["a"])(e).documentElement
if(!t&&s[n])return s[n]
var o=parseInt(Object(r["a"])(n).getPropertyValue("font-size"))
s[n]=o
return o}var c=n("CyAq")
n.d(t,"a",(function(){return d}))
function d(e,t){var n=t||document.body
if(!e||"number"===typeof e)return e
var i=Object(c["a"])(e),a=Object(o["a"])(i,2),r=a[0],s=a[1]
return"rem"===s?r*l():"em"===s?r*l(n):r}},HbFp:function(e,t,n){"use strict"
var o=n("qJBq")
var i=n.n(o)
var a=n("pQTu")
const r={_parseNumber:i.a,parse(e){if(null==e)return NaN
if("number"===typeof e)return e
let t=r._parseNumber(e.toString(),{thousands:a["default"].lookup("number.format.delimiter"),decimal:a["default"].lookup("number.format.separator")})
isNaN(t)&&(t=r._parseNumber(e))
e.toString().match(/e/)&&isNaN(t)&&(t=parseFloat(e))
return t},validate:e=>!isNaN(r.parse(e))}
t["a"]=r},JNmV:function(e,t,n){"use strict"
n.r(t)
var o=n("ouhR")
var i=n.n(o)
n("T3Mz")
const a=function(){const e=document.createEvent("Event")
e.initEvent("rubricEditDataReady",true,true)
document.dispatchEvent(e)}
i.a.isReady?a():i()(document).ready(()=>a())},TBRb:function(e,t,n){"use strict"
var o=n("ouhR")
var i=n.n(o)
var a=n("GLiE")
var r=n.n(a)
var s=n("Nxtp")
n("YGE8")
i.a.fn.fixDialogButtons=function(){return this.each((function(){const e=i()(this)
const t=e.find(".button-container:last .btn, button[type=submit]")
if(t.length){e.find(".button-container:last, button[type=submit]").hide()
let n=i.a.map(t.toArray(),t=>{const n=i()(t)
let o=n.attr("class")||""
const a=n.attr("id")
if(n.is(".dialog_closer")){n.off(".fixdialogbuttons")
n.on("click.fixdialogbuttons",Object(s["a"])(()=>e.dialog("close")))}"submit"===n.prop("type")&&n[0].form&&(o+=" button_type_submit")
return{text:n.text(),"data-text-while-loading":n.data("textWhileLoading"),click:()=>n.click(),class:o,id:a}})
n=r.a.sortBy(n,e=>e.class.match(/btn-primary/)?1:0)
e.dialog("option","buttons",n)}}))}},WEeK:function(e,t,n){"use strict"
var o=n("rePB")
var i=n("Ff2n")
var a=n("1OyB")
var r=n("vuIU")
var s=n("md7G")
var l=n("foSv")
var c=n("Ji7U")
var d=n("q1tI")
var u=n.n(d)
var b=n("17x9")
var h=n.n(b)
var _=n("TSYQ")
var p=n.n(_)
var g=n("cClk")
var f=n("nAyT")
var m=n("jtGx")
var y=n("E+IV")
var v=n("tCl5")
var k=n("/UXv")
var j=n("sTNg")
var w=n("TstA")
var x=n("BTe1")
var B=n("J2CL")
function O(e){var t=e.colors,n=e.typography,o=e.borders,i=e.spacing,a=e.forms
return{fontFamily:n.fontFamily,fontWeight:n.fontWeightNormal,borderWidth:o.widthSmall,borderStyle:o.style,borderColor:t.borderMedium,borderRadius:o.radiusMedium,color:t.textDarkest,background:t.backgroundLightest,padding:i.small,focusOutlineWidth:o.widthMedium,focusOutlineStyle:o.style,focusOutlineColor:t.borderBrand,errorBorderColor:t.borderDanger,errorOutlineColor:t.borderDanger,placeholderColor:t.textDark,smallFontSize:n.fontSizeSmall,smallHeight:a.inputHeightSmall,mediumFontSize:n.fontSizeMedium,mediumHeight:a.inputHeightMedium,largeFontSize:n.fontSizeLarge,largeHeight:a.inputHeightLarge}}O.canvas=function(e){return{color:e["ic-brand-font-color-dark"],focusOutlineColor:e["ic-brand-primary"]}}
n.d(t,"a",(function(){return A}))
var U,z,S,C,q
var F={componentId:"qBMHb",template:function(e){return"\n\n.qBMHb_cSXm{background:".concat(e.background||"inherit",";border:").concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";border-radius:").concat(e.borderRadius||"inherit",";position:relative}\n\n.qBMHb_cSXm,.qBMHb_cSXm:before{box-sizing:border-box;display:block}\n\n.qBMHb_cSXm:before{border:").concat(e.focusOutlineWidth||"inherit"," ").concat(e.focusOutlineStyle||"inherit"," ").concat(e.focusOutlineColor||"inherit",";border-radius:calc(").concat(e.borderRadius||"inherit",'*1.5);bottom:-0.25rem;content:"";left:-0.25rem;opacity:0;pointer-events:none;position:absolute;right:-0.25rem;top:-0.25rem;transform:scale(0.95);transition:all 0.2s}\n\n.qBMHb_cSXm.qBMHb_cVYB:before{opacity:1;transform:scale(1)}\n\n.qBMHb_cSXm.qBMHb_ywdX{cursor:not-allowed;opacity:0.5;pointer-events:none}\n\n.qBMHb_cSXm.qBMHb_fszt,.qBMHb_cSXm.qBMHb_fszt.qBMHb_cVYB:before{border-color:').concat(e.errorBorderColor||"inherit","}\n\n.qBMHb_cwos,input[type].qBMHb_cwos{-moz-appearance:none;-moz-osx-font-smoothing:grayscale;-webkit-appearance:none;-webkit-font-smoothing:antialiased;all:initial;animation:none 0s ease 0s 1 normal none running;appearance:none;backface-visibility:visible;background:transparent none repeat 0 0/auto auto padding-box border-box scroll;background:transparent;border:medium none currentColor;border:none;border-collapse:separate;border-image:none;border-radius:0;border-spacing:0;bottom:auto;box-shadow:none;box-sizing:content-box;box-sizing:border-box;caption-side:top;clear:none;clip:auto;color:#000;color:").concat(e.color||"inherit",";column-count:auto;column-fill:balance;column-gap:normal;column-rule:medium none currentColor;column-span:1;column-width:auto;columns:auto;content:normal;counter-increment:none;counter-reset:none;cursor:auto;direction:ltr;display:inline;display:block;empty-cells:show;float:none;font-family:serif;font-family:").concat(e.fontFamily||"inherit",";font-size:medium;font-stretch:normal;font-style:normal;font-variant:normal;font-weight:400;font-weight:").concat(e.fontWeight||"inherit",";height:auto;hyphens:none;left:auto;letter-spacing:normal;line-height:normal;list-style:disc outside none;margin:0;max-height:none;max-width:none;min-height:0;min-width:0;opacity:1;orphans:2;outline:medium none invert;outline:none;overflow:visible;overflow-x:visible;overflow-y:visible;padding:0;padding:0 ").concat(e.padding||"inherit",";page-break-after:auto;page-break-before:auto;page-break-inside:auto;perspective:none;perspective-origin:50% 50%;position:static;right:auto;tab-size:8;table-layout:auto;text-align:left;text-align-last:auto;text-decoration:none;text-indent:0;text-shadow:none;text-transform:none;top:auto;transform:none;transform-origin:50% 50% 0;transform-style:flat;transition:none 0s ease 0s;unicode-bidi:normal;vertical-align:baseline;visibility:visible;white-space:normal;widows:2;width:auto;width:100%;word-spacing:normal;z-index:auto}\n\n.qBMHb_cwos::-ms-clear,input[type].qBMHb_cwos::-ms-clear{display:none}\n\n.qBMHb_cwos[autocomplete=off]::-webkit-contacts-auto-fill-button,input[type].qBMHb_cwos[autocomplete=off]::-webkit-contacts-auto-fill-button{display:none!important}\n\n.qBMHb_cwos:focus,input[type].qBMHb_cwos:focus{box-shadow:none}\n\n.qBMHb_cwos:-ms-input-placeholder,input[type].qBMHb_cwos:-ms-input-placeholder{color:").concat(e.placeholderColor||"inherit","}\n\n.qBMHb_cwos::-ms-input-placeholder,input[type].qBMHb_cwos::-ms-input-placeholder{color:").concat(e.placeholderColor||"inherit","}\n\n.qBMHb_cwos::placeholder,input[type].qBMHb_cwos::placeholder{color:").concat(e.placeholderColor||"inherit","}\n\n.qBMHb_cwos.qBMHb_doqw,input[type].qBMHb_cwos.qBMHb_doqw{font-size:").concat(e.smallFontSize||"inherit",";height:calc(").concat(e.smallHeight||"inherit"," - 2*").concat(e.borderWidth||"inherit",");line-height:calc(").concat(e.smallHeight||"inherit"," - 2*").concat(e.borderWidth||"inherit",")}\n\n.qBMHb_cwos.qBMHb_ycrn,input[type].qBMHb_cwos.qBMHb_ycrn{font-size:").concat(e.mediumFontSize||"inherit",";height:calc(").concat(e.mediumHeight||"inherit"," - 2*").concat(e.borderWidth||"inherit",");line-height:calc(").concat(e.mediumHeight||"inherit"," - 2*").concat(e.borderWidth||"inherit",")}\n\n.qBMHb_cwos.qBMHb_cMDj,input[type].qBMHb_cwos.qBMHb_cMDj{font-size:").concat(e.largeFontSize||"inherit",";height:calc(").concat(e.largeHeight||"inherit"," - 2*").concat(e.borderWidth||"inherit",");line-height:calc(").concat(e.largeHeight||"inherit"," - 2*").concat(e.borderWidth||"inherit",")}\n\n.qBMHb_cwos.qBMHb_EMjX,input[type].qBMHb_cwos.qBMHb_EMjX{text-align:start}\n\n[dir=ltr] .qBMHb_cwos.qBMHb_EMjX,[dir=ltr] input[type].qBMHb_cwos.qBMHb_EMjX{text-align:left}\n\n[dir=rtl] .qBMHb_cwos.qBMHb_EMjX,[dir=rtl] input[type].qBMHb_cwos.qBMHb_EMjX{text-align:right}\n\n.qBMHb_cwos.qBMHb_ImeN,[dir=ltr] .qBMHb_cwos.qBMHb_ImeN,[dir=ltr] input[type].qBMHb_cwos.qBMHb_ImeN,[dir=rtl] .qBMHb_cwos.qBMHb_ImeN,[dir=rtl] input[type].qBMHb_cwos.qBMHb_ImeN,input[type].qBMHb_cwos.qBMHb_ImeN{text-align:center}")},facade:"qBMHb_cSXm",focused:"qBMHb_cVYB",disabled:"qBMHb_ywdX",invalid:"qBMHb_fszt",input:"qBMHb_cwos",small:"qBMHb_doqw",medium:"qBMHb_ycrn",large:"qBMHb_cMDj","textAlign--start":"qBMHb_EMjX","textAlign--center":"qBMHb_ImeN"}
var A=(U=Object(f["a"])("7.0.0",{label:"renderLabel",required:"isRequired",inline:"display"}),z=Object(B["themeable"])(O,F),U(S=z(S=(q=C=function(e){Object(c["a"])(t,e)
function t(e){var n
Object(a["a"])(this,t)
n=Object(s["a"])(this,Object(l["a"])(t).call(this))
n.handleInputRef=function(e){n._input=e
n.props.inputRef(e)}
n.handleChange=function(e){n.props.onChange(e,e.target.value)}
n.handleBlur=function(e){n.props.onBlur(e)
n.setState({hasFocus:false})}
n.handleFocus=function(e){n.props.onFocus(e)
n.setState({hasFocus:true})}
n.state={hasFocus:false}
n._defaultId=Object(x["a"])("TextInput")
n._messagesId=Object(x["a"])("TextInput-messages")
return n}Object(r["a"])(t,[{key:"focus",value:function(){this._input.focus()}},{key:"renderInput",value:function(){var e
var t=this.props,n=t.type,a=t.size,r=t.htmlSize,s=(t.display,t.textAlign),l=t.placeholder,c=t.value,d=t.defaultValue,b=t.required,h=t.isRequired,_=Object(i["a"])(t,["type","size","htmlSize","display","textAlign","placeholder","value","defaultValue","required","isRequired"])
var g=Object(m["b"])(_)
var f=this.interaction
var y=(e={},Object(o["a"])(e,F.input,true),Object(o["a"])(e,F[a],a),Object(o["a"])(e,F["textAlign--".concat(s)],s),e)
var v=""
g["aria-describedby"]&&(v="".concat(g["aria-describedby"]))
this.hasMessages&&(v=""!==v?"".concat(v," ").concat(this._messagesId):this._messagesId)
return u.a.createElement("input",Object.assign({},g,{className:p()(y),defaultValue:d,value:c,placeholder:l,ref:this.handleInputRef,type:n,id:this.id,required:h||b,"aria-invalid":this.invalid?"true":null,disabled:"disabled"===f,readOnly:"readonly"===f,"aria-describedby":""!==v?v:null,size:r,onChange:this.handleChange,onBlur:this.handleBlur,onFocus:this.handleFocus}))}},{key:"render",value:function(){var e
var t=this.props,n=t.width,i=t.inline,a=t.display,r=t.label,s=t.renderLabel,l=t.renderBeforeInput,c=t.renderAfterInput,d=t.messages,b=t.inputContainerRef,h=t.icon,_=t.shouldNotWrap
var g=this.interaction
var f=l||c||h
var m=(e={},Object(o["a"])(e,F.facade,true),Object(o["a"])(e,F.disabled,"disabled"===g),Object(o["a"])(e,F.invalid,this.invalid),Object(o["a"])(e,F.focused,this.state.hasFocus),e)
return u.a.createElement(j["FormField"],{id:this.id,label:Object(y["a"])(s||r),messagesId:this._messagesId,messages:d,inline:"inline-block"===a||i,width:n,inputContainerRef:b,layout:this.props.layout},u.a.createElement("span",{className:p()(m)},f?u.a.createElement(w["a"],{wrap:_?"no-wrap":"wrap"},l&&u.a.createElement(w["a"].Item,{padding:"0 0 0 small"},Object(y["a"])(l)),u.a.createElement(w["a"].Item,{shouldGrow:true,shouldShrink:true},u.a.createElement(w["a"],{__dangerouslyIgnoreExperimentalWarnings:true},u.a.createElement(w["a"].Item,{shouldGrow:true,shouldShrink:true},this.renderInput()),(c||h)&&u.a.createElement(w["a"].Item,{padding:"0 small 0 0"},c?Object(y["a"])(c):Object(y["a"])(h))))):this.renderInput()))}},{key:"interaction",get:function(){return Object(v["a"])({props:this.props})}},{key:"hasMessages",get:function(){return this.props.messages&&this.props.messages.length>0}},{key:"invalid",get:function(){return this.props.messages&&this.props.messages.findIndex((function(e){return"error"===e.type}))>=0}},{key:"focused",get:function(){return Object(k["a"])(this._input)}},{key:"value",get:function(){return this._input.value}},{key:"id",get:function(){return this.props.id||this._defaultId}}])
t.displayName="TextInput"
return t}(d["Component"]),C.propTypes={renderLabel:h.a.oneOfType([h.a.node,h.a.func]),type:h.a.oneOf(["text","email","url","tel","search","password"]),id:h.a.string,value:Object(g["a"])(h.a.string),defaultValue:h.a.string,interaction:h.a.oneOf(["enabled","disabled","readonly"]),messages:h.a.arrayOf(j["FormPropTypes"].message),size:h.a.oneOf(["small","medium","large"]),textAlign:h.a.oneOf(["start","center"]),width:h.a.string,htmlSize:h.a.oneOfType([h.a.string,h.a.number]),display:h.a.oneOf(["inline-block","block"]),shouldNotWrap:h.a.bool,placeholder:h.a.string,isRequired:h.a.bool,inputRef:h.a.func,inputContainerRef:h.a.func,renderBeforeInput:h.a.oneOfType([h.a.node,h.a.func]),renderAfterInput:h.a.oneOfType([h.a.node,h.a.func]),onChange:h.a.func,onBlur:h.a.func,onFocus:h.a.func,icon:h.a.func,label:h.a.oneOfType([h.a.node,h.a.func]),required:h.a.bool,inline:h.a.bool},C.defaultProps={renderLabel:void 0,type:"text",id:void 0,interaction:void 0,isRequired:false,value:void 0,defaultValue:void 0,display:"block",shouldNotWrap:false,placeholder:void 0,width:void 0,size:"medium",htmlSize:void 0,textAlign:"start",messages:[],inputRef:function(e){},inputContainerRef:function(e){},onChange:function(e,t){},onBlur:function(e){},onFocus:function(e){},renderBeforeInput:void 0,renderAfterInput:void 0},q))||S)||S)},cClk:function(e,t,n){"use strict"
n.d(t,"a",(function(){return o}))
function o(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"onChange"
var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"defaultValue"
return function(o,i,a){var r=e.apply(null,arguments)
if(r)return r
if(o[i]&&"function"!==typeof o[t])return new Error(["You provided a '".concat(i,"' prop without an '").concat(t,"' handler on '").concat(a,"'. This will render a controlled component. If the component should be uncontrolled and manage its own state, use '").concat(n,"'. Otherwise, set '").concat(t,"'.")].join(""))}}},cbNQ:function(e,t,n){"use strict"
n.d(t,"a",(function(){return i}))
n.d(t,"b",(function(){return a}))
const o={}.hasOwnProperty
function i(e,t){for(const n in t)o.call(t,n)&&(e[n]=t[n])
function n(){this.constructor=e}n.prototype=t.prototype
e.prototype=new n
e.__super__=t.prototype
return e}function a(e,t){Object.keys(t).forEach(n=>Object.defineProperty(e,n,{get:t[n],enumerable:true,configurable:true}))
return e}},dTie:function(e,t,n){"use strict"
var o=n("An8g")
var i=n("Ff2n")
var a=n("q1tI")
var r=n.n(a)
n("17x9")
var s=n("Mmr1")
var l=n("msMH")
var c=n("pQTu")
var d=n("m0r6")
Object(d["a"])(JSON.parse('{"ar":{"close_d634289d":"إغلاق"},"cy":{"close_d634289d":"Cau"},"da":{"close_d634289d":"Luk"},"da-x-k12":{"close_d634289d":"Luk"},"de":{"close_d634289d":"Schließen"},"el":{"close_d634289d":"Κλείσιμο"},"en-AU":{"close_d634289d":"Close"},"en-CA":{"close_d634289d":"Close"},"en-GB":{"close_d634289d":"Close"},"es":{"close_d634289d":"Cerrar"},"fa":{"close_d634289d":"بستن"},"fi":{"close_d634289d":"Sulje"},"fr":{"close_d634289d":"Fermer"},"fr-CA":{"close_d634289d":"Fermer"},"he":{"close_d634289d":"סגירה"},"ht":{"close_d634289d":"Fèmen"},"hu":{"close_d634289d":"Bezárás"},"hy":{"close_d634289d":"Փակել"},"is":{"close_d634289d":"Loka"},"it":{"close_d634289d":"Chiudi"},"ja":{"close_d634289d":"閉じる"},"ko":{"close_d634289d":"닫기"},"mi":{"close_d634289d":"Katia"},"nb":{"close_d634289d":"Lukk"},"nb-x-k12":{"close_d634289d":"Lukk"},"nl":{"close_d634289d":"Sluiten"},"nn":{"close_d634289d":"Lukk"},"pl":{"close_d634289d":"Zamknij"},"pt":{"close_d634289d":"Fechar"},"pt-BR":{"close_d634289d":"Fechar"},"ru":{"close_d634289d":"Закрыть"},"sl":{"close_d634289d":"Zapri"},"sv":{"close_d634289d":"Stäng"},"sv-x-k12":{"close_d634289d":"Stäng"},"tr":{"close_d634289d":"Kapat"},"uk":{"close_d634289d":"Закрити"},"zh-Hans":{"close_d634289d":"关闭"},"zh-Hant":{"close_d634289d":"關閉"}}'))
n("jQeR")
n("0sPK")
var u=c["default"].scoped("modal")
var b=n("98st")
n.d(t,"a",(function(){return _}))
function h(){return document.getElementById("flash_screenreader_holder")}function _(e){let t=e.label,n=e.closeButtonLabel,a=e.onDismiss,c=e.children,d=Object(i["a"])(e,["label","closeButtonLabel","onDismiss","children"])
return r.a.createElement(b["a"],Object.assign({liveRegion:h},d,{label:t,onDismiss:a}),Object(o["a"])(b["a"].Header,{},void 0,Object(o["a"])(s["a"],{"data-testid":"instui-modal-close",placement:"end",offset:"medium",onClick:a},void 0,n||u.t("Close")),Object(o["a"])(l["a"],{},void 0,t)),c)}["Header","Body","Footer"].forEach(e=>_[e]=b["a"][e])
_.defaultProps={closeButtonLabel:void 0}},eGSd:function(e,t,n){"use strict"
n.d(t,"a",(function(){return o}))
function o(e){var t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:0
var n=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{}
var o,i,a,r
var s=0
var l=[]
var c=false
if("function"!==typeof e)throw new TypeError("Expected a function")
var d=!!n.leading
var u="maxWait"in n
var b=!("trailing"in n)||!!n.trailing
var h=u?Math.max(+n.maxWait||0,t):0
function _(t){var n=o
var r=i
o=i=void 0
s=t
if(true!==c){a=e.apply(r,n)
return a}}function p(e){s=e
l.push(setTimeout(m,t))
return d?_(e):a}function g(e){var n=e-r
var o=e-s
var i=t-n
return u?Math.min(i,h-o):i}function f(e){var n=e-r
var o=e-s
return"undefined"===typeof r||n>=t||n<0||u&&o>=h}function m(){var e=Date.now()
if(f(e))return y(e)
l.push(setTimeout(m,g(e)))}function y(e){j()
if(b&&o)return _(e)
o=i=void 0
return a}function v(){c=true
j()
s=0
o=r=i=void 0}function k(){return 0===l.length?a:y(Date.now())}function j(){l.forEach((function(e){return clearTimeout(e)}))
l=[]}function w(){var e=Date.now()
var n=f(e)
for(var s=arguments.length,c=new Array(s),d=0;d<s;d++)c[d]=arguments[d]
o=c
i=this
r=e
if(n){if(0===l.length)return p(r)
if(u){l.push(setTimeout(m,t))
return _(r)}}0===l.length&&l.push(setTimeout(m,t))
return a}w.cancel=v
w.flush=k
return w}},fQ4S:function(e,t,n){"use strict"
var o=n("ouhR")
var i=n.n(o)
var a=n("GLiE")
var r=n.n(a)
var s=n("5Ky4")
n("tVj+")
n("vpJZ")
n("Z+Ib")
n("JI1W")
t["a"]={fieldSelectors:null,findSiblingTinymce:function(e){return e.siblings(".mce-tinymce").find(".mce-edit-area")},findField:function(e,t){var n,o,a
null==t&&(t=false)
a=(null!=(o=this.fieldSelectors)?o[e]:void 0)||"[name='"+e+"']"
n=t?i()(a):this.$(a)
n.data("rich_text")&&(n=this.findSiblingTinymce(n))
return n},showErrors:function(e,t){var n,o,a,r,l,c,d,u
null==t&&(t=false)
u=[]
for(a in e){o=e[a]
n=o.element||this.findField(a,t)
r=o.message||function(){var e,t,n,i
i=[]
for(e=0,t=o.length;e<t;e++){l=o[e].message
i.push(Object(s["a"])((null!=(n=this.translations)?n[l]:void 0)||l))}return i}.call(this).join("</p><p>")
null!=(c=n.errorBox(i.a.raw(""+r)))&&null!=(d=c.css("z-index","1100"))&&d.attr("role","alert")
this.attachErrorDescription(n,r)
o.$input=n
u.push(o.$errorBox=n.data("associated_error_box"))}return u},attachErrorDescription:function(e,t){var n
n=this.findOrCreateDescriptionField(e)
n["description"].text(i.a.raw(""+t))
return e.attr("aria-describedby",n["description"].attr("id")+" "+n["originalDescriptionIds"])},findOrCreateDescriptionField:function(e){var t,n,o
n=e.attr("id")
i()("#"+n+"_sr_description").length>0||i()("<div>").attr({id:n+"_sr_description",class:"screenreader-only"}).insertBefore(e)
t=i()("#"+n+"_sr_description")
o=this.getExistingDescriptionIds(e,n)
return{description:t,originalDescriptionIds:o}},getExistingDescriptionIds:function(e,t){var n,o
n=e.attr("aria-describedby")
o=n?n.split(" "):[]
return r.a.without(o,t+"_sr_description")}}},gCYW:function(e,t,n){"use strict"
n.d(t,"a",(function(){return s}))
var o=n("QF4Q")
var i=n("i/8D")
var a=n("EgqM")
var r=n("DUTp")
function s(e){var t={top:0,left:0,height:0,width:0}
if(!i["a"])return t
var n=Object(o["a"])(e)
if(!n)return t
if(n===window)return{left:window.pageXOffset,top:window.pageYOffset,width:window.innerWidth,height:window.innerHeight,right:window.innerWidth+window.pageXOffset,bottom:window.innerHeight+window.pageYOffset}
var l=e===document?document:Object(r["a"])(n)
var c=l&&l.documentElement
if(!c||!Object(a["a"])(c,n))return t
var d=n.getBoundingClientRect()
var u
for(u in d)t[u]=d[u]
if(l!==document){var b=l.defaultView.frameElement
if(b){var h=s(b)
t.top+=h.top
t.bottom+=h.top
t.left+=h.left
t.right+=h.left}}return{top:t.top+(window.pageYOffset||c.scrollTop)-(c.clientTop||0),left:t.left+(window.pageXOffset||c.scrollLeft)-(c.clientLeft||0),width:(null==t.width?n.offsetWidth:t.width)||0,height:(null==t.height?n.offsetHeight:t.height)||0,right:l.body.clientWidth-t.width-t.left,bottom:l.body.clientHeight-t.height-t.top}}},msMH:function(e,t,n){"use strict"
var o=n("rePB")
var i=n("Ff2n")
var a=n("1OyB")
var r=n("vuIU")
var s=n("md7G")
var l=n("foSv")
var c=n("Ji7U")
var d=n("q1tI")
var u=n.n(d)
var b=n("17x9")
var h=n.n(b)
var _=n("TSYQ")
var p=n.n(_)
var g=n("n12J")
var f=n("J2CL")
var m=n("RhCJ")
var y=n("nAyT")
var v=n("KgFQ")
var k=n("jtGx")
var j=n("oXx0")
function w(e){var t=e.borders,n=e.colors,o=e.spacing,i=e.typography
return{lineHeight:i.lineHeightFit,h1FontSize:i.fontSizeXXLarge,h1FontWeight:i.fontWeightLight,h1FontFamily:i.fontFamily,h2FontSize:i.fontSizeXLarge,h2FontWeight:i.fontWeightNormal,h2FontFamily:i.fontFamily,h3FontSize:i.fontSizeLarge,h3FontWeight:i.fontWeightBold,h3FontFamily:i.fontFamily,h4FontSize:i.fontSizeMedium,h4FontWeight:i.fontWeightBold,h4FontFamily:i.fontFamily,h5FontSize:i.fontSizeSmall,h5FontWeight:i.fontWeightNormal,h5FontFamily:i.fontFamily,primaryInverseColor:n.textLightest,primaryColor:n.textDarkest,secondaryColor:n.textDark,secondaryInverseColor:n.textLight,borderPadding:o.xxxSmall,borderColor:n.borderMedium,borderWidth:t.widthSmall,borderStyle:t.style}}w.canvas=function(e){return{primaryColor:e["ic-brand-font-color-dark"]}}
w["instructure"]=function(e){var t=e.typography
return{h1FontFamily:t.fontFamilyHeading,h2FontFamily:t.fontFamilyHeading,h3FontWeight:t.fontWeightBold,h3FontSize:"2.125rem",h4FontWeight:t.fontWeightBold,h4FontSize:t.fontSizeLarge,h5FontWeight:t.fontWeightBold,h5FontSize:t.fontSizeMedium}}
var x={fontFamily:["h1FontFamily","h2FontFamily","h3FontFamily","h4FontFamily","h5FontFamily"]}
var B=Object(f["createThemeAdapter"])({map:x,version:"8.0.0"})
n.d(t,"a",(function(){return A}))
var O,U,z,S,C,q
var F={componentId:"blnAQ",template:function(e){return"\n\n.blnAQ_bGBk{line-height:".concat(e.lineHeight||"inherit",";margin:0}\n\ninput.blnAQ_bGBk[type]{-moz-appearance:none;-webkit-appearance:none;appearance:none;background:none;border:none;border-radius:0;box-shadow:none;box-sizing:border-box;color:inherit;display:block;height:auto;line-height:inherit;margin:-0.375rem 0 0 0;outline:0;padding:0;text-align:start;width:100%}\n\n[dir=ltr] input.blnAQ_bGBk[type]{text-align:left}\n\n[dir=rtl] input.blnAQ_bGBk[type]{text-align:right}\n\ninput.blnAQ_bGBk[type]:focus{outline:none}\n\n.blnAQ_fCtg{font-family:").concat(e.h1FontFamily||"inherit",";font-size:").concat(e.h1FontSize||"inherit",";font-weight:").concat(e.h1FontWeight||"inherit","}\n\n.blnAQ_cVrl{font-family:").concat(e.h2FontFamily||"inherit",";font-size:").concat(e.h2FontSize||"inherit",";font-weight:").concat(e.h2FontWeight||"inherit","}\n\n.blnAQ_dnfM{font-family:").concat(e.h3FontFamily||"inherit",";font-size:").concat(e.h3FontSize||"inherit",";font-weight:").concat(e.h3FontWeight||"inherit","}\n\n.blnAQ_KGwv{font-family:").concat(e.h4FontFamily||"inherit",";font-size:").concat(e.h4FontSize||"inherit",";font-weight:").concat(e.h4FontWeight||"inherit","}\n\n.blnAQ_eYKA{font-family:").concat(e.h5FontFamily||"inherit",";font-size:").concat(e.h5FontSize||"inherit",";font-weight:").concat(e.h5FontWeight||"inherit","}\n\n.blnAQ_dbSc{font-size:inherit;font-weight:inherit;line-height:inherit;margin:0}\n\n.blnAQ_bACI{border-top:").concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";padding-top:").concat(e.borderPadding||"inherit","}\n\n.blnAQ_kWwi{border-bottom:").concat(e.borderWidth||"inherit"," ").concat(e.borderStyle||"inherit"," ").concat(e.borderColor||"inherit",";padding-bottom:").concat(e.borderPadding||"inherit","}\n\n.blnAQ_drOs{color:inherit}\n\n.blnAQ_eCSh{color:").concat(e.primaryColor||"inherit","}\n\n.blnAQ_buuG{color:").concat(e.secondaryColor||"inherit","}\n\n.blnAQ_bFtJ{color:").concat(e.primaryInverseColor||"inherit","}\n\n.blnAQ_dsSB{color:").concat(e.secondaryInverseColor||"inherit","}\n\n.blnAQ_bOQC{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}")},root:"blnAQ_bGBk","level--h1":"blnAQ_fCtg","level--h2":"blnAQ_cVrl","level--h3":"blnAQ_dnfM","level--h4":"blnAQ_KGwv","level--h5":"blnAQ_eYKA","level--reset":"blnAQ_dbSc","border--top":"blnAQ_bACI","border--bottom":"blnAQ_kWwi","color--inherit":"blnAQ_drOs","color--primary":"blnAQ_eCSh","color--secondary":"blnAQ_buuG","color--primary-inverse":"blnAQ_bFtJ","color--secondary-inverse":"blnAQ_dsSB",ellipsis:"blnAQ_bOQC"}
var A=(O=Object(y["a"])("8.0.0",{ellipsis:"<TruncateText />"}),U=Object(j["a"])(),z=Object(f["themeable"])(w,F,B),O(S=U(S=z(S=(q=C=function(e){Object(c["a"])(t,e)
function t(){Object(a["a"])(this,t)
return Object(s["a"])(this,Object(l["a"])(t).apply(this,arguments))}Object(r["a"])(t,[{key:"render",value:function(){var e
var n=this.props,a=n.border,r=n.children,s=n.color,l=n.level,c=n.margin,d=n.elementRef,b=n.ellipsis,h=Object(i["a"])(n,["border","children","color","level","margin","elementRef","ellipsis"])
var _=Object(v["a"])(t,this.props,(function(){return"reset"===l?"span":l}))
return u.a.createElement(g["a"],Object.assign({},Object(k["b"])(h),{className:p()((e={},Object(o["a"])(e,F.root,true),Object(o["a"])(e,F["level--".concat(l)],true),Object(o["a"])(e,F["color--".concat(s)],s),Object(o["a"])(e,F["border--".concat(a)],"none"!==a),Object(o["a"])(e,F.ellipsis,b),e)),as:_,margin:c,elementRef:d}),r)}}])
t.displayName="Heading"
return t}(d["Component"]),C.propTypes={border:h.a.oneOf(["none","top","bottom"]),children:m["a"],color:h.a.oneOf(["primary","secondary","primary-inverse","secondary-inverse","inherit"]),level:h.a.oneOf(["h1","h2","h3","h4","h5","reset"]),as:h.a.elementType,margin:f["ThemeablePropTypes"].spacing,elementRef:h.a.func,ellipsis:h.a.bool},C.defaultProps={children:null,margin:void 0,elementRef:void 0,border:"none",color:"inherit",level:"h2"},q))||S)||S)||S)},mykf:function(e,t,n){"use strict"
const o=()=>{const e=ENV.LTI_LAUNCH_FRAME_ALLOWANCES||[]
return e.join("; ")}
t["a"]=o},p6Wi:function(e,t,n){"use strict"
var o=n("pQTu")
var i=n("m0r6")
Object(i["a"])(JSON.parse('{"ar":{"buttons":{"cancel":"إلغاء","delete":"حذف"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"هل ترغب بالتأكيد في حذف هذا؟"}}},"cy":{"buttons":{"cancel":"Canslo","delete":"Dileu"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Ydych chi’n siŵr eich bod am ddileu hyn?"}}},"da":{"buttons":{"cancel":"Annuller","delete":"Slet"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Er du sikker på, at du vil slette dette?"}}},"da-x-k12":{"buttons":{"cancel":"Annuller","delete":"Slet"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Er du sikker på, at du vil slette dette?"}}},"de":{"buttons":{"cancel":"Abbrechen","delete":"Löschen"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Möchten Sie dies wirklich löschen?"}}},"el":{"buttons":{"cancel":"Ακύρωση","delete":"Διαγραφή"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Είστε σίγουρος/η ότι επιθυμείτε να το διαγράψετε;"}}},"en-AU":{"buttons":{"cancel":"Cancel","delete":"Delete"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Are you sure you want to delete this?"}}},"en-CA":{"buttons":{"cancel":"Cancel","delete":"Delete"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Are you sure you want to delete this?"}}},"en-GB":{"buttons":{"cancel":"Cancel","delete":"Delete"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Are you sure you want to delete this?"}}},"es":{"buttons":{"cancel":"Cancelar","delete":"Eliminar"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"¿Seguro que desea eliminarlo?"}}},"fa":{"buttons":{"cancel":"لغو","delete":"حذف"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"مطمئنید که می خواهید این مورد حذف شود؟"}}},"fi":{"buttons":{"cancel":"Peruuta","delete":"Poista"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Haluatko varmasti poistaa tämän?"}}},"fr":{"buttons":{"cancel":"Annuler","delete":"Supprimer"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Voulez-vous vraiment supprimer cet élément ?"}}},"fr-CA":{"buttons":{"cancel":"Annuler","delete":"Supprimer"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Voulez-vous vraiment supprimer cet élément?"}}},"he":{"buttons":{"cancel":"ביטול","delete":"ביטול"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"בטוח/ה שרוצה לבטל זאת?"}}},"ht":{"buttons":{"cancel":"Anile","delete":"Efase"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Ou kwè vrèman ou vle efase sa a?"}}},"hu":{"buttons":{"cancel":"Mégse","delete":"Törlés"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Biztos benne, hogy törli ezt?"}}},"hy":{"buttons":{"cancel":"Չեղյալ համարել","delete":"Ջնջել"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Դուք իսկապե՞ս ցանկանում եք ջնջել սա:"}}},"is":{"buttons":{"cancel":"Hætta við","delete":"Eyða"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Viltu örugglega eyða þessu?"}}},"it":{"buttons":{"cancel":"Annulla","delete":"Elimina"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Vuoi eliminare questo?"}}},"ja":{"buttons":{"cancel":"キャンセル","delete":"削除"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"これを削除してもよろしいですか?"}}},"ko":{"buttons":{"cancel":"취소","delete":"삭제"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"삭제하시겠습니까?"}}},"mi":{"buttons":{"cancel":"Whakakore","delete":"Muku"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"E tino hiahia ana koe ki te muku i tēnei?"}}},"nb":{"buttons":{"cancel":"Avbryt","delete":"Slett"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Er du sikker på at du ønsker å slette dette?"}}},"nb-x-k12":{"buttons":{"cancel":"Avbryt","delete":"Slett"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Er du sikker på at du ønsker å slette dette?"}}},"nl":{"buttons":{"cancel":"Annuleren","delete":"Verwijderen"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Weet je zeker dat je dit wilt verwijderen?"}}},"nn":{"buttons":{"cancel":"Avbryt","delete":"Slett"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Er du sikker på at du vil slette dette?"}}},"pl":{"buttons":{"cancel":"Anuluj","delete":"Usuń"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Czy na pewno chcesz usunąć ten element?"}}},"pt":{"buttons":{"cancel":"Cancelar","delete":"Excluir"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Tem certeza de que deseja excluir isto?"}}},"pt-BR":{"buttons":{"cancel":"Cancelar","delete":"Excluir"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Tem certeza que deseja excluir isto?"}}},"ru":{"buttons":{"cancel":"Отменить","delete":"Удалить"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Действительно хотите удалить?"}}},"sl":{"buttons":{"cancel":"Prekliči","delete":"Odstrani"}},"sv":{"buttons":{"cancel":"Avbryt","delete":"Ta bort"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Vill du verkligen radera det här?"}}},"sv-x-k12":{"buttons":{"cancel":"Avbryt","delete":"Ta bort"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Vill du verkligen radera det här?"}}},"tr":{"buttons":{"cancel":"İptal","delete":"Sil"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"Bunu silmek istediğinize emin misiniz?"}}},"uk":{"buttons":{"cancel":"Скасувати","delete":"Видалити"}},"zh-Hans":{"buttons":{"cancel":"取消","delete":"删除"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"是否确定要删除它?"}}},"zh-Hant":{"buttons":{"cancel":"取消","delete":"刪除"},"instructure_misc_plugins":{"confirms":{"default_delete_thing":"您是否確定要刪除？"}}}}'))
n("jQeR")
n("0sPK")
var a=o["default"].scoped("instructure_misc_plugins")
var r=n("ouhR")
var s=n.n(r)
var l=n("5Ky4")
var c=n("JD5e")
n("jYyc")
n("YGE8")
n("B1vq")
n("s/PJ")
s.a.fn.setOptions=function(e,t){let n=e?"<option value=''>"+Object(l["a"])(e)+"</option>":""
null==t&&(t=[])
t.forEach(e=>{const t=Object(l["a"])(e)
n+='<option value="'+t+'">'+t+"</option>"})
return this.html(s.a.raw(n))}
s.a.fn.ifExists=function(e){this.length&&e.call(this,this)
return this}
s.a.fn.scrollbarWidth=function(){const e=s()('<div style="width:50px;height:50px;overflow:hidden;position:absolute;top:-200px;left:-200px;"><div style="height:100px;"></div>').appendTo(this),t=e.find("div")
const n=t.innerWidth()
e.css("overflow-y","scroll")
const o=t.innerWidth()
e.remove()
return n-o}
s.a.fn.dim=function(e){return this.animate({opacity:.4},e)}
s.a.fn.undim=function(e){return this.animate({opacity:1},e)}
s.a.fn.confirmDelete=function(e){e=s.a.extend({},s.a.fn.confirmDelete.defaults,e)
const t=this
let n=null
let o=true
e.noMessage=e.noMessage||e.no_message
const i=function(){if(!o){e.cancelled&&s.a.isFunction(e.cancelled)&&e.cancelled.call(t)
return}e.confirmed||(e.confirmed=function(){t.dim()})
e.confirmed.call(t)
if(e.url){e.success||(e.success=function(e){t.fadeOut("slow",()=>{t.remove()})})
const o=e.prepareData?e.prepareData.call(t,n):{}
o.authenticity_token=Object(c["a"])()
s.a.ajaxJSON(e.url,"DELETE",o,n=>{e.success.call(t,n)},(n,o,i,a)=>{e.error&&s.a.isFunction(e.error)?e.error.call(t,n,o,i,a):s.a.ajaxJSON.unhandledXHRs.push(o)})}else{e.success||(e.success=function(){t.fadeOut("slow",()=>{t.remove()})})
e.success.call(t)}}
if(e.message&&!e.noMessage&&!s.a.skipConfirmations){if(e.dialog){o=false
const t="object"===typeof e.dialog?e.dialog:{}
const r=e.url.includes("assignments")?"btn-danger":"btn-primary"
n=s()(e.message).dialog(s.a.extend({},{modal:true,close:i,buttons:[{text:a.t("#buttons.cancel","Cancel"),click(){s()(this).dialog("close")}},{text:a.t("#buttons.delete","Delete"),class:r,click(){o=true
s()(this).dialog("close")}}]},t))
return}o=confirm(e.message)}i()}
s.a.fn.confirmDelete.defaults={get message(){return a.t("confirms.default_delete_thing","Are you sure you want to delete this?")}}
s.a.fn.fragmentChange=function(e){if(e&&true!==e){const n=(window.location.search||"").replace(/^\?/,"").split("&")
let o=null
for(var t=0;t<n.length;t++){const e=n[t]
e&&0===e.indexOf("hash=")&&(o="#"+e.substring(5))}this.bind("document_fragment_change",e)
const i=this
let a=false
for(t=0;t<s.a._checkFragments.fragmentList.length;t++){const e=s.a._checkFragments.fragmentList[t]
e.doc[0]==i[0]&&(a=true)}a||s.a._checkFragments.fragmentList.push({doc:i,fragment:""})
s()(window).bind("hashchange",s.a._checkFragments)
setTimeout(()=>{o&&o.length>0?i.triggerHandler("document_fragment_change",o):i&&i[0]&&i[0].location&&i[0].location.hash.length>0&&i.triggerHandler("document_fragment_change",i[0].location.hash)},500)}else this.triggerHandler("document_fragment_change",this[0].location.hash)
return this}
s.a._checkFragments=function(){const e=s.a._checkFragments.fragmentList
for(let t=0;t<e.length;t++){const n=e[t]
const o=n.doc
if(o[0].location.hash!=n.fragment){o.triggerHandler("document_fragment_change",o[0].location.hash)
n.fragment=o[0].location.hash
s.a._checkFragments.fragmentList[t]=n}}}
s.a._checkFragments.fragmentList=[]
s.a.fn.clickLink=function(){const e=this.eq(0)
e.hasClass("disabled_link")||e.click()}
s.a.fn.showIf=function(e){if(s.a.isFunction(e))return this.each((function(t){s()(this).showIf(e.call(this))}))
e?this.show():this.hide()
return this}
s.a.fn.disableIf=function(e){s.a.isFunction(e)&&(e=e.call(this))
this.prop("disabled",!!e)
return this}
s.a.fn.indicate=function(e){e=e||{}
let t
if("remove"==e){t=this.data("indicator")
t&&t.remove()
return}s()(".indicator_box").remove()
let n=this.offset()
e&&e.offset&&(n=e.offset)
const o=this.width()
const i=this.height()
const a=(e.container||this).zIndex()
t=s()(document.createElement("div"))
t.css({width:o+6,height:i+6,top:n.top-3,left:n.left-3,zIndex:a+1,position:"absolute",display:"block","-moz-border-radius":5,opacity:.8,border:"2px solid #870",backgroundColor:"#fd0"})
t.addClass("indicator_box")
t.mouseover((function(){s()(this).stop().fadeOut("fast",(function(){s()(this).remove()}))}))
this.data("indicator")&&this.indicate("remove")
this.data("indicator",t)
s()("body").append(t)
e&&e.singleFlash?t.hide().fadeIn().animate({opacity:.8},500).fadeOut("slow",(function(){s()(this).remove()})):t.hide().fadeIn().animate({opacity:.8},500).fadeOut("slow").fadeIn("slow").animate({opacity:.8},2500).fadeOut("slow",(function(){s()(this).remove()}))
e&&e.scroll&&s()("html,body").scrollToVisible(t)}
s.a.fn.hasScrollbar=function(){return this.length&&this[0].clientHeight<this[0].scrollHeight}
s.a.fn.log=function(e){console.log("%s: %o",e,this)
return this}
s.a.fn.fillWindowWithMe=function(e){const t=s.a.extend({minHeight:400},e),n=s()(this),o=s()("#wrapper"),i=s()("#main"),a=s()("#not_right_side"),r=s()(window),l=s()(this).add(t.alsoResize)
function c(){l.height(0)
const e=r.height()-(o.offset().top+o.outerHeight())+(i.height()-a.height()),c=Math.max(400,e)
l.height(c)
s.a.isFunction(t.onResize)&&t.onResize.call(n,c)}c()
r.unbind("resize.fillWindowWithMe").bind("resize.fillWindowWithMe",c)
return this}
s.a.fn.autoGrowInput=function(e){e=s.a.extend({maxWidth:1e3,minWidth:0,comfortZone:70},e)
this.filter("input:text").each((function(){let t=e.minWidth||s()(this).width(),n="",o=s()(this),i=s()("<tester/>").css({position:"absolute",top:-9999,left:-9999,width:"auto",fontSize:o.css("fontSize"),fontFamily:o.css("fontFamily"),fontWeight:o.css("fontWeight"),letterSpacing:o.css("letterSpacing"),whiteSpace:"nowrap"}),a=function(){setTimeout(()=>{if(n===(n=o.val()))return
i.text(n)
const a=i.width(),r=a+e.comfortZone>=t?a+e.comfortZone:t,s=o.width(),l=r<s&&r>=t||r>t&&r<e.maxWidth
l&&o.width(r)})}
i.insertAfter(o)
s()(this).bind("keyup keydown blur update change",a)}))
return this}
s.a},ppAs:function(e,t,n){"use strict"
var o=n("ouhR")
var i=n.n(o)
var a=n("GLiE")
var r=n.n(a)
var s=n("5Ky4")
var l=n("pQTu")
var c=n("m0r6")
Object(c["a"])(JSON.parse('{"ar":{"user_content_aaf0fb5a":"محتوى المستخدم"},"cy":{"user_content_aaf0fb5a":"Cynnwys Defnyddiwr"},"da":{"user_content_aaf0fb5a":"Brugerindhold"},"da-x-k12":{"user_content_aaf0fb5a":"Brugerindhold"},"de":{"user_content_aaf0fb5a":"Benutzer-Content"},"el":{"user_content_aaf0fb5a":"Περιεχόμενο Χρήστη"},"en-AU":{"user_content_aaf0fb5a":"User Content"},"en-CA":{"user_content_aaf0fb5a":"User Content"},"en-GB":{"user_content_aaf0fb5a":"User content"},"es":{"user_content_aaf0fb5a":"Contenido del usuario"},"fa":{"user_content_aaf0fb5a":"محتوای کاربر"},"fi":{"user_content_aaf0fb5a":"Käyttäjän sisältö"},"fr":{"user_content_aaf0fb5a":"Contenu de l\'utilisateur"},"fr-CA":{"user_content_aaf0fb5a":"Contenu de l\'utilisateur"},"he":{"user_content_aaf0fb5a":"תוכן משתמש"},"ht":{"user_content_aaf0fb5a":"Kontni Itilizatè"},"hu":{"user_content_aaf0fb5a":"Felhasználói tartalom"},"is":{"user_content_aaf0fb5a":"Notandaefni"},"it":{"user_content_aaf0fb5a":"Contenuto utente"},"ja":{"user_content_aaf0fb5a":"ユーザーコンテンツ"},"mi":{"user_content_aaf0fb5a":"Ihirangi kaiwhakamahi"},"nb":{"user_content_aaf0fb5a":"Brukerinnhold"},"nb-x-k12":{"user_content_aaf0fb5a":"Brukerinnhold"},"nl":{"user_content_aaf0fb5a":"Gebruikersinhoud"},"nn":{"user_content_aaf0fb5a":"Brukarinnhald"},"pl":{"user_content_aaf0fb5a":"Zawartość użytkownika"},"pt":{"user_content_aaf0fb5a":"Conteúdo do Utilizador"},"pt-BR":{"user_content_aaf0fb5a":"Conteúdo do Usuário"},"ru":{"user_content_aaf0fb5a":"Контент пользователя"},"sl":{"user_content_aaf0fb5a":"Vsebina uporabnika"},"sv":{"user_content_aaf0fb5a":"Användarinnehåll"},"sv-x-k12":{"user_content_aaf0fb5a":"Användarinnehåll"},"tr":{"user_content_aaf0fb5a":"Kullanıcı İçeriği"},"uk":{"user_content_aaf0fb5a":"Контент користувача"},"zh-Hans":{"user_content_aaf0fb5a":"用户内容"},"zh-Hant":{"user_content_aaf0fb5a":"使用者內容"}}'))
n("jQeR")
n("0sPK")
var d=l["default"].scoped("user_content")
const u={translateMathmlForScreenreaders(e){const t=i()("<div/>").html(e.attr("x-canvaslms-safe-mathml")).html()
const n=i()('<span class="hidden-readable"></span>')
n.html(t)
return n},toMediaCommentLink(e){const t=i()("<a\n        id='media_comment_".concat(Object(s["a"])(i()(e).data("media_comment_id")),"'\n        data-media_comment_type='").concat(Object(s["a"])(i()(e).data("media_comment_type")),"'\n        class='instructure_inline_media_comment ").concat(Object(s["a"])(e.nodeName.toLowerCase()),"_comment'\n        data-alt='").concat(Object(s["a"])(i()(e).attr("data-alt")),"'\n      />"))
t.html(i()(e).html())
return t},convert(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{}
const n=i()("<div />").html(e)
n.find("video.instructure_inline_media_comment,audio.instructure_inline_media_comment").replaceWith((function(){return u.toMediaCommentLink(this)}))
n.find("object.instructure_user_content:not(#kaltura_player) embed").remove()
if(!t.forEditing){n.find("object.instructure_user_content,embed.instructure_user_content").replaceWith((function(){const e=i()(this)
if(!e.data("uc_snippet")||!e.data("uc_sig"))return this
const t=r.a.uniqueId("uc_")
let n="/object_snippet"
ENV.files_domain&&(n="//".concat(ENV.files_domain).concat(n))
const o=i()("<form\n            action='".concat(Object(s["a"])(n),"'\n            method='post'\n            class='user_content_post_form'\n            target='").concat(Object(s["a"])(t),"'\n            id='form-").concat(Object(s["a"])(t),"'\n          />"))
o.append(i()("<input type='hidden'/>").attr({name:"object_data",value:e.data("uc_snippet")}))
o.append(i()("<input type='hidden'/>").attr({name:"s",value:e.data("uc_sig")}))
i()("body").append(o)
setTimeout(()=>o.submit(),0)
return i()("<iframe\n            class='user_content_iframe'\n            name='".concat(Object(s["a"])(t),"'\n            style='width: ").concat(Object(s["a"])(e.data("uc_width")),"; height: ").concat(Object(s["a"])(e.data("uc_height")),";'\n            frameborder='0'\n            title='").concat(Object(s["a"])(d.t("User Content")),"'\n          />"))}))
n.find("img.equation_image").each((e,t)=>{const n=i()(t)
const o=u.translateMathmlForScreenreaders(n)
n.removeAttr("x-canvaslms-safe-mathml")
n.after(o)})}return n.html()}}
t["a"]=u},qJBq:function(e,t){(function(){var t,n,o
o=[]
t={}
e.exports=n=function(e,n,i){var a,r,s,l,c,d,u,b,h
null==i&&(i=true)
if("string"===typeof n){if(2!==n.length)throw{name:"ArgumentException",message:"The format for string options is '<thousands><decimal>' (exactly two characters)"}
h=n[0],a=n[1]}else if(Array.isArray(n)){if(2!==n.length)throw{name:"ArgumentException",message:"The format for array options is ['<thousands>','[<decimal>'] (exactly two elements)"}
h=n[0],a=n[1]}else{h=(null!=n?n.thousands:void 0)||(null!=n?n.group:void 0)||t.thousands
a=(null!=n?n.decimal:void 0)||t.decimal}u=""+h+a+i
d=o[u]
if(null==d){s=i?3:1
d=o[u]=new RegExp("^\\s*([+-]?(?:(?:\\d{1,3}(?:\\"+h+"\\d{"+s+",3})+)|\\d*))(?:\\"+a+"(\\d*))?\\s*$")}b=e.match(d)
if(!(null!=b&&3===b.length))return NaN
l=b[1].replace(new RegExp("\\"+h,"g"),"")
r=b[2]
c=parseFloat(l+"."+r)
return c}
e.exports.setOptions=function(e){var n,o
for(n in e){o=e[n]
t[n]=o}}
e.exports.factoryReset=function(){t={thousands:",",decimal:"."}}
e.exports.withOptions=function(e,t){null==t&&(t=true)
return function(o){return n(o,e,t)}}
e.exports.factoryReset()}).call(this)},"tVj+":function(e,t,n){"use strict"
var o=n("ouhR")
var i=n.n(o)
n("BYL3")
const a={validate:/^[a-zA-Z][a-zA-Z0-9_-]*(?:\[(?:\d*|[a-zA-Z0-9_-]+)\])*$/,key:/[a-zA-Z0-9_-]+|(?=\[\])/g,push:/^$/,fixed:/^\d+$/,named:/^[a-zA-Z0-9_-]+$/}
const r=function(e,t,n){e[t]=n
return e}
i.a.fn.toJSON=function(){let e={},t={}
const n=function(e,n){void 0===t[e]&&(t[e]=0)
if(void 0===n)return t[e]++
if(void 0!==n&&n>t[e])return t[e]=++n}
i.a.each(i()(this).serializeForm(),(function(){if(!a.validate.test(this.name))return
let t,o=this.name.match(a.key),s=this.value,l=this.name
while(void 0!==(t=o.pop())){l=l.replace(new RegExp("\\["+t+"\\]$"),"")
if(t.match(a.push))s=r([],n(l),s)
else if(t.match(a.fixed)){n(l,t)
s=r([],t,s)}else t.match(a.named)&&(s=r({},t,s))}e=i.a.extend(true,e,s)}))
return e}},teYS:function(e,t,n){const o=n("ouhR")
var i,a,r,s=o({})
o.subscribe=i=function(e,t){if(o.isPlainObject(e))return o.each(e,(function(e,t){i(e,t)}))
function n(){return t.apply(this,Array.prototype.slice.call(arguments,1))}n.guid=t.guid=t.guid||o.guid++
s.bind(e,n)}
o.unsubscribe=a=function(){s.unbind.apply(s,arguments)}
o.publish=r=function(){s.trigger.apply(s,arguments)}
e.exports={subscribe:i,unsubscribe:a,publish:r}}}])

//# sourceMappingURL=edit_rubric-c-355a737d33.js.map